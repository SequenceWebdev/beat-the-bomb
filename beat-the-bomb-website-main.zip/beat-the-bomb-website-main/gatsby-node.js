// Allow css module rule names to use the format className={styles["name-here"]}
const process_rule = rule => {
  if (rule.oneOf) {
    return {
      ...rule,
      oneOf: rule.oneOf.map(process_rule),
    };
  }

  if (Array.isArray(rule.use)) {
    return {
      ...rule,
      use: rule.use.map(use => {
        const css_loader_regex = /\/css-loader\//;

        if (!css_loader_regex.test(use.loader)) {
          return use;
        }

        return {
          ...use,
          options: {
            ...use.options,
            camelCase: false,
          },
        };
      }),
    };
  }

  return rule;
};

if (process.env.NODE_ENV === 'development') {
  process.env.GATSBY_WEBPACK_PUBLICPATH = '/'
}

const path = require('path')
const slugify = require('slugify')
exports.createPages = async ({ graphql, actions }) =>{
  const { createPage } = actions
  const result = await graphql(`
    query homePagesQuery {
      allContentfulHomePages {
        nodes {
          pathname
          title
          pageName
        }
      }
    }

  `)

  if(result.errors){
    console.log(result.errors);
    reject(result.errors);
  }

  result.data.allContentfulHomePages.nodes.forEach(node =>{
      let name = node.pageName;
      createPage({
        path: node.pathname,
        component: path.resolve(`src/templates/home-template.js`),
        context: {
          name: name,
        }
      })
  })
}