import React from 'react'
import { graphql } from 'gatsby'

// import site_image from "../assets/images/site.jpg";
import Seo from '../components/seo';
import Layout from '../layouts'
import MissionNavBar from '../components/mission/nav-bar'

import { FAQ, 
  Banner, 
  HeroImage, 
  Text, 
  SingleImage, 
  ImagePanel, 
  ReviewCarousel, 
  ReviewTestimonial, 
  Ticket, 
  Button, 
  Missions, 
  TextSlider, 
  LogoCarousel, 
  SignUp, 
  Locations, 
  ImageTextButton,
  EventsHero,
  EventsImageTextButton,
  EventsReviewCarousel,
  EventsSignUp,
  AsSeenIn,
  ChooseMission,
  GameBay,
  ProLeague,
  FoodAndDrinks,
  NewsBlog,
} from '../components/home-new'

import { BlogPage } from '../components/blog';

import { GameCard, ImageText, GameBayCard } from '../components/mission'

import { Tsi } from '../components/tripleseat-form'

const sections ={
  "Banner": Banner,
  "HeroImage": HeroImage,
  "Text": Text,
  "SingleImage": SingleImage,
  "3ImagePanel": ImagePanel,
  "ReviewTestimonialCard": ReviewTestimonial,
  "ReviewCarousel" : ReviewCarousel,
  "TicketCard": Ticket,
  "ButtonSection": Button,
  "MissionSection": Missions,
  "TextSlider": TextSlider,
  "LogoCarousel": LogoCarousel,
  "SignUp": SignUp,
  "LocationSection": Locations,
  "ImageTextButton": ImageTextButton,
  "FaqSection": FAQ,
  "IFrames": Tsi,
  "EventsHero": EventsHero,
  "EventsImageTextButton": EventsImageTextButton,
  "EventsReviewCarousel": EventsReviewCarousel,
  "EventsSignUp": EventsSignUp,
  "GameCard": GameCard,
  "ImageText": ImageText,
  "GameBayCard": GameBayCard,
  "AsSeenIn": AsSeenIn,
  "ChooseMission": ChooseMission,
  "GameBay": GameBay,
  "ProLeague": ProLeague,
  "Blog": BlogPage,
  "FoodDrinkMenuSection":FoodAndDrinks,
  "NewsBlogSection": NewsBlog
}



const HomeTemplate = (pageContext) => {
  const page_data = pageContext.data
  const page_references = page_data.contentfulHomePages.pageComponents
  const {title, description, image } = page_data.contentfulHomePages;

  return (
    <Layout pathname={pageContext.path}>
      <Seo
        path={pageContext.path}
        description={description.description}
        title={title}
        seoImage={image}
      />
      {(pageContext.path.includes('mission') || pageContext.path.includes('game-bay') )&&
      <MissionNavBar path={pageContext.path}/>}
      {page_references.map((ref, index)=>{
        const Section = sections[ref.internal.type.replace("ContentfulHomePage", "")];
        return (
            <Section
              data={ref}
              key={index}
              path={pageContext.path}
            />
        )
      })}

    </Layout>
  )
}

export default HomeTemplate

export const query = graphql`
query homePageQuery($name: String) {
  contentfulHomePages(pageName: {eq: $name}) {
    pathname
    title
    description {
      description
    }
    canonical
    image {
      url
    }
    pageComponents {
      ... on ContentfulHomePageNewsBlogSection {
        internal {
          type
        }
        newsBlogs {
          title
          description {
            description
          }
          modalDescription {
            raw
          }
          buttons{
              borderColor
              buttonColor
              buttonText
              textColor
              type
              buttonLink
          }
          date(formatString: "MM/DD")
          dateExtraText
          image {
            title
            url
            gatsbyImageData(layout: CONSTRAINED)
          }
        }
      }
      ... on ContentfulHomePageFoodDrinkMenuSection {
        internal {
          type
        }
        buttons {
          borderColor
          buttonColor
          buttonText
          textColor
          type
          image {
            title
            url
          }
        }
        food {
          name
          color
          subMenuItems {
            name
            extraNote
            menuItems {
              name
              price
              image {
                title
                url
                gatsbyImageData(layout: CONSTRAINED)
              }
              description {
                description
              }
            }
          }
        }
        drinks {
          name
          color
          subMenuItems {
            name
            menuItems {
              name
              price
              image {
                title
                url
                gatsbyImageData(layout: CONSTRAINED)
              }
              description {
                description
              }
            }
          }
        }
      }
      ... on ContentfulHomePageBlog {
        internal {
          type
        }
        blogTitle
        publishedTime(formatString: "DD MMM, YYYY HH:mm")
        sourceLabel
        sourceUrl
        image {
          gatsbyImageData(layout: CONSTRAINED)
          title
        }
        richText {
          raw
        }
      }
      ... on ContentfulHomePageProLeague {
        leaderboardTitle
        internal {
          type
        }
        image {
          url
          title
        }
        button {
          borderColor
          buttonColor
          buttonText
          textColor
          type
          buttonLink
        }
        startDate(formatString: "YYYYMMDD")
        endDate(formatString: "YYYYMMDD")
      }
      ... on ContentfulHomePageEventsImageTextButton {
        internal {
          type
        }
        eventsCarousel{
          internal {
            type
          }
          companyLogos {
            title
            url
          }
        }
        buttons {
          borderColor
          buttonColor
          buttonText
          textColor
          type
          buttonLink
          locations{
            locationCards {
              button {
                borderColor
                buttonColor
                buttonText
                textColor
                type
                buttonLink
              }
              locationText
              image {
                gatsbyImageData
                title
              }
              overlayGradientColor
            }
          }
        }
        header
        richText {
          raw
        }
        mediaAsset {
          gatsbyImageData(layout: CONSTRAINED)
        }
        imageLocation
        bulletPoints
        paintSplatColor
      }
      ... on ContentfulHomePageEventsReviewCarousel {
        internal {
          type
        }
        icons {
          url
          title
        }
        carousel{
          internal {
            type
          }
          companyLogos {
            title
            url
          }
        }
        asSeenInText
        reviewTestimonials {
          clientName
          backgroundColor
          
          review {
            review
          }
        }
      }
      ... on ContentfulHomePageAsSeenIn {
        internal {
          type
        }
        header
        media {
          title
          url
        }
        icons {
          url
          title
        }
        placeholder{
          title
          url
        }
        carousel{
          internal {
            type
          }
          companyLogos {
            title
            url
          }
        }
      }
      ... on ContentfulHomePageEventsSignUp {
        internal {
          type
        }
        backgroundImage {
          gatsbyImageData(
            resizingBehavior: SCALE,
            placeholder: BLURRED,
          )
          title
        }
        header
        richText {
          raw
        }
        button {
          borderColor
          buttonColor
          buttonText
          textColor
          type
          buttonLink
        }
      }
      ... on ContentfulHomePageImageText {
        internal {
          type
        }
        richText {
          raw
        }
        image {
          gatsbyImageData
          url
        }
      }
      ... on ContentfulHomePageEventsHero {
        internal {
          type
        }
        header
        subheader {
          subheader
        }
        assets {
          richText {
            raw
          }
          image {
            url
            title
          }
        }
        video {
          title
          url
        }
        placeholderImg {
          url
        }
        buttons {
          borderColor
          buttonColor
          buttonText
          textColor
          type
          buttonLink
        }
      }
      ... on ContentfulHomePageGameBayCard {
        internal {
          type
        }
        gameType
        gameTypeDescription
        games {
          name
          gameDescription {
            gameDescription
          }
          gameMissionImageAssets {
            gatsbyImageData(placeholder: BLURRED, resizingBehavior: SCALE)
          }
        }
      }
      ... on ContentfulHomePageIFrames {
        internal {
          type
        }
        url
        name
      }
      ... on ContentfulHomePageBanner {
        internal {
          type
        }
        color
        text{
          text
        }
        tiltAlignment
        fontSize
      }
      ... on ContentfulHomePageReviewCarousel {
        internal {
          type
        }
        title {
          title
        }
        cards {
          alignment
          clientName
          backgroundColor
          postedDate(formatString: "MMM YYYY")
          review {
            review
          }
          starImage {
            gatsbyImageData(
              resizingBehavior: SCALE,
              placeholder: BLURRED,
            )
            title
          }
          sourceImage {
            gatsbyImageData(
              resizingBehavior: SCALE,
              placeholder: BLURRED,
            )
            title
          }
        }
      }
      ... on ContentfulHomePageGameCard {
        gameDescription {
          gameDescription
        }
        internal {
          type
        }
        topLeftImage {
          gatsbyImageData
          title
        }
        rightImage {
          gatsbyImageData
          title
        }
        video{
          url
          title
        }
      }
      ... on ContentfulHomePageButtonSection {
        internal {
          type
        }
        button {
          borderColor
          buttonColor
          buttonText
          textColor
          type
          buttonLink
          locations{
            locationCards {
              button {
                borderColor
                buttonColor
                buttonText
                textColor
                type
                buttonLink
              }
              locationText
              image {
                gatsbyImageData
                title
              }
              overlayGradientColor
            }
          }
        }
      }
      ... on ContentfulHomePageHeroImage {
        internal {
          type
        }
        backgroundImage {
          title
          gatsbyImageData(
            layout: FULL_WIDTH,
            placeholder: BLURRED,
            resizingBehavior: SCALE,
          )
        }
        mainText {
          raw
        }
        textCarousel
        video {
          title
          url
        }
        mobileVideo {
          title
          url
        }
        placeholderImg {
          url
        }
        buttons {
          borderColor
          buttonColor
          buttonText
          textColor
          type
          buttonLink
        }
        name
      }
      ... on ContentfulHomePageGameBay {
        internal {
          type
        }
        header
        secondHeader
        description {
          raw
        }
        backgroundImage {
          title
          url
        }
        buttons {
          borderColor
          buttonColor
          buttonText
          textColor
          type
          buttonLink
        }
        gameBayIcons {
          url
          title
        }
        video {
          title
          url
        }
        placeholder {
          title
          url
        }
        carousel{
          internal {
            type
          }
          companyLogos {
            title
            url
          }
        }
      }
      ... on ContentfulHomePageChooseMission {
        internal{
          type
        }
        header
        missions {
          video {
            url
          }
          cardImage {
            title
            url
          }
          paintWordColor
          missionName
          missionDescription {
            raw
          }
          buttons {
            borderColor
            buttonColor
            buttonText
            textColor
            type
            buttonLink
          }
        }
      }
      ... on ContentfulHomePageMissionSection {
        internal {
          type
        }
        missionDescriptionCard {
          gameDescription {
            gameDescription
          }
          gameMissionImageAssets {
            url
            title
          }
        }
        mission {
          name
          paintWordColor
          missionNumber
          missionName
          missionDescription {
            raw
          }
          video{
            title
            url
          }
          cardImage {
            title
            gatsbyImageData(placeholder: BLURRED, resizingBehavior: SCALE)
          }
          gamesImage {
            title
            gatsbyImageData(
              resizingBehavior: SCALE,
              placeholder: BLURRED,
            )
          }
          button {
            borderColor
            buttonColor
            buttonText
            textColor
            type
            buttonLink
          }
        }
      }
      ... on ContentfulHomePageSignUp {
        internal {
          type
        }
        backgroundImage {
          gatsbyImageData(
            resizingBehavior: SCALE,
            placeholder: BLURRED,
          )
          title
          url
        }
        topText
        richText {
          raw
        }
      }
      ... on ContentfulHomePageSingleImage {
        internal {
          type
        }
        image {
          gatsbyImageData(placeholder: BLURRED)
          title
        }
        video{
          title
          url
        }
        buttonLocation
        overlayGradientColor
        button {
          borderColor
          buttonColor
          buttonText
          textColor
          type
          buttonLink
        }
      }
      ... on ContentfulHomePageText {
        internal {
          type
        }
        color
        font
        fontStyle
        fontSize
        fontWeight
        topMargin
        textTransform
        richText {
          raw
        }
        textAlignment
        contentfulid
      }
      
    }
  }
}
`
