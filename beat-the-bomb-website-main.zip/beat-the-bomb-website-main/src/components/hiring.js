import React from 'react'
import styled from 'styled-components'
import { AiFillCaretRight } from "react-icons/ai"

const HiringWrapper = styled.div`
  max-width: 1920px;
  /* padding: 0 1rem; */

  & h2{
    padding: 0 60px;
    font-family: 'Acumin-Pro-700';
    font-style: normal;
    font-weight: 700;
    text-align: center;
    letter-spacing: 0.03em;
    text-transform: uppercase;
    font-size: 75px;
    color: #fff;
    margin-top: 3rem;
    margin-bottom: 3rem;
  }

  .job_listing__container{
    display:flex;
    flex-direction: column;
    align-items: center;
    width:100%;
  }

  .job_listing__button{
    display: flex;
    border-radius: 1rem;
    align-items: center;
    justify-content: space-between;
    background-color: var(--neon-blue);
    margin-top: 1.5rem;
    margin-bottom: 1.5rem;
    padding: 0.5rem 1rem;
    width: 95%;
    color: white;
    font-size: 20px;
  }

  .job_listing__button:hover{
    color:var(--neon-blue);
    background-color: #ffffff;

    .rightArrow{
      color:var(--neon-blue);
    }
  }

  .rightArrow{
    color:white;
  }

  @media screen and (max-width: 768px) {
    & h2 {
      padding: 0 30px;
      font-size: 45px;
    }

    .job_listing__button{
      font-size: 16px;
    }
 
  }

  @media screen and (max-width: 500px) {
    & h2 {
      font-size: 30px;
    }

    .job_listing__button{
      font-size: 12px;
    }
  }

  @media only screen and (min-width: 1920px){
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }
`

const LocationContainer = styled.div`
  padding: 0 3rem;
  margin-bottom: 3rem;
  /* scroll-margin-top: 9rem; */

  h4{
    font-family: 'Acumin-Pro-700';
    font-style: normal;
    font-weight: 700;
    text-align: left;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    font-size: 22px;
    color:#ffffff;

    @media only screen and (max-width: 768px){
      font-size:18px;
    }

    @media only screen and (max-width: 500px){
      font-size:15px;
    }
  }

  .white_divider{
    width: 100%;
    height: 5px;
    border-top: 1px solid #ffffff;
  }
`

const Hiring = ({ context, jq }) => {
  const { headerTitle, markupText } = context[0]
  return (
    <HiringWrapper>
      <h2>{headerTitle}</h2>
      {jq.map((place, index)=>{
        return place.totalCount !== 0 && (
          <LocationContainer key={index} id={place.fieldValue}>
            <h4>{place.fieldValue}&nbsp;({markupText}&nbsp;{place.totalCount})</h4>
            <div className="white_divider"></div>
            <div className="job_listing__container">
              {place.nodes.map((job, index) =>{
                return(
                  <a href={job.jobUrl} key={index} className="job_listing__button">
                    {job.jobTitle}   
                    <AiFillCaretRight className='rightArrow'/>
                  </a>
                )
              })}
            </div>
          </LocationContainer>
        )
      })}
    </HiringWrapper>
  )
}

export default Hiring
