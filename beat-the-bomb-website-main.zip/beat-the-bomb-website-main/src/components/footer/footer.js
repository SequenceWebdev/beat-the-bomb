import React from 'react'
import { StaticImage } from 'gatsby-plugin-image';
import { Link } from "gatsby";
import * as Fa from "react-icons/fa";

import * as footerStyles from "../styles/footer.module.css"
import { isStyledComponent } from 'styled-components';
import { AnchorLink } from "gatsby-plugin-anchor-links";

//images
import atl_logo from "../../assets/images/navigation/btb_atlanta_logo.png";
import bk_logo from "../../assets/images/navigation/btb_brooklyn_logo.png";
import v_logo from "../../assets/images/navigation/btb_virtual_logo.png";
import dc_logo from "../../assets/images/navigation/btb_dc_logo.png";
import fb_icon from "../../assets/images/footer-social-icons/facebook.png";
import insta_icon from "../../assets/images/footer-social-icons/instagram.png";
import tiktok_icon from "../../assets/images/footer-social-icons/tiktok.png";
import twitter_icon from "../../assets/images/footer-social-icons/twitter.png";
import yt_icon from "../../assets/images/footer-social-icons/yt.png";




const Footer = (pageContext) => {
  const { pathname } = pageContext
  const PAGES = {
    "/virtual": "VIRTUAL", 
    "https://www.applicantpro.com/openings/beatthebomb/jobs": "CAREERS",
    "/faq": "FAQ",
    "/privacy-policy": "Privacy Policy",

  };

  const links = Object.keys(PAGES).map(function (key) {
    return [key, PAGES[key]];
  });

  const colors ={
    "Black":"#000000",
    "Blue": "var(--neon-blue)",
    "Pink": "var(--neon-pink)",
    "Yellow": "var(--neon-yellow)",
    "Green": "var(--neon-green)",
    "White": "#FFFFFF",
  }

  return (
    <footer className={footerStyles.footer}>
      <div className={footerStyles.footer__column1}>
        {(
            !(pathname?.includes("/brooklyn") ||
            pathname?.includes("/atlanta") ||
            pathname?.includes("/dc") ||
            pathname?.includes("/virtual"))
          ) && 
        <div className={footerStyles.footer__logo_container}>
          <StaticImage alt="beat the bomb" className={footerStyles.footer__logo} src="../../assets/images/navigation/logo-old.png" />
        </div>}
        {pathname.includes('/virtual') && 
        <div className={footerStyles.footer__logo_container}>
          <img alt="btb footer virtual logo" className={footerStyles.footer__logo} src={v_logo}/>
        </div>}
        {pathname.includes('/atlanta') && 
        <div className={footerStyles.footer__logo_container}>
          <img alt="btb footer atl logo" className={footerStyles.footer__logo} src={atl_logo}/>
        </div>}
        {pathname.includes('/brooklyn') && 
        <div className={footerStyles.footer__logo_container}>
          <img alt="btb footer bk logo" className={footerStyles.footer__logo} src={bk_logo}/>
        </div>
        }
        {pathname.includes('/dc') && 
        <div className={footerStyles.footer__logo_container}>
          <img alt="btb footer dc logo" className={footerStyles.footer__logo} src={dc_logo}/>
        </div>}
        <div className={footerStyles.footer_locations}>
          {!((pathname.includes('/brooklyn')) || (pathname.includes('/atlanta')) || (pathname.includes('/dc'))) && <br className='mobile_break'/>}
          {pathname === '/virtual' && 
          <a className={footerStyles.footer__upperCaseContent} href="mailto:online@beatthebomb.com.com?subject=Virtual Request:">
            <button className={footerStyles.email_us}>
            <span>
              <BorderFlairTopLeft
                color="var(--neon-green)"
              />
              Email Us
              <BorderFlairBotRight
                color="var(--neon-green)"
              />
            </span>
            </button>
          </a>}
          {!(pathname.includes('/brooklyn') || pathname.includes('/virtual') || (pathname.includes('/dc'))) && <div className={footerStyles.footer__locations_container}>
            
            <div className={footerStyles.footer__upperCaseContent}>1483 Chattahoochee Ave</div>
            <div className={footerStyles.footer__upperCaseContent}>NW, Atlanta, GA 30318</div>
          </div>}
          {!((pathname.includes('/brooklyn')) || (pathname.includes('/atlanta')) || (pathname.includes('/dc'))) && <br className='mobile_break'/>}
          {!(pathname.includes('/atlanta') || pathname.includes('/virtual') || (pathname.includes('/dc'))) && <div className={footerStyles.footer__locations_container}>
            
            <div className={footerStyles.footer__upperCaseContent}>255 Water Street</div>
            <div className={footerStyles.footer__upperCaseContent}>Brooklyn, NY 11201</div>
          </div>}
          {!((pathname.includes('/brooklyn')) || (pathname.includes('/atlanta')) || (pathname.includes('/dc'))) && <br className='mobile_break'/>}
          {!(pathname.includes('/atlanta') || pathname.includes('/virtual') || (pathname.includes('/brooklyn'))) && <div className={footerStyles.footer__locations_container}>
            
            <div className={footerStyles.footer__upperCaseContent}>2005 Hecht Ave NE</div>
            <div className={footerStyles.footer__upperCaseContent}>Washington, DC 20002</div>
          </div>}
          {!((pathname.includes('/brooklyn')) || (pathname.includes('/atlanta')) || (pathname.includes('/dc'))) && <br></br>}
          {/* <div className={footerStyles.footer__dividers}></div> */}
          {!((pathname.includes('/brooklyn')) || (pathname.includes('/virtual')) || (pathname.includes('/atlanta')) || (pathname.includes('/dc'))) && 
          <a className={footerStyles.footer__upperCaseContent} href="mailto:online@beatthebomb.com.com?subject=Virtual Request:">
            <button className={footerStyles.email_us}>
            <span>
              <BorderFlairTopLeft
                color="var(--neon-green)"
              />
              Email Us
              <BorderFlairBotRight
                color="var(--neon-green)"
              />
            </span>
            </button>
          </a>}
          {pathname.includes('/brooklyn') && 
          <a className={footerStyles.footer__upperCaseContent} href="mailto:info@beatthebomb.com?subject=Brooklyn Request:">
            <button className={footerStyles.email_us}>
            <span>
              <BorderFlairTopLeft
                color="var(--neon-green)"
              />
              Email Us
              <BorderFlairBotRight
                color="var(--neon-green)"
              />
            </span>
            </button>
          </a>}
          {pathname.includes('/atlanta') && 
          <a className={footerStyles.footer__upperCaseContent} href="mailto:info@beatthebomb.com?subject=Atlanta Request:">
            <button className={footerStyles.email_us}>
              <span>
                <BorderFlairTopLeft
                  color="var(--neon-green)"
                />
                Email Us
                <BorderFlairBotRight
                  color="var(--neon-green)"
                />
              </span>
            </button>
          </a>}
          {pathname.includes('/dc') && 
          <a className={footerStyles.footer__upperCaseContent} href="mailto:info@beatthebomb.com?subject=DC Request:">
            <button className={footerStyles.email_us}>
              <span>
                <BorderFlairTopLeft
                  color="var(--neon-green)"
                />
                Email Us
                <BorderFlairBotRight
                  color="var(--neon-green)"
                />
              </span>
            </button>
          </a>}
        </div>
      </div>

      {/* <div className={footerStyles.footer__dividers}></div> */}
      <div className={footerStyles.footer__column2}>
        <h4 className={footerStyles.footer__heading}><strong>Quick Links</strong></h4>
        <div className={footerStyles.footer__links}>
          {links.map((value, index) => {
            const currLink = value[0] === "CAREERS" ?
              <a className={footerStyles.footer__link} href={value[0]} key={index}><div className={footerStyles.footer__pagesUpperCaseContent}>{value[1]}</div></a> 
              : 
              <Link className={footerStyles.footer__link} key={index} to={value[0]}><div className={footerStyles.footer__pagesUpperCaseContent}>{value[1]}</div></Link>;
            return (
              currLink
            );
          })}

          {/* "BOOK NOW": "BOOK NOW"  */}
          { (pathname?.includes("/") || 
            pathname?.includes("/learn-more") ||
            pathname?.includes("/virtual") ||
            pathname?.includes("/video") ||
            pathname?.includes("/leaderboards") ||
            pathname?.includes("/faq") ||
            pathname?.includes("/careers") ||
            pathname?.includes("/404") ||
            pathname?.includes("/privacy-policy")) && (
              !pathname?.includes("/brooklyn") && !pathname?.includes("/atlanta") && !pathname?.includes("/dc")
            ) &&
            <AnchorLink className={footerStyles.footer__link} to='/#locations' stripHash={true}><div className={footerStyles.footer__pagesUpperCaseContent}>BOOK NOW</div></AnchorLink> 
          }
          { pathname?.includes("/atlanta") &&
            <a className={footerStyles.footer__link} href="https://checkout.xola.com/index.html#buttons/63091d3e30d8544279111238?cache=1661549928757&">
              <div className={footerStyles.footer__pagesUpperCaseContent}>BOOK NOW</div>
            </a>
          }
          { pathname?.includes("/brooklyn") &&
            <a className={footerStyles.footer__link} href="https://checkout.xola.com/index.html#buttons/6308d7e950cfe36e325c1cdd?cache=1661523947828&">
              <div className={footerStyles.footer__pagesUpperCaseContent}>BOOK NOW</div>
            </a>
          }

        </div>
      </div>

      {/* <div className={footerStyles.footer__dividers}></div> */}
      <div className={footerStyles.footer__column3}>
        <h4 className={[footerStyles.footer__heading, footerStyles.footer__heading__right_col].join(" ")}><strong>Follow Us</strong></h4>
        <div className={footerStyles.footer__socialLinks__container}>
          <div className={footerStyles.footer__socialLinks__top}>
            <a
              alt="tiktok-icon"
              href="https://www.tiktok.com/@beatthebomb"
              rel="noopener noreferrer"
              target="_blank"
            >
              <img alt="tiktok social icon" className={footerStyles.footer__socialIcon} src={tiktok_icon}/>
              {/* <Fa.FaTiktok className={footerStyles.footer__socialIcon} /> */}
            </a>
            <a
              alt="instagram-icon"
              href="https://www.instagram.com/beatthebomb/"
              rel="noopener noreferrer"
              target="_blank"
            >
              <img alt="instagram social icon" className={footerStyles.footer__socialIcon} src={insta_icon}/>
              {/* <Fa.FaInstagram className={footerStyles.footer__socialIcon} /> */}
            </a>
            <a
              alt="facebook-icon"
              href="https://www.facebook.com/beatthebomb/"
              rel="noopener noreferrer"
              target="_blank"
            >
              <img alt="fb social icon" className={footerStyles.footer__socialIcon} src={fb_icon}/>
              {/* <Fa.FaFacebookSquare className={footerStyles.footer__socialIcon} /> */}
            </a>
          </div>
          <div className={footerStyles.footer__socialLinks__bot}>
            <a
              alt="youtube-icon"
              href="https://www.youtube.com/channel/UC0yh7vo1knuKuaaCKUssAzA/"
              rel="noopener noreferrer"
              target="_blank"
            >
              <img alt="yt social icon" className={footerStyles.footer__socialIcon} src={yt_icon}/>
              {/* <Fa.FaYoutube className={footerStyles.footer__socialIcon} /> */}
            </a>
            <a
              alt="twitter-icon"
              href="https://twitter.com/beatthebomb?lang=en"
              rel="noopener noreferrer"
              target="_blank"
            >
              <img alt="twitter social icon" className={footerStyles.footer__socialIcon} src={twitter_icon}/>
              {/* <Fa.FaTwitter className={footerStyles.footer__socialIcon} /> */}
            </a>
          </div>
        </div>
      </div>
      <div className={footerStyles.email_us__mobile_container}>
        {!((pathname.includes('/brooklyn')) || (pathname.includes('/atlanta')) || (pathname.includes('/dc'))) && 
          <a className={[footerStyles.footer__upperCaseContent, footerStyles.footer__upperCaseContent__mobile].join(" ")} href="mailto:info@beatthebomb.com?subject=General Request:">
            <button className={footerStyles.email_us__mobile}>
            <span>
              <BorderFlairTopLeft
                color="var(--neon-green)"
              />
              Email Us
              <BorderFlairBotRight
                color="var(--neon-green)"
              />
            </span>
            </button>
          </a>}
          {pathname.includes('/brooklyn') && 
          <a className={[footerStyles.footer__upperCaseContent, footerStyles.footer__upperCaseContent__mobile].join(" ")} href="mailto:info@beatthebomb.com?subject=Brooklyn Request:">
            <button className={footerStyles.email_us__mobile}>
            <span>
              <BorderFlairTopLeft
                color="var(--neon-green)"
              />
              Email Us
              <BorderFlairBotRight
                color="var(--neon-green)"
              />
            </span>
            </button>
          </a>}
          {pathname.includes('/atlanta') && 
          <a className={[footerStyles.footer__upperCaseContent, footerStyles.footer__upperCaseContent__mobile].join(" ")} href="mailto:info@beatthebomb.com?subject=Atlanta Request:">
            <button className={footerStyles.email_us__mobile}>
              <span>
                <BorderFlairTopLeft
                  color="var(--neon-green)"
                />
                Email Us
                <BorderFlairBotRight
                  color="var(--neon-green)"
                />
              </span>
            </button>
          </a>}
          {pathname.includes('/dc') && 
          <a className={[footerStyles.footer__upperCaseContent, footerStyles.footer__upperCaseContent__mobile].join(" ")} href="mailto:info@beatthebomb.com?subject=DC Request:">
            <button className={footerStyles.email_us__mobile}>
              <span>
                <BorderFlairTopLeft
                  color="var(--neon-green)"
                />
                Email Us
                <BorderFlairBotRight
                  color="var(--neon-green)"
                />
              </span>
            </button>
          </a>}
      </div>
    </footer>
  );
}

const BorderFlairTopLeft = ({
  color,
}) => {
  return (
    <svg
      class={[footerStyles.border_flair, footerStyles.border_flair__top_left].join(" ")}
      fill="none"
      height="35"
      viewBox="0 0 975 976"
      xmlns="http://www.w3.org/2000/svg"
      width="35"
    >
      <path
        clip-rule="evenodd"
        d="M800 0.00236591L800 -5.56264e-06L975 0L800.016 174.984L800.016 175.002L175 175.002L175 800.002L-4.94084e-05 975.002L9.53993e-06 800.002L0 0.00241806L0.015625 0.00241806V0.00241041L800 0.00236591Z"
        fill={color}
        fill-rule="evenodd"
      />
    </svg>
  );
}

const BorderFlairBotRight = ({
  color,
}) => {
  return (
    <svg
      class={[footerStyles.border_flair, footerStyles.border_flair__bottom_right].join(" ")}
      fill="none"
      height="35"
      viewBox="0 0 975 976"
      xmlns="http://www.w3.org/2000/svg"
      width="35"
    >
      <path
        clip-rule="evenodd"
        d="M175 975L175 975.002L0 975.002L174.984 800.018L174.984 800L800 800L800 175L975 1.07671e-05L975 175L975 975L974.984 975L974.984 975L175 975Z"
        fill={color}
        fill-rule="evenodd"
      />
    </svg>
  );
}

export default Footer;