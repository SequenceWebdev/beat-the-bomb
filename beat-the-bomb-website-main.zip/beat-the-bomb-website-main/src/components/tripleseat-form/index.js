import Tsi from "./ts-iframe";



export {
  Tsi,
};