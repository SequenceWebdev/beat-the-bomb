import React from 'react'
import styled from 'styled-components'

const VideoWrapper = styled.div`
  position: relative;
  padding-bottom: 56.25%;
  overflow: hidden;

  ._iframe {
    overflow: hidden;
    border: 0;
    align-self: center;
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
  }

  @media only screen and (max-width: 1920px){
    padding-bottom: 75%;
  }

  @media only screen and (max-width: 1600px){
    padding-bottom: 90%;
  }

  @media only screen and (max-width: 1440px){
    padding-bottom: 120%;
  }

  @media only screen and (max-width: 1024px){
    padding-bottom: 150%;
  }

  @media only screen and (max-width: 768px){
    padding-bottom: 200%;
  }
`

const iframe = ({ data }) => {
  const url = data.url;
  return (
    
    <VideoWrapper>
      <h1>{data.name}</h1>
      <iframe
        src={url}
        allowFullScreen
        frameBorder="0"
        className="_iframe"
        allow="autoplay"
        title="form">
      </iframe>
    </VideoWrapper>
  )
}

export default iframe
