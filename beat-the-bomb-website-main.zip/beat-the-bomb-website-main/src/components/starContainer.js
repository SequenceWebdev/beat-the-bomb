import React from 'react'
import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import styled from 'styled-components'

const StarContainerWrapper = styled.div`
  display: inline-flex;
  justify-content: center;
  align-items: center;

  .fullStar_img{
    width: 30px;
    aspect-ratio: 1;
  }

`

const StarContainer = ({ star }) => {
  return (
    <StarContainerWrapper>
      <GatsbyImage alt="stars" className="fullStar_img" image={getImage(star)}/>
      <GatsbyImage alt="stars" className="fullStar_img" image={getImage(star)}/>
      <GatsbyImage alt="stars" className="fullStar_img" image={getImage(star)}/>
      <GatsbyImage alt="stars" className="fullStar_img" image={getImage(star)}/>
      <GatsbyImage alt="stars" className="fullStar_img" image={getImage(star)}/>
    </StarContainerWrapper>
  )
}

export default StarContainer