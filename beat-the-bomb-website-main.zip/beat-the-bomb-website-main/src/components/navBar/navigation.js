import React, { useState, useEffect } from 'react';
// import { StaticImage } from 'gatsby-plugin-image';
import { Link } from "gatsby";

import Burger from "./burger"
// import { FaInstagram, FaTiktok } from "react-icons/fa";
import * as navigationStyles from "../styles/navigation.module.css";

//images
import btb_logo from '../../assets/images/navigation/logo-old.png';
import bk_btb_logo from '../../assets/images/navigation/btb_brooklyn_logo.png';
import v_btb_logo from '../../assets/images/navigation/btb_virtual_logo.png';
import tester from '../../assets/images/navigation/btb_brooklyn_logo.webp';
import atl_btb_logo from '../../assets/images/navigation/btb_atlanta_logo.png';
import dc_btb_logo from '../../assets/images/navigation/btb_dc_logo.png';

const Navigation = (pageContext) => {
  const {pathname} = pageContext

  const getBookElement= () =>{
    if (pathname?.includes("/atlanta")) {
      return (
        <>
        {pathname?.includes("/events") &&
        <div className={[navigationStyles.book_now__container, navigationStyles.bookNowButtonMobile, navigationStyles.planYourEventButtonMobile].join(" ")}>
          <Link className={navigationStyles.planYourEventButton} to="/tripleseat/party-request/atlanta">
            <span>
              <BorderFlairTopLeft
                color="var(--neon-green)"
              />
            Plan Your Event
              <BorderFlairBotRight
                color="var(--neon-green)"
              />
          </span>
          </Link>
        </div>
        }
        {!pathname?.includes("/events") &&
        <div className={[navigationStyles.book_now__container, navigationStyles.bookNowButtonMobile, navigationStyles.bookNowButtonMobileAtlanta].join(" ")}>
          <div className="xola-checkout xola-custom" data-button-id="63091d3e30d8544279111238">
            {/* <span className={[navigationStyles.bookNowButtonMobile, navigationStyles.bookNowButtonMobileAtlanta].join(" ")}>Book Now</span> */}
            <span>
                <BorderFlairTopLeft
                  color="var(--neon-pink)"
                />
              Book Now
                <BorderFlairBotRight
                  color="var(--neon-pink)"
                />
              
            </span>
          </div>
        </div>}
        </>
      );
    } else if (pathname?.includes("/brooklyn")) {
      return (
        <>
        {!pathname?.includes("/events") &&
        <div className={[navigationStyles.book_now__container, navigationStyles.bookNowButtonMobile, navigationStyles.bookNowButtonMobileBrooklyn].join(" ")}>
          <div className="xola-checkout xola-custom" data-button-id="6308d7e950cfe36e325c1cdd">
            <span>
                <BorderFlairTopLeft
                  color="var(--neon-blue)"
                />
              Book Now
                <BorderFlairBotRight
                  color="var(--neon-blue)"
                />
            </span>
          </div>
        </div>}
        {pathname?.includes("/events") &&
        <div className={[navigationStyles.book_now__container, navigationStyles.bookNowButtonMobile, navigationStyles.planYourEventButtonMobile].join(" ")}>
          <Link className={navigationStyles.planYourEventButton} to="/tripleseat/party-request/brooklyn">
            <span>
              <BorderFlairTopLeft
                color="var(--neon-green)"
              />
            Plan Your Event
              <BorderFlairBotRight
                color="var(--neon-green)"
              />
          </span>
          </Link>
        </div>
        }
        </>
      );
    } else if(pathname?.includes("/virtual")) {
      return (
        <div className={[navigationStyles.book_now__container, navigationStyles.bookNowButtonMobile, navigationStyles.bookNowButtonMobileDc].join(" ")}>
          <div className="xola-checkout xola-custom" data-button-id="629f6ddc4ac30137d8100347">
            {/* <span className={[navigationStyles.bookNowButtonMobile].join(" ")}>Book Now</span> */}
            <span>
                <BorderFlairTopLeft
                  color="var(--neon-green)"
                />
              Book Now
                <BorderFlairBotRight
                  color="var(--neon-green)"
                />
            </span>
          </div>
        </div>
      );
    } else if (pathname?.includes("/dc")) {
      return (
        <>
        {pathname?.includes("/events") &&
        <div className={[navigationStyles.book_now__container, navigationStyles.bookNowButtonMobile, navigationStyles.planYourEventButtonMobile].join(" ")}>
          <Link className={navigationStyles.planYourEventButton} to="/tripleseat/party-request/dc">
            <span>
              <BorderFlairTopLeft
                color="var(--neon-green)"
              />
            Plan Your Event
              <BorderFlairBotRight
                color="var(--neon-green)"
              />
          </span>
          </Link>
        </div>
        }
        {!pathname?.includes("/events") &&
        <div className={[navigationStyles.book_now__container, navigationStyles.bookNowButtonMobile, navigationStyles.bookNowButtonMobileDc].join(" ")}>
          <div className="xola-checkout xola-custom" data-button-id="63a621eb06bdc8511b3e6b5f">
            {/* <span className={[navigationStyles.bookNowButtonMobile, navigationStyles.bookNowButtonMobileDc].join(" ")}>Book Now</span> */}
            <span>
                <BorderFlairTopLeft
                  color="var(--neon-green)"
                />
              Book Now
                <BorderFlairBotRight
                  color="var(--neon-green)"
                />
            </span>
          </div>
        </div>}
        </>
      );
    } else {
      return (
        <div className={[navigationStyles.bookDropDownContainer, navigationStyles.bookNowButtonMobile].join(" ")}>
          {/* <span className={navigationStyles.bookNowButtonMobile}>Book Tickets</span> */}
          <span>
              <BorderFlairTopLeft
                color="var(--neon-green)"
              />
            Book Now
              <BorderFlairBotRight
                color="var(--neon-green)"
              />
          </span>
          <ul style={{"width":"100%"}} className={navigationStyles.bookDropDown}>
            <li class={[navigationStyles.book_now__container, navigationStyles.bookNowButtonMobile, navigationStyles.bookNowButtonMobileBrooklyn].join(" ")}>
              <div className="xola-checkout xola-custom" data-button-id="6308d7e950cfe36e325c1cdd">
                {/* <span className={[navigationStyles.bookNowButtonMobile, navigationStyles.bookNowBlue].join(" ")}>Brooklyn</span> */}
                <span>
                    <BorderFlairTopLeft
                      color="var(--neon-blue)"
                    />
                  Brooklyn
                    <BorderFlairBotRight
                      color="var(--neon-blue)"
                    />
                </span>
              </div>
            </li>
            <li class={[navigationStyles.book_now__container, navigationStyles.bookNowButtonMobile, navigationStyles.bookNowButtonMobileAtlanta].join(" ")}>
              <div className="xola-checkout xola-custom" data-button-id="63091d3e30d8544279111238">
                {/* <span className={[navigationStyles.bookNowButtonMobile, navigationStyles.bookNowRed].join(" ")}>Atlanta</span> */}
                <span>
                    <BorderFlairTopLeft
                      color="var(--neon-pink)"
                    />
                  Atlanta
                    <BorderFlairBotRight
                      color="var(--neon-pink)"
                    />
                </span>
              </div>
            </li>
            <li class={[navigationStyles.book_now__container, navigationStyles.bookNowButtonMobile, navigationStyles.bookNowButtonMobileDc].join(" ")}>
              <div className="xola-checkout xola-custom" data-button-id="63a621eb06bdc8511b3e6b5f">
                {/* <span className={[navigationStyles.bookNowButtonMobile, navigationStyles.bookNowGreen].join(" ")}>DC</span> */}
                <span>
                    <BorderFlairTopLeft
                      color="var(--neon-green)"
                    />
                  DC
                    <BorderFlairBotRight
                      color="var(--neon-green)"
                    />
                </span>
              </div>
            </li>
          </ul>
        </div>
      );
    }
  }

  const [isClient, setClient] = useState(false);
  const key = isClient ? "client" : "server";

  useEffect(() => {
    // this.setState({pathname: this.props.pathname});
    setClient(true);
    // if(pathname?.includes("/dc")){
    //   const sign_up_section = document.querySelector(".background__container");
    //   sign_up_section.setAttribute('id', 'first-sign-up');
    // }
  },);

    if ( !isClient ) return null;
    return (
      <nav className={navigationStyles.outerNavbar}>
      <div key={key} id="navigation_bar" className={navigationStyles.navbar}>
        <div className={navigationStyles.navbar__logo}>
          { (
            !(pathname?.includes("/brooklyn") ||
            pathname?.includes("/atlanta") ||
            pathname?.includes("/dc") ||
            pathname?.includes("/virtual"))
          )&&
            <Link to="/"><img alt="generic-logo-img" className={navigationStyles.navbar__logoImg} src={btb_logo}/></Link>
          }
          { pathname?.includes("/virtual") &&
            <Link to="/virtual"><img alt="virtual-logo-img" className={navigationStyles.navbar__logoImg} src={v_btb_logo}/></Link>
          }
          { pathname?.includes("/brooklyn") &&
            <Link to="/brooklyn"><img alt="bk-logo-img" className={navigationStyles.navbar__logoImg} src={tester}/></Link>
          }
          { pathname?.includes("/atlanta") &&
            <Link to="/atlanta"><img alt="atl-logo-img" className={navigationStyles.navbar__logoImg} src={atl_btb_logo}/></Link>
          }
          { pathname?.includes("/dc") &&
            <Link to="/dc"><img alt="dc-logo-img" className={navigationStyles.navbar__logoImg} src={dc_btb_logo}/></Link>
          }
          {getBookElement()}
        </div>
        <div className={navigationStyles.navbar__rightSide}>
          {/* {this.getBookElement()} */}
          <Burger pathname={pathname}/>
        </div>
      </div>
      </nav>
    )
}

const BorderFlairTopLeft = ({
  color,
}) => {
  return (
    <svg
      class={[navigationStyles.border_flair, navigationStyles.border_flair__top_left].join(" ")}
      fill="none"
      height="35"
      viewBox="0 0 975 976"
      xmlns="http://www.w3.org/2000/svg"
      width="35"
    >
      <path
        clip-rule="evenodd"
        d="M800 0.00236591L800 -5.56264e-06L975 0L800.016 174.984L800.016 175.002L175 175.002L175 800.002L-4.94084e-05 975.002L9.53993e-06 800.002L0 0.00241806L0.015625 0.00241806V0.00241041L800 0.00236591Z"
        fill={color}
        fill-rule="evenodd"
      />
    </svg>
  );
}

const BorderFlairBotRight = ({
  color,
}) => {
  return (
    <svg
      class={[navigationStyles.border_flair, navigationStyles.border_flair__bottom_right].join(" ")}
      fill="none"
      height="35"
      viewBox="0 0 975 976"
      xmlns="http://www.w3.org/2000/svg"
      width="35"
    >
      <path
        clip-rule="evenodd"
        d="M175 975L175 975.002L0 975.002L174.984 800.018L174.984 800L800 800L800 175L975 1.07671e-05L975 175L975 975L974.984 975L974.984 975L175 975Z"
        fill={color}
        fill-rule="evenodd"
      />
    </svg>
  );
}

export default Navigation;
