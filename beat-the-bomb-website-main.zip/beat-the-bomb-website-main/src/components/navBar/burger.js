// React
import React, { useState, useEffect, useRef } from 'react'
//Plugins
import styled from 'styled-components'
import { Link, graphql, useStaticQuery } from "gatsby";
//Components
// import NavLinks from "./navLinks"

/////////////////////////////////////////////////////
import 'react-responsive-modal/styles.css';
import '../styles/modal.css'
import { Modal } from 'react-responsive-modal';
import { GatsbyImage, getImage } from 'gatsby-plugin-image';
import { AiOutlineClose } from 'react-icons/ai'
/////////////////////////////////////////////////////

const BurgerWrapper = styled.div`
  width: 2rem;
  height: 2rem;
  /* position: fixed;
  right: 20px; */
  display:flex;
  flex-flow: column nowrap;
  justify-content: space-around;
  z-index: 99;
  position: relative;
  cursor: pointer;

  .hamburger__line{
    background-color: white;
    width: 2rem;
    height: 0.25rem;
    border-radius: 10px;
    transform-origin: 1px;
    transition: all 0.3s;


    &:first-child{
      transform: ${({open}) => open ? "rotate(45deg)":"rotate(0)"};
    }
    &:nth-child(2){
      transform: ${({open}) => open ? "translateX(100%)":"translateX(0)"};
      opacity: ${({open}) => open ? 0 : 1};
    }
    &:last-child{
      transform: ${({open}) => open ? "rotate(-45deg)":"rotate(0)"};
    }
  }

`

const NavLinksWrapper = styled.ul`
  list-style: none;
  display: flex;
  flex-flow: column nowrap;
  align-items: flex-start;
  background-color: black;
  position: fixed;
  top: 0;
  right: -50%;
  height: 100vh;
  width: 100%;
  padding-top: 3.5rem;
  transform: ${({ open }) => open ? "translateX(0)" : "translateX(100%)"};
  transition: 0.3s ease-in-out;
  z-index: 90;
  overflow-y: scroll;

  & li {
    margin: 0.5rem 0;
    /* text-transform: uppercase; */
    letter-spacing: 1px;
  }

  .navbar__link {
    background-color: black;
    border: none;
    color: white;
    font-family: 'Acumin-Bold', sans-serif;
    font-size: 32px;
    padding: 3px 0;
    position: relative;
    text-decoration: none;
    text-transform: uppercase;

    &::after,
    &::before {
      background-color: currentColor;
      content: "";
      height: 2px;
      left: 0;
      margin-top: -7px;
      position: absolute;
      transform: scaleX(0);
      transition: transform .5s;
      width: 100%;

    }

    &::before{
      top: 0;
      transform-origin: left;
    }

    &::after{
      bottom: 0;
      transform-origin: right;
    }

    &.active::after,
    &.active::before,
    &:hover::after,
    &:hover::before {
      transform: scaleX(1);
    }

    &--atlanta { color: var(--neon-pink); }
    &--brooklyn { color: var(--neon-blue); }
    &--dc { color: var(--neon-green); }
  }

  @media only screen and (max-width: 900px) {
    width: 110%;

    .navbar__link{
      font-size: 30px;
    }
  }

  @media only screen and (max-width: 600px) {
    width: 125%;
  }

  @media only screen and (max-width: 500px) {
    /* width: 65vw; */
    .navbar__link{
      font-size: 25px;
    }
  }

  @media only screen and (max-width: 320px) {
    .navbar__link{
      font-size: 20px;
    }
  }

`

const Burger = ({ pathname }) => {
  const [open, setOpen] = useState(false);

  const { allContentfulAsset } = useStaticQuery(graphql`
    query {
      allContentfulAsset(filter: {title: {regex: "/Menu/"}}) {
        nodes {
          gatsbyImageData(placeholder: BLURRED)
          title
        }
      }
    }
  `);

  const locationAbbrv = () => {
    if(pathname.includes("/atlanta")){
      return "ATL";
    }else if(pathname.includes("/brooklyn")){
      return "BK";
    }else if(pathname.includes("/dc")){
      return "DC";
    }
  }

  const getMenuAssets = () =>{
    const menuItems = []
     allContentfulAsset.nodes.map((image)=>{
      if(image.title.includes(locationAbbrv())){
        menuItems.push(image);
      }
    })

    return menuItems;
  };

  const menuAssets = getMenuAssets();

  //////////////////////////////////////////////////
  const [modalOpen, setModalOpen] = useState(false);

  const onOpenModal = () => {
    setModalOpen(true)
    setOpen(!open)
  }
  const onCloseModal = () => setModalOpen(false);
  const closeIcon = (<AiOutlineClose className="close_icon" color='white' />);

  let sideMenuRef = useRef();

  useEffect(() => {
    let handler = (event) => {
      if (!sideMenuRef.current.contains(event.target)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handler);
    return () => {
      document.removeEventListener("mousedown", handler);
    }
  });

  return (
    <div ref={sideMenuRef}>
      <BurgerWrapper open={open} onClick={() => setOpen((open) => !open)}>
        <div className="hamburger__line"></div>
        <div className="hamburger__line"></div>
        <div className="hamburger__line"></div>
      </BurgerWrapper>
      <NavLinksWrapper open={open}>
        <li><Link activeClassName="active" className="navbar__link" onClick={() => setOpen(!open)} to="/">Home</Link></li>
        <li><Link activeClassName="active" className="navbar__link navbar__link--brooklyn" onClick={() => setOpen(!open)} to="/brooklyn">Brooklyn</Link></li>
        {pathname.includes('/brooklyn') && 
        <>
        <li style={{"marginLeft":"1rem"}}>
          <Link className="navbar__link" to="/events/brooklyn">Special Events 13+ People</Link>
        </li>
        <li style={{"marginLeft":"1rem"}}>
          <Link className="navbar__link" to="/brooklyn-menu">Bar Menu</Link>
        </li>
        </>}
        <li><Link activeClassName="active" className="navbar__link navbar__link--atlanta" onClick={() => setOpen(!open)} to="/atlanta">Atlanta</Link></li>
        {pathname.includes('atlanta') && 
        <>
        <li style={{"marginLeft":"1rem"}}>
          <Link className="navbar__link" to="/events/atlanta">Special Events 13+ People</Link>
        </li>
        <li style={{"marginLeft":"1rem"}}>
          <Link className="navbar__link" to="/atlanta-menu">Bar Menu</Link>
        </li>
        </>}
        <li><Link activeClassName="active" className="navbar__link navbar__link--dc" onClick={() => setOpen(!open)} to="/dc">Washington DC</Link></li>
        {pathname.includes('/dc') && 
        <>
        <li style={{"marginLeft":"1rem"}}> 
          <Link className="navbar__link" to="/events/dc">Special Events 13+ People</Link>
        </li>
        <li style={{"marginLeft":"1rem"}}>
          <Link className="navbar__link" to="/dc-menu">Bar Menu</Link>
        </li>
        </>}
        <li><Link activeClassName="active" className="navbar__link" onClick={() => setOpen(!open)} to="/virtual">Virtual Team Building</Link></li>
        {!pathname.includes('/brooklyn') && !pathname.includes('/dc') && !pathname.includes('/atlanta') && pathname !== "/mission-02" && pathname !== "/game-bay" && <li><Link activeClassName="active" className="navbar__link" onClick={() => setOpen(!open)} to="/mission-01">Games</Link></li>}
        {!pathname.includes('/brooklyn') && !pathname.includes('/dc') && !pathname.includes('/atlanta') && pathname === "/mission-02" && <li><Link activeClassName="active" className="navbar__link" onClick={() => setOpen(!open)} to="/mission-02">Games</Link></li>}
        {!pathname.includes('/brooklyn') && !pathname.includes('/dc') && !pathname.includes('/atlanta') && pathname === "/game-bay" && <li><Link activeClassName="active" className="navbar__link" onClick={() => setOpen(!open)} to="/game-bay">Games</Link></li>}

        {pathname.includes('/brooklyn') && pathname !== "/brooklyn/mission-02" && pathname !== "/brooklyn/game-bay" && <li><Link activeClassName="active" className="navbar__link" onClick={() => setOpen(!open)} to="/brooklyn/mission-01">Games</Link></li>}
        {pathname.includes('/brooklyn/mission-02') && <li><Link activeClassName="active" className="navbar__link" onClick={() => setOpen(!open)} to="/brooklyn/mission-02">Games</Link></li>}
        {pathname.includes('/brooklyn/game-bay') && <li><Link activeClassName="active" className="navbar__link" onClick={() => setOpen(!open)} to="/brooklyn/game-bay">Games</Link></li>}

        {pathname.includes('/atlanta') && pathname !== "/atlanta/mission-02" && pathname !== "/atlanta/game-bay" && <li><Link activeClassName="active" className="navbar__link" onClick={() => setOpen(!open)} to="/atlanta/mission-01">Games</Link></li>}
        {pathname.includes('/atlanta/mission-02') && <li><Link activeClassName="active" className="navbar__link" onClick={() => setOpen(!open)} to="/atlanta/mission-02">Games</Link></li>}
        {pathname.includes('/atlanta/game-bay') && <li><Link activeClassName="active" className="navbar__link" onClick={() => setOpen(!open)} to="/atlanta/game-bay">Games</Link></li>}

        {pathname.includes('/dc') && pathname !== "/dc/mission-02" && pathname !== "/dc/game-bay" && <li><Link activeClassName="active" className="navbar__link" onClick={() => setOpen(!open)} to="/dc/mission-01">Games</Link></li>}
        {pathname.includes('/dc/mission-02') && <li><Link activeClassName="active" className="navbar__link" onClick={() => setOpen(!open)} to="/dc/mission-02">Games</Link></li>}
        {pathname.includes('/dc/game-bay') && <li><Link activeClassName="active" className="navbar__link" onClick={() => setOpen(!open)} to="/dc/game-bay">Games</Link></li>}
        {/* <li><Link activeClassName="active" className="navbar__link" to="/videos">Videos</Link></li> */}
        <li><Link activeClassName="active" className="navbar__link" onClick={() => setOpen(!open)} to="/leaderboards">Leaderboards</Link></li>
        {pathname === '/brooklyn' && <li><a
          activeClassName="active"
          href="#"
          className="navbar__link"
          onClick={(e) => {
            e.preventDefault();
            setOpen(!open)
            document.getElementById("brooklyn-gift").click()
          }}
        >
          Gift Cards
        </a>
        </li>}
        {pathname === '/atlanta' && <li>
          <a
            activeClassName="active"
            href="#"
            className="navbar__link"
            onClick={(e) => {
              e.preventDefault();
              setOpen(!open)
              document.getElementById("atlanta-gift").click()
            }}
          >
            Gift Cards
          </a>
        </li>}
        {pathname === '/dc' && <li>
          <a
            activeClassName="active"
            href="#"
            className="navbar__link"
            onClick={(e) => {
              e.preventDefault();
              setOpen(!open)
              document.getElementById("dc-gift").click()
            }}
          >
            Gift Cards
          </a>
        </li>}
        <li><Link activeClassName="active" className="navbar__link" onClick={() => setOpen(!open)} to="/faq">FAQ</Link></li>
        <li><a activeClassName="active" className="navbar__link" onClick={() => setOpen(!open)} href="https://www.applicantpro.com/openings/beatthebomb/jobs">Careers</a></li>
        {pathname === '/brooklyn' && <li><a

          style={{ "display": "none" }}
          id="brooklyn-gift"
          className="navbar__link"
          href="https://gift-ui.xola.com/#?button=5f62447fe30c717270258e4f&_=1665263596636&openExternal=true"
        >
          Gift Cards
        </a>
        </li>}
        {pathname === '/atlanta' && <li>
          <a
            style={{ "display": "none" }}
            id="atlanta-gift"
            className="navbar__link"
            href="https://gift-ui.xola.com/#?button=631f65e0bea41a4ee53178c0&_=1663003364400"
          >
            Gift Cards
          </a>
        </li>}
        {pathname === '/dc' && <li>
          <a
            style={{ "display": "none" }}
            id="dc-gift"
            className="navbar__link"
            href="https://gift-ui.xola.com/#?button=643d5abc08799e79961f5e54&_=1681742528443&openExternal=true"
          >
            Gift Cards
          </a>
        </li>}

        <Modal
          open={modalOpen}
          onClose={onCloseModal}
          center
          showCloseIcon
          classNames={{
            overlay: 'customOverlay',
            modal: 'customModal',
          }}
          closeIcon={closeIcon}
        >
          {menuAssets.length !== 0 && <div className="menu_modal">
            <div className="food_menu__container">
              <GatsbyImage className="menu_img" alt='food_menu' image={getImage(menuAssets[0]?.gatsbyImageData)} />
            </div>
            <div className="drink_menu__container">
              <GatsbyImage className="menu_img" alt='food_menu' image={getImage(menuAssets[1]?.gatsbyImageData)} />
            </div>
          </div>}

          {menuAssets.length === 0 && <div className="menu_modal">
            <h2 style={{"padding":"1rem"}}>Something delicious is coming!</h2>
          </div>}

        </Modal>
      </NavLinksWrapper>
    </div>
  )
}

export default Burger;
