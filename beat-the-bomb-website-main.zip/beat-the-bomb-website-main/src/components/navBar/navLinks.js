////////////////////////////////////////////
//                                        //
//     Currently Not Using this file      //
//                                        //
////////////////////////////////////////////


// //React
// import React, {useState, useEffect} from 'react'
// import { Link, graphql, useStaticQuery } from "gatsby";
// //Plugins
// import styled from "styled-components"
// // import * as Fa from "react-icons/fa"

// /////////////////////////////////////////////////////
// import 'react-responsive-modal/styles.css';
// import '../styles/modal.css'
// import { Modal } from 'react-responsive-modal';
// import { GatsbyImage, getImage } from 'gatsby-plugin-image';
// import {AiOutlineClose} from 'react-icons/ai'
// /////////////////////////////////////////////////////


// const NavLinksWrapper = styled.ul`
//   list-style: none;
//   display: flex;
//   flex-flow: column nowrap;
//   align-items: flex-start;
//   background-color: black;
//   position: fixed;
//   top: 0;
//   right: 0;
//   height: 100vh;
//   width: 35vw;
//   padding-top: 3.5rem;
//   transform: ${({test})=> test ? "translateX(0)" : "translateX(100%)"};
//   transition: 0.3s ease-in-out;
//   z-index: 90;
//   overflow-y: scroll;

//   & li{
//     margin: 0.5rem 0;
//     /* text-transform: uppercase; */
//     letter-spacing: 1px;
//   }

//   .navbar__link{
//     text-decoration: none;
//     text-transform: uppercase;
//     color: white;
//     position: relative;
//     padding: 3px 0;
//     font-family: 'Acumin-Bold', sans-serif;
// 	  font-size: 32px;
//     border: none;
//     background-color: black;

//     &::before,&::after{
//       content: "";
//       width:100%;
//       height: 2px;
//       margin-top:-7px;
//       background-color: var(--neon-blue);
//       position: absolute;
//       left: 0;
//       transform: scaleX(0);
//       transition: transform .5s;

//     }

//     &::before{
//       top: 0;
//       transform-origin: left;
//     }

//     &::after{
//       bottom: 0;
//       transform-origin: right;
//     }

//     &:hover::before, &:hover::after{
//       transform: scaleX(1);
//     }

//   }

//   .active{
//     color: var(--neon-pink);
//   }

//   @media only screen and (max-width: 900px) {
//     width: 45vw;
//     .navbar__link{
//       font-size: 30px;
//     }
//   }

//   @media only screen and (max-width: 600px) {
//     width: 55vw;
//   }

//   @media only screen and (max-width: 500px) {
//     width: 65vw;
//     .navbar__link{
//       font-size: 25px;
//     }
//   }

//   @media only screen and (max-width: 320px) {
//     .navbar__link{
//       font-size: 20px;
//     }
//   }
  
// `

// const NavLinks = ({open, pathname}) => {


//   const { allContentfulAsset } = useStaticQuery(graphql`
//     query {
//       allContentfulAsset(filter: {title: {regex: "/^ATL/"}}) {
//         nodes {
//           gatsbyImageData
//         }
//       }
//     }
//   `);

//   const menuAssets = allContentfulAsset.nodes;
//   //////////////////////////////////////////////////
//   const [modalOpen, setModalOpen] = useState(false);

//   const onOpenModal = () => setModalOpen(true);
//   const onCloseModal = () => setModalOpen(false);

//   const closeIcon = (<AiOutlineClose className="close_icon" color='white'/>);

//   const [currPagePath, setCurrPagePath] = useState(pathname);
//   const [sideMenuOpen, setSideMenuOpen] = useState(open);

//   useEffect(() => {
//     setCurrPagePath(pathname);
//     setSideMenuOpen(open);
//   },[pathname, open]);
//   //////////////////////////////////////////////////
//   return (
//     <NavLinksWrapper test={open}>
//       <li><Link activeClassName="active" className="navbar__link" to="/">Home</Link></li>
//       <li><Link activeClassName="active" className="navbar__link" onClick={()=>setSideMenuOpen(!sideMenuOpen)} to="/brooklyn/">Brooklyn</Link></li>
//       <li><Link activeClassName="active" className="navbar__link" to="/atlanta/">Atlanta - Now Open</Link></li>
//       {currPagePath==='/atlanta' &&<li>   
//           <button
//             style={{"cursor":"pointer"}}
//             className="navbar__link"
//             onClick={onOpenModal}  
//           >
//             Menu
//           </button>
//       </li>}
//       <li><Link activeClassName="active" className="navbar__link" to="/dc/">DC - Coming Soon!</Link></li>
//       <li><Link activeClassName="active" className="navbar__link" to="/virtual/">Virtual Team Building</Link></li>
//       <li><Link activeClassName="active" className="navbar__link" to="/learn-more/mission-01/">Games</Link></li>
//       {/* <li><Link activeClassName="active" className="navbar__link" to="/videos">Videos</Link></li> */}
//       <li><Link activeClassName="active" className="navbar__link" to="/leaderboards">Leaderboards</Link></li>
//       {currPagePath==='/brooklyn' && <li><a
//             activeClassName="active"
//             className="navbar__link"
//             href="https://gift-ui.xola.com/#?button=5f62447fe30c717270258e4f&_=1665263596636&openExternal=true"
            
//           >
//             Gift Cards
//           </a>
//       </li>}
//       {currPagePath==='/atlanta' &&<li>   
//           <a
//             activeClassName="active"
//             className="navbar__link"
//             href="https://gift-ui.xola.com/#?button=631f65e0bea41a4ee53178c0&_=1663003364400"
            
//           >
//             Gift Cards
//           </a>
//       </li>}
//       <li><Link activeClassName="active" className="navbar__link" to="/faq">FAQ</Link></li>
//       <li><a activeClassName="active" className="navbar__link" href="https://www.applicantpro.com/openings/beatthebomb/jobs">Careers</a></li>


//       <Modal 
//         open={modalOpen} 
//         onClose={onCloseModal} 
//         center 
//         showCloseIcon 
//         classNames={{
//           overlay: 'customOverlay',
//           modal: 'customModal',
//         }}
//         closeIcon={closeIcon}
//       >
//         <div className="menu_modal">
//           <div className="food_menu__container">
//             <GatsbyImage className="menu_img" alt='food_menu' image={getImage(menuAssets[0].gatsbyImageData)}/>
//           </div>
//           <div className="drink_menu__container">
//             <GatsbyImage className="menu_img" alt='food_menu' image={getImage(menuAssets[1].gatsbyImageData)}/>
//           </div>  
//         </div>
//       </Modal>
//     </NavLinksWrapper>
//   )
// }

// export default NavLinks;

