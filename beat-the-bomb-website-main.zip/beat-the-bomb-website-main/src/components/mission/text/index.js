import React from 'react'
import styled from 'styled-components'
import { documentToReactComponents } from '@contentful/rich-text-react-renderer'
import { BLOCKS, MARKS } from '@contentful/rich-text-types'

const RichTextWrapper = styled.div`
  max-width: 1440px;
  position: relative;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  justify-content: center;

`

const RichTextContainer = styled.div`
  margin-left: auto;
  margin-right: auto;
  padding: 0 3rem;

  @media only screen and (max-width: 768px){
    padding: 0 2rem;
  }

  @media only screen and (max-width: 500px){
    padding: 0 1rem;
  }

  .rich_paragraph{
    font-family: "Acumin Pro";
    font-style: normal;
    font-weight: ${({fontWeight}) => `${fontWeight}`};
    font-size: ${({fontSize}) => `${fontSize}px`};
    line-height: 125%;
    color: #ffffff;
    margin-top: 3.5rem;
    margin-bottom: 0rem;
    text-transform: ${({textTransform}) => `${textTransform}`.toLowerCase()};
    text-align:${({textAlignment}) => `${textAlignment}`};

    @media only screen and (max-width: 768px){
      font-size: 25px;
      text-align: center;
      margin-top: 2.5rem;
    }

    @media only screen and (max-width: 500px){
      font-size: 18px;
    }
  }

  .rich_h1{
    font-family: 'Acumin Pro';
    font-style: normal;
    font-weight: 700;
    font-size: 100px;
    line-height: 119%;
    text-align:${({textAlignment}) => `${textAlignment}`};
    letter-spacing: 0;
    text-transform: ${({textTransform}) => `${textTransform}`.toLowerCase()};
    margin-top: 3.5rem;
    color: #ffffff;

    @media screen and (max-width: 1250px) {
      font-size: 80px;
    }

    @media screen and (max-width: 1024px) {
      font-size: 60px;
    }

    @media screen and (max-width: 768px) {
      font-size: 45px;
    }

    @media screen and (max-width: 500px) {
      font-size: 32px;
    }
  }

  .rich_h2{
    font-family: "Acumin Pro";
    font-style: normal;
    font-weight: ${({fontWeight}) => `${fontWeight}`};
    font-size: ${({fontSize}) => `${fontSize}px`};
    line-height: 125%;
    color: #ffffff;
    margin-top: 3.5rem;
    margin-bottom: 0rem;
    text-transform: ${({textTransform}) => `${textTransform}`.toLowerCase()};
    text-align:${({textAlignment}) => `${textAlignment}`};

    @media only screen and (max-width: 1024px){
      font-size: 50px;
    }

    @media only screen and (max-width: 768px){
      font-size: 42px;
      text-align: center;
    }

    @media only screen and (max-width: 500px){
      font-size: 30px;
    }
  }

  .rich_h3{
    font-family: 'Acumin Pro';
    font-style: normal;
    font-weight: 700;
    font-size: 50px;
    line-height: 140%;
    text-align:${({textAlignment}) => `${textAlignment}`};
    letter-spacing: 0;
    text-transform: ${({textTransform}) => `${textTransform}`.toLowerCase()};
    margin-top: 3.5rem;
    color: #ffffff;

    @media screen and (max-width: 1250px) {
      font-size: 32px;
    }

    @media screen and (max-width: 1024px) {
      font-size: 25px;
    }

    @media screen and (max-width: 768px) {
      font-size: 20px;
    }
  }

  @media only screen and (max-width: 768px){
    width: 90%;
  }
`

const RICHTEXT_OPTIONS = {
  renderMark: {
    [MARKS.BOLD]: text => <strong className='questions'>{text}<br></br></strong>,
  },
  renderNode: {
    [BLOCKS.HEADING_1]: (node, children) =>{
      return children!='' && (<h1 className='rich_h1'>{children}</h1>)
    },
    [BLOCKS.HEADING_2]: (node, children) =>{
      return children!='' && (<h2 className='rich_h2'>{children}</h2>)
    },
    [BLOCKS.HEADING_3]: (node, children) =>{
      return children!='' && (<h3 className='rich_h3'>{children}</h3>)
    },
    [BLOCKS.PARAGRAPH]: (node, children) =>{
      return children!='' && (<p className='rich_paragraph'>{children}</p>)
    },
  }
}

const Text = ({ data }) => {
  const { textAlignment, richText, font, fontSize, fontWeight, topMargin, textTransform } = data
  const json_text = JSON.parse(richText.raw)
  return (
    <RichTextWrapper>
      <RichTextContainer font={font} fontSize={fontSize} textAlignment={textAlignment} fontWeight={fontWeight} topMargin={topMargin} textTransform={textTransform}>
        {documentToReactComponents(json_text, RICHTEXT_OPTIONS)}
      </RichTextContainer>
    </RichTextWrapper>
  )
}

export default Text