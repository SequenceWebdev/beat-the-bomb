import React, {useState} from 'react'
import styled from 'styled-components'
import { Locations } from '../../home-new';

import 'react-responsive-modal/styles.css';
import '../../styles/modal.css'
import { Modal } from 'react-responsive-modal';

import {AiOutlineClose} from 'react-icons/ai'

const ButtonWrapper = styled.div`
  max-width: 1440px;
  position: relative;
  left: 50%;
  transform: translateX(-50%);

  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  margin-top: 5rem;

  button:hover{
    background-color: ${({textColor}) => `${textColor}`};
    color: ${({buttonColor}) => `${buttonColor}`};
    border-color: ${({buttonColor}) => `${buttonColor}`};
  }

  button{
    background-color: ${({buttonColor}) => `${buttonColor}`};
    color: ${({textColor}) => `${textColor}`};
    border-color: ${({borderColor}) => `${borderColor}`};
    font-family: 'Pixel';
    font-style: normal;
    font-weight: 400;
    font-size: 48px;
    line-height: 117%;
    text-align: center;
    width: 27%;
    min-width: 391px;

    @media only screen and (max-width: 1250px){
      font-size: 40px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 35px;
      
    }

    @media only screen and (max-width: 900px){
      width: 100%;
      font-size: 30px;
      min-width: 325px;
      max-width: 325px;
    }

    @media only screen and (max-width: 768px){
      min-width: 300px;
      max-width: 300px;
    }

    @media only screen and (max-width: 500px){
      min-width: 240px;
      font-size: 24px;
      max-width: 240px;
    }
  }

  @media only screen and (max-width: 500px){
    margin-top: 3rem;
  }

`

const Button = ({ data }) => {
  const { borderColor, type, buttonColor, buttonText, textColor, locations } = data.button
  const colors ={
    "Black":"#000000",
    "Blue": "var(--neon-blue)",
    "Pink": "var(--neon-pink)",
    "Yellow": "var(--neon-yellow)",
    "Green": "var(--neon-green)",
    "White": "#FFFFFF",
  }

  const [open, setOpen] = useState(false);

  const onOpenModal = () => setOpen(true);
  const onCloseModal = () => setOpen(false);

  const closeIcon = (<AiOutlineClose color='white' size={36} />);
  return (
    <ButtonWrapper borderColor={colors[borderColor]} buttonColor={colors[buttonColor]} textColor={colors[textColor]}>
      {type.toLowerCase() !=='pop-up' && <button>{buttonText}</button>}

      {type.toLowerCase()==='pop-up' && <>
      <button onClick={onOpenModal}> {buttonText} </button>
      <Modal 
      open={open} 
      onClose={onCloseModal} 
      center 
      showCloseIcon 
      classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      closeIcon={closeIcon}>
        <Locations data={locations}/>
      </Modal></>}
    </ButtonWrapper>
  )
}

export default Button