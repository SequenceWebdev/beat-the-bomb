import React from 'react'
import styled from 'styled-components'
import { GatsbyImage, getImage } from 'gatsby-plugin-image'

const GameCardWrapper = styled.div`
  max-width: 1440px;
  position: relative;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 3rem;
  margin-top: 2rem;

  @media only screen and (max-width: 768px){
    padding: 0 2rem;
  }

  @media only screen and (max-width: 500px){
    padding: 0 1rem;
  }

`
const GameInfo = styled.div`
  display:flex;
  width:100%;
  justify-content: space-around;
  align-items: center;
  column-gap: 25px;

  .leftCol{
    display:flex;
    width: 50%;
    align-items: center;
    flex-direction: column;

    & .game_description {
      font-family: 'Acumin Pro';
      font-style: normal;
      font-weight: 400;
      font-size: 32px;
      line-height: 125%;
      /* or 40px */
      color: #ffffff;
      text-align: left;
      padding:0;

      @media only screen and (max-width: 1250px) {
        font-size: 25px;
      }

      @media only screen and (max-width: 1024px) {
        font-size: 20px;
      }

      @media only screen and (max-width: 500px) {
        font-size: 15px;
        line-height: 18px;
      }
    }
  }

  .rightCol{
    width:50%;
    display:flex;
    align-items: center;
    justify-content: center;
  }

  .video__container{
    width: 50%;

    @media only screen and (max-width: 768px){
      width: 100%;
    }
  }

  .video__container video{
    width: 100%;
  }


  @media screen and (max-width: 768px){
    flex-direction: column;

    .leftCol{
      order:2;
      width: 100%;
      margin-bottom: 2rem;
      flex-direction: row;
      margin-top: 2rem;

      .leftCol_image{
        width: 40%;
      }

      & .game_description{
        width: 60%;
        margin:0;
        text-align: center;
      }
    }

    .rightCol{
      width:100%;
    }
  }

  @media only screen and (max-width: 500px){
    .leftCol{
      flex-direction: column;

      .leftCol_image{
        margin-bottom: 1rem;
      }

      & .game_description{
        width: 100%;
        text-align: center;
      }
    }
  }
`



const GameCard = ({ data }) => {
  const { gameDescription, rightImage, topLeftImage, video } = data
  return (
    <GameCardWrapper>
      <GameInfo>
        <div className="leftCol">
          <GatsbyImage alt={topLeftImage.title} className="leftCol_image" image={getImage(topLeftImage.gatsbyImageData)} />
          <p className="game_description">{gameDescription.gameDescription}</p>
        </div>
        {video===null &&
        <div className="rightCol">
          <GatsbyImage alt={rightImage.title} image={getImage(rightImage.gatsbyImageData)} />
        </div>}
        {video &&
        <div className="video__container">
          <video autoPlay playsInline loop muted>
            <source src={video.url} type="video/mp4" />
          </video>   
        </div>
        }
      </GameInfo>
    </GameCardWrapper>
    
  )
}

export default GameCard