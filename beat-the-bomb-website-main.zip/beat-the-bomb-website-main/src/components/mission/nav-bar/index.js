import React from 'react'
import styled from 'styled-components'
import { Link } from 'gatsby'
import slugify from 'slugify'

const MissionNavBarWrapper = styled.div`
  max-width: 1440px;
  position: relative;
  left: 50%;
  transform: translateX(-50%);
  width: 100%;
`

const SecondaryNavBar = styled.div`
  display: flex;
  justify-content: space-evenly;
  align-items: center;

  .active-link p{
    opacity: 1;
  }

  p{
    font-family: 'Pixel';
    font-style: normal;
    font-weight: 700;
    font-size: 48px;
    line-height: 195.39%;
    text-align: center;
    letter-spacing: 0.03em;
    color: #FFFFFF;
    opacity: 0.5;

    @media only screen and (max-width: 1024px){
      font-size: 30px;
    }

    @media only screen and (max-width: 768px){
      font-size: 25px;
    }

    @media only screen and (max-width: 500px){
      font-size: 15px;
      line-height: 18px;
    }

    // @media only screen and (max-width: 375px){
    //   font-size: 14px;
    // }
  }
`

const MissionNavBar = (pageContext) => {
  const temp_array = ["Paint Bomb","Foam Bomb", "Game Bay"]
  const missionToName = {"mission-01": "paint-bomb", "mission-02": "foam-bomb", "game-bay": "game-bay"}
  const nameToMission = {"paint-bomb": "mission-01", "foam-bomb": "mission-02", "game-bay": "game-bay"}
  const location = pageContext.path.split("/")
  return (
    <MissionNavBarWrapper>
      <SecondaryNavBar>
        {temp_array.map((pageName,index) =>{
          const slug = slugify(pageName, {lower:true})
          return( location.length === 3 ? 
            <Link key={index} className={`${slug}`=== missionToName[location[2]] ? 'active-link' :''} to={`/${location[1]}/${nameToMission[`${slug}`]}`}><p>{pageName}</p></Link>
            :
            <Link key={index} className={`${slug}`=== missionToName[location[1]] ? 'active-link' :''} to={`/${nameToMission[`${slug}`]}`}><p>{pageName}</p></Link>
          )
        })

        }
      </SecondaryNavBar>
    </MissionNavBarWrapper>
  )
}

export default MissionNavBar