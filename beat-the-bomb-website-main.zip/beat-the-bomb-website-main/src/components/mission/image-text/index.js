import React from 'react'
import styled from 'styled-components'
import battleModePoster from "../../../assets/images/battleMode/battleMode_poster.png"
import { documentToReactComponents } from '@contentful/rich-text-react-renderer'
import { BLOCKS, MARKS } from '@contentful/rich-text-types'

const ImageTextWrapper = styled.div`
  max-width: 1440px;
  position: relative;
  left: 50%;
  transform: translateX(-50%);
  padding: 0 3rem;
  margin-top: 2rem;

  @media only screen and (max-width: 768px){
    padding: 0 2rem;
  }

  @media only screen and (max-width: 500px){
    padding: 0 1rem;
  }
`

const WinLoseContent = styled.div`
  display: grid;
  grid-template-columns: repeat(2,1fr);
  grid-gap: 100px;
  align-items: center;
  /* padding: 0 60px; */

  .winloseText p{
    font-family: 'Acumin Pro';
    font-size: 32px;
    line-height: 125%;
    letter-spacing: 0;
    color: #ffffff;
    text-align: left;

    @media only screen and (max-width: 1250px) {
      font-size: 25px;
    }

    @media only screen and (max-width: 1024px) {
      font-size: 20px;
    }

    @media only screen and (max-width: 500px) {
      font-size: 15px;
      line-height: 18px;
    }
  }

  .videoContainer video{
    max-height: 550px;
    width: auto;
    margin: 0 auto;
    max-width: 100%;
  }

  @media only screen and (max-width: 768px){
    display:flex;
    flex-direction: column;
    grid-gap: 50px;
    
    .winloseText{
      margin-bottom: 2rem;
    }

    .winloseText p{
      margin:0;
      text-align: center;
    }
  }

  @media only screen and (max-width:500px){
    .winloseText{
      margin-bottom: 0;
    }
  }

`

const RICHTEXT_OPTIONS = {
  renderMark: {
    [MARKS.BOLD]: text => <strong>{text}</strong>,
  },
  renderNode: {
    [BLOCKS.PARAGRAPH]: (node, children) =>{
      return children!='' && (<p>{children}</p>)
    },

  }
}

const ImageText = ({ data }) => {
  const { richText, image } = data
  const json_text = JSON.parse(richText.raw)
  return (
    <ImageTextWrapper>
      <WinLoseContent>
        <div className="winloseText">
          {documentToReactComponents(json_text, RICHTEXT_OPTIONS)}
        </div>
        <div className="videoContainer">
          <video 
            autoPlay 
            playsInline 
            loop 
            muted  
            poster={battleModePoster}
          >
            <source src={image.url} type="video/mp4" />
          </video>
        </div>
      </WinLoseContent>
    </ImageTextWrapper>
    
  )
}

export default ImageText