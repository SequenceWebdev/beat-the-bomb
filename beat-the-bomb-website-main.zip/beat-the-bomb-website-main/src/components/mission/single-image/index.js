import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from 'styled-components'

const SingleImageWrapper = styled.div`
  max-width: 1440px;
  display:flex;
  flex-direction: column;
  align-items: center;

  position: relative;
  left:50%;
  transform: translateX(-50%);
  margin-top: 5rem;

  .video__container{
    width: 100%;
    max-width: 1000px;
    padding: 0 1rem;
  }

  .video__container video{
    width: 100%;
  }

  @media only screen and (max-width: 768px){
    margin-top: 2.5rem;
  }

  @media only screen and (max-width: 500px){
    margin-top: 1rem;
  }

  .single_image{
    
    position: relative;
    z-index: -1;
  }
`


const SingleImage = ({ data }) => {
  return (
    <SingleImageWrapper>
      {data.image.gatsbyImageData && <div className="image__container">
        <GatsbyImage alt={data.image.title} className='single_image' image={getImage(data.image.gatsbyImageData)}/>
      </div>}
      {data.image.gatsbyImageData===null &&
        <div className="video__container">
          <video autoPlay playsInline loop muted>
            <source src={data.image.url} type="video/mp4" />
          </video>   
        </div>
        }
    </SingleImageWrapper>
  )
}

export default SingleImage