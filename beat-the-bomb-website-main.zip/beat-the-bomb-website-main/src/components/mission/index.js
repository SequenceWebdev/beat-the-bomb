import Text from "./text";
import GameCard from "./game-card";
import ImageText from "./image-text";
import SingleImage from "./single-image";
import GameBayCard from "./game-bay-card";
import Button from "./button";

export {
  Text,
  GameCard,
  ImageText,
  SingleImage,
  GameBayCard,
  Button,
}