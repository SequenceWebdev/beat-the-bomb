import React from 'react'
import styled from 'styled-components'
import { GatsbyImage, getImage } from 'gatsby-plugin-image'

const GameBayCardWrapper = styled.div`
  max-width: 1440px;
  position: relative;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 3rem;
  margin-top: 2rem;

  @media only screen and (max-width: 768px){
    padding: 0 2rem;
  }

  @media only screen and (max-width: 500px){
    padding: 0 1rem;
    margin-top: 0rem;
  }
`

const GameRow = styled.div`
  display:flex;
  align-items: center;
  justify-content: space-evenly;

  .single_game{
    display:flex;
    flex-direction: column;
    align-items: center;
    position:relative;
    margin: 0 2rem 0.5rem 2rem;

    @media only screen and (max-width: 768px){
      flex-direction: row;
    }

    @media only screen and (max-width: 600px){
      margin: 0 0rem 1rem 0rem;
    }
  }

  .game_description{
    font-family: 'Acumin Pro';
    font-style: normal;
    font-weight: 400;
    font-size: 32px;
    line-height: 125%;
    /* or 40px */
    color:#ffffff;
    text-align: left;

    /* @media only screen and (max-width: 768px){
      text-align: center; 
    } */

    @media only screen and (max-width: 600px){
      font-size: 25px; 
    }
 

    @media only screen and (max-width: 500px){
      font-size: 20px; 
    }

  }

  .image__container{
    @media only screen and (max-width: 768px){
      width: 50%;
    }
  }

  .single_game__text__container{
    @media only screen and (max-width: 768px){
      width: 50%;
    }

  }

  @media only screen and (max-width: 768px){
    flex-direction: column;
  }
`

const GameInfo = styled.div`
  margin-top:3rem;
  display:flex;
  width:100%;
  flex-direction: column;
  align-items: center;

  .gameInfo__text{
    width:100%;
    display:flex;
    flex-direction: column;
    align-items: left;

    @media only screen and (max-width: 500px){
      margin-bottom: 1.5rem;
    }
  }

  .gameType_name, .gameType_desc{
    font-family: 'Acumin Pro';
    font-style: italic;
    font-weight: 700;
    font-size: 50px;
    line-height: 120%;
    letter-spacing: 0;
    text-transform: uppercase;
    color: var(--neon-blue);

    @media only screen and (max-width: 1250px) {
      font-size: 35px;
    }

    @media only screen and (max-width: 1024px) {
      font-size: 30px;
    }

    @media only screen and (max-width: 768px) {
      font-size: 25px;
      text-align: center;
    }

    @media only screen and (max-width: 500px) {
      font-size: 22px;
    }
  }

  .gameType_name{
    color: var(--neon-blue);
  }

  .gameType_desc{
    color: #ffffff;
  }
`

const GameBayCard = ({ data }) => {
  const { gameType, gameTypeDescription, games } = data
  return (
    <GameBayCardWrapper>
      <GameInfo>
        <div className="gameInfo__text">
          <h4 className="gameType_name">{gameType}</h4>
          <h4 className="gameType_desc">{gameTypeDescription}</h4>
        </div>
        <GameRow>
          {games.map((game,index) =>{
            const {name, gameDescription, gameMissionImageAssets} = game
            return(
                <div className="single_game" key={index}>
                  <div className="image__container">
                    <GatsbyImage alt={name} image={getImage(gameMissionImageAssets[0].gatsbyImageData)}/>
                  </div>
                  <div className="single_game__text__container">
                    <p className='game_description'>{gameDescription.gameDescription}</p>
                  </div>
                  
                  
                </div>
            )
          })}
        </GameRow>
      </GameInfo>
    </GameBayCardWrapper>
  )
}

export default GameBayCard