import { StaticImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from "styled-components"
import CompLogoScroller from '../compLogoScroller'

const VirtualCompaniesWrapper = styled.div`
  margin-bottom: 0.5rem;
  display:flex;
  flex-direction: column;

  .banner--normal{
    @media only screen and (max-width:500px){
      padding: 20px 0px;
    }
  }

  .banner h2{
    font-family: 'Acumin-Pro-700';
    font-size: 60px;

    @media only screen and (max-width: 768px){
      font-size:40px;
    }

    @media only screen and (max-width: 500px){
      font-size:22px;
    }
  }
`

const VirtualCompaniesInnerWrapper = styled.div`
  /* max-width: 1920px; */
  display:flex;
  flex-direction: column;
  align-items: center;
  padding: 0 80px;
  position: relative;

  .comp_logo_container{
    display:flex;
    align-items: center;
  }

  .video_bg{
    position: absolute;
    top:10%;
    left:0;
    width:100%;
    height:100%;
    z-index:1;
  }
  iframe{
    max-width: 936px;
    width:100%;
    margin-top: 4rem;
    margin-bottom: 5rem;
    aspect-ratio: 1.8;
    z-index:5;
  }

  h3{
    font-family: 'Acumin-Pro-700';
    font-style: normal;
    font-weight: 700;
    font-size: 60px;
    line-height: 120%;
    text-align: center;
    letter-spacing: 0.065em;
    text-transform: uppercase;
    width: 100%;
    color: #fff;
    z-index:5;

    @media only screen and (max-width: 768px){
      font-size:40px;
    }

    @media only screen and (max-width: 500px){
      font-size:20px;
    }
  }

  .blue_line_divider{
    width: 20%;
    height: 5px;
    background-color: var(--neon-blue);
    margin: 2rem 0 0 0;
    z-index: 6;
  }

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }

  @media screen and (max-width: 768px){
    padding: 0 30px;
  }
`

const VirtualCompanies = ({ companies }) => {
  const { headerTitle, bodyTexts, assets } = companies[0]
  return (
    <VirtualCompaniesWrapper>
      {/* banner banner--normal banner--angle-1 banner--pink */}
      <div className="banner banner--normal banner--green">
        <h2 data-aos="fade-right" data-aos-once="true">{headerTitle}</h2>
      </div>
      <VirtualCompaniesInnerWrapper>
        <StaticImage alt="video bg" className="video_bg" objectFit="fill" src="../../assets/images/virtual/video_game_bg.png"/>
        <iframe title="Youtube BTB Video" src={bodyTexts[0].text}></iframe>
        <h3>{bodyTexts[1].text}</h3>
        <div className="blue_line_divider"></div>
        {/* <CompaniesScroller companyLogos={companies} /> */}
        <div className="comp_logo_container">
          <CompLogoScroller assets={assets} page="Virtual"/>
        </div>
      </VirtualCompaniesInnerWrapper>
    </VirtualCompaniesWrapper>
  )
}

export default VirtualCompanies