import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from "styled-components"

const VirtualGamePacksWrapper = styled.div`
  margin-bottom: 5rem;

  .banner--normal{
    margin-top:0;
    @media only screen and (max-width:500px){
      padding: 20px 0px;
    }
  }

  .banner h2{
    font-family: 'Acumin-Pro-700';
    font-size: 60px;
    text-transform: uppercase;

    @media only screen and (max-width: 768px){
      font-size:40px;
    }

    @media only screen and (max-width: 500px){
      font-size:22px;
    }
  }


`

const VirtualGamePacksInnerWrapper = styled.div`
  max-width:1920px;
  display:flex;
  flex-direction: column;
  align-items: center;
  padding: 0 60px;
  padding-top: 1rem;

  .description{
    font-family: 'Acumin-Pro';
    font-style: normal;
    font-weight: 400;
    font-size: 30px;
    line-height: 120%;
    text-align: center;
    letter-spacing: 0.065em;
    color: #fff;
    padding-top: 2rem;

    @media only screen and (max-width:900px){
      font-size: 25px;
    }

    @media only screen and (max-width:600px){
      font-size: 20px;
    }

    @media only screen and (max-width:425px){
      font-size: 15px;
    }
  }

  .title{
    font-family: 'Acumin-Pro-700';
    font-style: italic;
    font-weight: 700;
    font-size: 40px;
    line-height: 120%;
    text-align: center;
    letter-spacing: 0.065em;
    text-transform: uppercase;
    color: var(--neon-blue);

    @media only screen and (max-width:900px){
      font-size: 35px;
    }

    @media only screen and (max-width:600px){
      font-size: 30px;
    }

    @media only screen and (max-width:425px){
      font-size: 20px;
    }
  }


  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }
`

const Packs = styled.div`
  margin-top: 5rem;
  display:grid;
  grid-template-columns: repeat(3,1fr);
  column-gap: 60px;
  align-items: baseline;
  
  .button{
    width:235px;
    height: 65px;
    font-family: 'Pixel';
    font-style: italic;
    font-weight: 700;
    font-size: 30px;
    line-height: 120%;
    text-align: center;
    text-transform: uppercase;
    padding: .75rem 0 0 0;

    @media only screen and (max-width:900px){
      height: 45px;
      font-size: 25px;
    }

    @media only screen and (max-width:600px){
      font-size: 18px;
    }
  }

  .pack1, .pack2, .packs{
    display:flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;
    height:900px;

    @media only screen and (max-width: 600px){
      justify-content: space-evenly;
    }
  }

  .surprise_pack, .vip_pack{
    border: 2px solid var(--neon-blue);
    display:flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    padding: 1.5rem .5rem;

    & a{
      position:absolute;
      bottom: 0%;
      transform: translateY(50%);
    }
  }

  @media only screen and (max-width: 1250px){
    grid-template-columns: repeat(2,1fr);

    .packs{
      margin-top: 5rem;
      grid-column: span 2; 
      height: 600px;
    }
  }

  @media only screen and (max-width: 600px){
    margin-top:2rem;
    display:flex;
    flex-direction: column;
    align-items: center;

    .pack1{
      height: 600px;
      border: 2px solid var(--neon-blue);
      position: relative;
      padding: 1rem;

      & a{
        position: absolute;
        bottom:0;
        transform: translateY(50%);
      }
    }

    .pack2{
      margin-top: 5rem; 
      height: 600px;
      border: 2px solid var(--neon-blue);
      padding: 1rem;
      position:relative;

      & a{
        position: absolute;
        bottom:0;
        transform: translateY(50%);
      }
    }

    .packs{
      margin-bottom: 5rem;
      height:auto;
      row-gap:5rem;
    }
  }

  @media only screen and (max-width: 425px){

    
  }
`


const GameImages = styled.div`
  margin-top: 5rem;
  display:grid;
  grid-template-columns: repeat(2, 1fr);
  column-gap: 100px;
  align-items: center;

  @media only screen and (max-width:900px){
    display:flex;
    flex-direction: column;
    row-gap: 3rem;
  }

  @media only screen and (max-width:600px){
    margin-top: 0;
  }
`

const VirtualGamePacks = ({ games }) => {
  const { headerTitle, assets, bodyTexts } = games[0]

  return (
    <VirtualGamePacksWrapper>
      <div className="banner banner--no-transition banner--normal banner--no-transform banner--green">
        <h2 data-aos="fade-right" data-aos-once="true">{headerTitle}</h2>
      </div>
      <VirtualGamePacksInnerWrapper>
        <p className='description'>{bodyTexts[0].text}</p>
        <p className='description'>{bodyTexts[1].text}</p>
        <Packs>
          <div className="pack1">
            <h4 className='title'>{bodyTexts[2].text}</h4>
            <GatsbyImage alt={assets[2].title} image={getImage(assets[2].gatsbyImageData)} />
            <GatsbyImage alt={assets[3].title} image={getImage(assets[3].gatsbyImageData)} />
            <GatsbyImage alt={assets[4].title} image={getImage(assets[4].gatsbyImageData)} />
            <a class="button button--large button--blue button--xola" href="https://checkout.xola.com/index.html#seller/609be2cbe41c4f2ac9265084/experiences/609be36e1d1851521b564359">{bodyTexts[8].text}</a>
          </div>
          <div className="pack2">
            <h4 className='title'>{bodyTexts[3].text}</h4>
            <GatsbyImage alt={assets[5].title} image={getImage(assets[5].gatsbyImageData)} />
            <GatsbyImage alt={assets[6].title} image={getImage(assets[6].gatsbyImageData)} />
            <GatsbyImage alt={assets[7].title} image={getImage(assets[7].gatsbyImageData)} />
            <a class="button button--large button--blue button--xola" href="https://checkout.xola.com/index.html#seller/609be2cbe41c4f2ac9265084/experiences/6298ac45a0c856601e096141">{bodyTexts[8].text}</a>
          </div>
          <div className="packs">
            <div className="surprise_pack">
              <h4 className='title'>{bodyTexts[4].text}</h4>
              <p className="description">{bodyTexts[5].text}</p>
              <a class="button button--large button--blue button--xola" href="https://checkout.xola.com/index.html#seller/609be2cbe41c4f2ac9265084/experiences/6298b572a3460a3d8d0cf2b4">{bodyTexts[8].text}</a>
            </div>
            <div className="vip_pack">
              <h4 className='title'>{bodyTexts[6].text}</h4>
              <p className="description">{bodyTexts[7].text}</p>
            </div>
          </div>
        </Packs>
        <GameImages>
          <GatsbyImage alt={assets[0].title} image={getImage(assets[0].gatsbyImageData)}></GatsbyImage>
          <GatsbyImage alt={assets[1].title} image={getImage(assets[1].gatsbyImageData)}></GatsbyImage>
        </GameImages>
      </VirtualGamePacksInnerWrapper>
    </VirtualGamePacksWrapper>
  )
}

export default VirtualGamePacks