import React, { useState } from 'react'
import styled from 'styled-components'

import 'react-responsive-modal/styles.css';
import '../styles/modal.css'
import { Modal } from 'react-responsive-modal';

import {AiOutlineClose} from 'react-icons/ai'

const VirtualDemoWrapper = styled.div`
  margin-bottom: 5rem;

  .banner--normal{
    @media only screen and (max-width:500px){
      padding: 20px 0px;
    }
  }
  
  .banner h2{
    font-family: 'Acumin-Pro-700';
    font-size: 60px;
    text-transform: uppercase;

    @media only screen and (max-width: 768px){
      font-size:40px;
    }

    @media only screen and (max-width: 500px){
      font-size:22px;
    }
  }
`

const VirtualDemoInnerWrapper = styled.div`
  max-width: 1920px;
  display: flex;
  align-items: center;
  flex-direction: column;
  margin-top:5rem;
  padding: 0 120px;

  p{
    font-family: 'Acumin Pro';
    font-style: normal;
    font-weight: 400;
    font-size: 30px;
    line-height: 142.19%;
    /* or 43px */
    text-align: center;
    margin-bottom: 3rem;
    color: #FFFFFF;

    @media only screen and (max-width: 1024px){
      font-size: 27px;
    }

    @media only screen and (max-width: 768px){
      font-size: 22px;
    }

    @media only screen and (max-width: 500px){
      font-size: 20px;
    }
  }

  .button{
    width:500px;
    font-family: 'Pixel';
    font-style: italic;
    font-weight: 700;
    font-size: 30px;
    line-height: 120%;
    text-align: center;
    text-transform: uppercase;
    margin-bottom: 3rem;

    @media screen and (max-width: 768px) {
       width:300px;
       font-size: 27px;
       padding: 0;
       height: 45px;
    }

    @media screen and (max-width: 500px) {
       width:250px; 
       font-size: 18px;
    }
  }

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }

  @media screen and (max-width: 1024px) {
    padding: 0 80px; 
  }

  @media screen and (max-width: 768px) {
    padding: 0 60px; 
  }

  @media screen and (max-width: 500px) {
    padding: 0 30px; 
  }
`

const VirtualDemo = ({ demo }) => {
  const { headerTitle, bodyTexts } = demo[0]

  const [open, setOpen] = useState(false);

  const onOpenModal = () => setOpen(true);
  const onCloseModal = () => setOpen(false);

  const closeIcon = (<AiOutlineClose color='black' size={36} />);

  return (
    <VirtualDemoWrapper>
      <div className="banner banner--no-transition banner--normal banner--no-transform banner--green">
        <h2 data-aos="fade-right" data-aos-once="true">{headerTitle}</h2>
      </div>
      <VirtualDemoInnerWrapper>
        <p>{bodyTexts[0].text}</p>
        <button className="button button--large button--pink" onClick={onOpenModal}>
          {bodyTexts[1].text}
        </button>
      </VirtualDemoInnerWrapper>
      <Modal 
          open={open} 
          onClose={onCloseModal} 
          center 
          showCloseIcon 
          classNames={{
            overlay: 'customOverlay',
            modal: 'customModal',
          }}
          closeIcon={closeIcon}
        >
          <div className="iframe_container">
            <iframe title="demo__scheduler" width="100%" height="100%" src="https://calendly.com/online-cck/30min"></iframe>
          </div>
          
        </Modal>
    </VirtualDemoWrapper>
  )
}

export default VirtualDemo