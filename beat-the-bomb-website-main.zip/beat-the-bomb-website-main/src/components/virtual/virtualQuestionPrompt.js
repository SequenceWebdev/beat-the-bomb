import React, { useState } from 'react'
import styled from 'styled-components'
import { Collapse } from 'react-bootstrap'
import { IoCaretDown } from 'react-icons/io5'

const QuestionPrompt = styled.div`
  display:flex;
  align-items: flex-start;
  flex-direction: column;
  margin-bottom: 0.5rem;
  /* margin: 0.5rem 0; */

  .question__button{
    background-color: transparent;
    border-color: transparent;
    display:flex;
    align-items: flex-start;
  }

  .plus_icon{
    color: var(--neon-blue);
    font-size: 40px;
    margin-right: 1rem;

    @media only screen and (max-width: 1250px){
      font-size: 38px;
    }

    @media only screen and (max-width: 900px){
      font-size: 30px;
    }

    @media only screen and (max-width: 600px){
      font-size: 25px;
    }

    @media only screen and (max-width: 500px){
      font-size: 22px;
    }
  }

  h4{
    font-family: 'Acumin-Pro-700';
    font-style: normal;
    font-weight: 700;
    font-size: 40px;
    line-height: 142.19%;
    /* or 57px */
    color: var(--neon-blue);
    margin-bottom: 1rem;
    text-align: left;

    @media only screen and (max-width: 1250px){
      font-size: 30px;
    }

    @media only screen and (max-width: 900px){
      font-size: 25px;
    }

    @media only screen and (max-width: 600px){
      font-size: 20px;
    }

    @media only screen and (max-width: 500px){
      font-size: 18px;
    }
  }

  p{
    font-family: 'Acumin Pro';
    font-style: normal;
    font-weight: 400;
    font-size: 30px;
    line-height: 142.19%;
    /* or 43px */
    color: #FFFFFF;
    text-align: left;

    @media only screen and (max-width: 900px){
      font-size: 20px;
    }

    @media only screen and (max-width: 600px){
      font-size: 18px;
    }

    @media only screen and (max-width: 500px){
      font-size: 16px;
    }
  }
`


const VirtualQuestionPrompt = ({ qa }) => {
  const [open, setOpen] = useState(false);
  const question = qa.QA[0].text
  const answer = qa.QA[1].text
  return (
    <QuestionPrompt>
      <button
        onClick={() => {setOpen(!open)}}
        aria-controls="collapse-text"
        aria-expanded={open}
        className="question__button"
      >
        <h4>
          <IoCaretDown 
            className='plus_icon' 
            style={{
              transition: "transform .5s",
              transform: `rotate(${open ? 0 : -90}deg)`,
            }}/>
              {question}
        </h4>
      </button>
      <Collapse in={open}>
        <div id="collapse-text">
          <p>{answer}</p>
        </div>
      </Collapse>
    </QuestionPrompt>
  )
}

export default VirtualQuestionPrompt