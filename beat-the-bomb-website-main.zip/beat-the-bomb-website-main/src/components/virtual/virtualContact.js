import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from 'styled-components'

import SalesForm from "../forms/salesForm";

const VirtualContactWrapper = styled.div`
  margin-bottom: 5rem;

  .banner--normal{
    margin-bottom:0;

    @media only screen and (max-width:500px){
      padding: 20px 0px;
    }
  }
  
  .banner h2{
    font-family: 'Acumin Pro';
    font-weight: 700;
    font-size: 60px;
    text-transform: uppercase;
    color:#fff;

    @media only screen and (max-width: 768px){
      font-size:40px;
    }

    @media only screen and (max-width: 500px){
      font-size:22px;
    }
  }
`

const VirtualContactInnerWrapper = styled.div`
  /* max-width: 1920px; */
  position:relative;
  display:flex;
  flex-direction: column;
  align-items: center;
  padding: 0 80px;
  padding-bottom: 3rem;

  .bg{
    position: absolute;
    top:0;
    left:0;
    width:100%;
    height: 100%;
    z-index:1;
  }

  .contact__paragraph{
    margin-top: 3rem;
    font-family: 'Acumin Pro';
    font-style: normal;
    font-weight: 400;
    font-size: 30px;
    line-height: 142.19%;
    /* or 43px */

    text-align: center;

    color: #FFFFFF;
    z-index: 2;

    @media only screen and (max-width: 1024px){
      font-size: 27px;
    }

    @media only screen and (max-width: 768px){
      font-size: 22px;
    }

    @media only screen and (max-width: 500px){
      font-size: 20px;
    }
  }

  .button{
    margin-top:1rem;
    font-family: 'Pixel';
    font-style: italic;
    font-weight: 700;
    font-size: 30px;
    line-height: 36px;
    text-align: center;
    text-transform: uppercase;
    width: 500px;
    position: relative;
    left:50%;
    transform: translateX(-50%);

    @media only screen and (max-width: 1024px){
      width:475px;
    }

    @media only screen and (max-width: 768px){
      width:350px;
      height: 45px;
      font-size: 18px;
      padding: 0;
    }

    @media only screen and (max-width: 500px){
      width:250px;
    }
  }

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }

  @media screen and (max-width: 768px) {
    padding: 0 60px; 
  }

  @media screen and (max-width: 500px) {
    padding: 0 30px; 
  }
`

const SocialMedia = styled.div`
  margin-top: 7rem;
  margin-bottom: 3rem;
  z-index:5;
  display:flex;
  justify-content: center;
  align-items: center;
  width:25%;

  .sm_link{
    margin: 0 0.75rem;
  }

  .sm_icon{
    color:#FFFFFF;
    font-size:40px;
  }

  .sm_icon:hover{
    color:var(--neon-pink);
    
  }
`

const VirtualContact = ({ contact }) => {
  const { headerTitle, bodyTexts, assets } = contact[0]
  return (
    <VirtualContactWrapper>
      <div className="banner banner--no-transition banner--normal banner--no-transform banner--blue">
        <h2 data-aos="fade-left" data-aos-once="true">{headerTitle}</h2>
      </div>
      <VirtualContactInnerWrapper>
        <GatsbyImage alt={assets[0].title} className="bg" objectFit="fill" image={getImage(assets[0].gatsbyImageData)}></GatsbyImage>
        <p className="contact__paragraph">{bodyTexts[0].text}</p>
        <SalesForm />
      </VirtualContactInnerWrapper>
    </VirtualContactWrapper>
  )
}

export default VirtualContact