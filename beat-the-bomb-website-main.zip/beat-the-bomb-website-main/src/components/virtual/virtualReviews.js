import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from "styled-components"

const VirtualReviewWrapper = styled.div`
  /* margin-bottom: 5rem; */

  .banner--normal{
    @media only screen and (max-width:500px){
      padding: 20px 0px;
    }
  }

  .banner h2{
    font-family: 'Acumin-Pro-700';
    font-size: 60px;
    text-transform: uppercase;

    @media only screen and (max-width: 768px){
      font-size:40px;
    }

    @media only screen and (max-width: 500px){
      font-size:22px;
    }
  }

`

const VirtualReviewInnerWrapper = styled.div`
  max-width:1920px;
  position: relative;
  padding: 60px;
  margin-top: -1rem;

  .review_bg{
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:100%;
    z-index:1;
  }

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }

`

const ReviewTestimonials = styled.div`
  display: grid;
  grid-template-columns: repeat(3,1fr);
  column-gap: 30px;
  

  @media only screen and (max-width: 900px){
    display:flex;
    flex-direction: column;
    align-items: center;
  }

  @media only screen and (max-width: 500px){
    padding: 2rem 0.5rem;
  }
`

const Review = styled.div`
  border: 2px solid var(--neon-blue);
  background-color: #000;
  z-index:5;
  display:flex;
  align-items: center;
  flex-direction: column;
  justify-content: center;
  
  .review{
    font-family: 'Acumin-Pro';
    font-style: normal;
    font-weight: 400;
    font-size: 23px;
    line-height: 130%;
    text-align: center;
    color: #fff;
    padding: 25px 10px;

    @media only screen and (max-width: 1250px){
      font-size: 20px;
    }

    @media only screen and (max-width: 765px){
      font-size: 18px;
    }

    /* @media only screen and (max-width: 500px){
      font-size: 12px;
    } */

  }

  .title{
    font-family: 'Acumin-Pro';
    font-style: normal;
    font-weight: 400;
    font-size: 23px;
    line-height: 130%;
    text-align: center;
    color: #fff;
    padding: 0px 10px 25px 10px;

    @media only screen and (max-width: 1250px){
      font-size: 20px;
    }

    @media only screen and (max-width: 765px){
      font-size: 18px;
    }

    /* @media only screen and (max-width: 500px){
      font-size: 12px;
    } */
  }

  .name{
    font-family: 'Pixel';
    font-style: normal;
    font-weight: 400;
    font-size: 23px;
    line-height: 130%;
    text-align: center;
    padding: 0 10px;
    color: #fff;

    @media only screen and (max-width: 1250px){
      font-size: 20px;
    }

    @media only screen and (max-width: 765px){
      font-size: 18px;
    }

    /* @media only screen and (max-width: 500px){
      font-size: 12px;
    } */
  }

  @media only screen and (max-width:900px){
    margin-bottom: 3rem;
  }
`

const VirtualReviews = ({ reviews }) => {
  const { headerTitle, assets, reviewTestimonial } = reviews[0]
  return (
    <VirtualReviewWrapper>
      <div className="banner banner--no-transition banner--normal banner--no-transform banner--blue">
        <h2 data-aos="fade-left" data-aos-once="true">{headerTitle}</h2>
      </div>
      <VirtualReviewInnerWrapper>
        <GatsbyImage alt={assets[0].title} className="review_bg" image={getImage(assets[0].gatsbyImageData)} />
        <ReviewTestimonials>
          {reviewTestimonial.references.map((testimony, index)=>{
            return(
              <Review key={index}>
                <p className="review">{testimony.review.review}</p>
                <h4 className="name">{testimony.name}</h4>
                <p className="title">{testimony.title}</p>
              </Review>
            )
          })}
        </ReviewTestimonials>
      </VirtualReviewInnerWrapper>
    </VirtualReviewWrapper>
  )
}

export default VirtualReviews