import React from 'react'
import styled from 'styled-components'
import { GatsbyImage, getImage, StaticImage } from 'gatsby-plugin-image'
import Button from "../home-new/button";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
// Images
import cb from '../../assets/images/virtual/CB.png';

const BodyParagraphs = styled.div`
  margin-top: 3rem;
  max-width: 1920px;
  position: relative;
  margin-left: auto;
  margin-right: auto;
  padding-left: 128px;
  padding-right: 128px;
  /* left: 50%;
  transform: translateX(-50%); */
  display: flex;
  align-items: center;
  flex-direction: column;
  justify-content: center;

  p{
    padding: 0 0 30px 0;
    font-family: 'Acumin Pro';
    font-style: normal;
    font-weight: 400;
    font-size: 30px;
    line-height: 142.19%;
    /* or 43px */

    text-align: center;
    color: #fff;

    @media only screen and (max-width: 1024px) {
      font-size: 25px;
    }

    @media only screen and (max-width: 768px) {
      
      font-size: 20px;
    }

    @media only screen and (max-width: 500px) {
      font-size: 16px;
    }

    @media only screen and (max-width: 425px) {
      font-size: 12px;
    }
  }

  @media only screen and (max-width: 768px) {
    padding: 0px 15px;
  }
`

const HeroImageWrapper = styled.div`
  margin-bottom: -10rem;
  margin-top: -2rem;
  padding: 4rem 128px 12rem 128px;
  position: relative;

  @media (max-width: 900px) {
    padding: 0 0 12rem 0;
  }

  .background-image {
    bottom: 0;
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    z-index: 0;

    &::after {
      background: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 1));
      bottom: 0;
      content: "";
      display: block;
      height: 150px;
      left: 0;
      position: absolute;
      right: 0;
    }
  }

  .content {
    aspect-ratio: 1.77777777777778;
    display: flex;
    flex-direction: column;
    justify-content: center;
    margin: 0 auto;
    max-width: 1920px;
    padding: 0 128px;
    position: relative;
    text-align: center;
    z-index: 2;

    @media (max-width: 900px) {
      aspect-ratio: auto;
      padding: 10rem 0;
    }

    .text {
      color: white;
      font-family: "Acumin Pro";
      font-size: clamp(20px, 5vw, 80px);
      font-style: normal;
      font-weight: 700;
      letter-spacing: -1.5px;
      line-height: 125%;
      margin: 0 auto;
      max-width: 20ch;
      text-transform: uppercase;

      @media (max-width: 900px) {
        font-size: clamp(20px, 8vw, 80px);
      }
    }

    .buttons {
      display: flex;
      margin-top: 4rem;
      padding: 0 10px;

      @media (max-width: 900px) {
        flex-direction: column;
        margin: 0 auto;
        max-width: 300px;
        width: 100%;
      }

      .button-wrapper {
        padding: 5px 10px;
        position: relative;
        width: 100%;
        z-index: 3;
      }

      .button-wrapper > * {
        margin-top: 0;
      }

      .button-wrapper > * > a {
        width: 100%;
      }

      .button-wrapper > * > div {
        width: 100%;
      }

      &--1 {
        .button-wrapper > * > a {
          max-width: 400px;
        }

        .button-wrapper > * > div {
          max-width: 400px;
        }
      }
    }

    .media {
      height: 0;
      overflow: hidden;
      padding-top: 56.25%;
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
      right: 0;
      top: 0;
      max-width: 1200px;
      width: 100%;
      z-index: 0;

      @media (max-width: 900px) {
        height: 100%;
        padding-top: 0;
      }

      .image,
      .video {
        bottom: 0;
        height: 100%;
        position: absolute;
        left: 0;
        right: 0;
        top: 0;
        width: 100%;
        z-index: -1;

        @media (max-width: 900px) {
          object-fit: cover;
        }
      }

      .iframe_container {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 0;
      }
    }

    .flairs {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 2;
      * {
        pointer-events: none;
        position: absolute;
        z-index: 2;
      }

      .cb {
        bottom: 0;
        /* height: 290px; */
        left: 0;
        /* width: 194px; */

        @media (max-width: 1600px) {
          height: 216px;
          width: 250px;
        }

        @media (max-width: 1250px) {
          height: 116px;
          width: 135px;
        }
      }
    }
  }
`

const VirtualHero = ({ hero }) => {
  const { assets, bodyTexts, headerTitle } = hero[0];
  const placeholder = assets[1];
  const logo = assets[0];
  const backgroundImage = assets[2];
  const borderColor = "Blue";
  const buttonColor = "Black";
  const buttonText = "Book Now";
  const textColor = "Blue";
  const type = "xola";
  const buttonLink = "https://checkout.xola.com/index.html#buttons/629f6ddc4ac30137d8100347?cache=1654701736332&openExternal=true";
  const button = {borderColor, buttonColor, buttonText, textColor, type, buttonLink};

  const video = assets[3];

  const settings = {
    arrows: false,
    autoplay: true,
    autoplaySpeed: 5000,
    dots: false,
    infinite: true,
    pauseOnFocus: false,
    pauseOnHover: false,
    slidesToScroll: 1,
    slidesToShow: 1,
    speed: 500,
  };

  return (
    <>
    <HeroImageWrapper>
      <div className="content">
        <div className="background-image">
          <GatsbyImage
            alt={backgroundImage.title}
            image={getImage(backgroundImage.gatsbyImageData)}
            objectFit="cover"
            style={{
              height: "100%",
              width: "100%",
            }}
          />
        </div>
        {/* <div className="media">
          
            <video
              autoPlay
              className="video"
              playsInline
              loop
              muted
              src={video.url}
              poster={placeholder.url}
            />
        </div> */}
        <div className="text">
            <GatsbyImage alt="virtual hero" image={getImage(logo.gatsbyImageData)}/>
            {/* <Slider {...settings}>
                  <div>
                    {headerTitle}
                  </div> 
            </Slider> */}
          
        </div>

        <div className={`buttons buttons--1`}>
          
          <div className="button-wrapper">
            <div className="button-wrapper">
                <Button
                  data={{ button }}
                  glow={{
                    "Black":"#000000",
                    "Blue": "var(--neon-blue)",
                    "Pink": "var(--neon-pink)",
                    "Yellow": "var(--neon-yellow)",
                    "Green": "var(--neon-green)",
                    "White": "#FFFFFF",
                  }[button.textColor]}
                  withFlair={true}
                />
              </div>
          </div>
          <div className="flairs">
            <img
              alt=""
              className="cb"
              src={cb}
            />
          </div>
        </div>
      </div>
    </HeroImageWrapper>
    <BodyParagraphs>
     <p>{bodyTexts[1].text}</p>
     <p>{bodyTexts[2].text}</p>
    </BodyParagraphs>
    </>
  )
}

export default VirtualHero