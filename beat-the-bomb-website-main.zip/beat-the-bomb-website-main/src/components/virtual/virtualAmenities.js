import { GatsbyImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from "styled-components"

const VirtualAmenitiesWrapper = styled.div`
  margin-bottom: 5rem;

  .banner--normal{
    @media only screen and (max-width:500px){
      padding: 20px 0px;
    }
  }

  .banner h2{
    font-family: 'Acumin-Pro-700';
    font-size: 60px;
    text-transform: uppercase;
    color:#fff;

    @media only screen and (max-width: 768px){
      font-size:40px;
    }

    @media only screen and (max-width: 500px){
      font-size:22px;
    }
  }
`

const VirtualAmenitiesInnerWrapper = styled.div`
  max-width:1920px;
  padding: 3rem 20px 0 20px;

  display:flex;
  flex-direction: column;
  justify-content: space-evenly;
  align-items: center;

  .upperRow{
    display:flex;
    justify-content: space-evenly;
    align-items: baseline;
    width:100%;
    margin-bottom: 1rem;

    @media only screen and (max-width:900px) {
      flex-direction: column;
      width:50%;
      margin-bottom:0;
      margin-right: 1rem;
      align-items: center;
      row-gap: 60px;
      /* display:grid;
      grid-template-columns: repeat(2,1fr); */
    }

    @media only screen and (max-width:600px) { 
      width:100%;
    }
  }

  .lowerRow{
    display:flex;
    justify-content: space-evenly;
    align-items: baseline;
    width:100%;

    @media only screen and (max-width:900px) {
      flex-direction: column;
      width:50%;
      align-items: center;
      row-gap: 60px;
      /* display:grid;
      grid-template-columns: repeat(2,1fr); */

    }

    @media only screen and (max-width:600px) { 
      width:100%;
    }
  }

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }

  @media only screen and (max-width:900px) {
    flex-direction:row;
    align-items: baseline;
  }

  /* @media only screen and (max-width:600px) {
    flex-direction:column;
    align-items: center;
    row-gap: 60px;
  } */
`

const Amenity = styled.div`
  display:flex;
  flex-direction: column;
  align-items: center;
  margin:1rem;
  
  .amenity-img{
    @media only screen and (max-width:425px){
      width:50%;
    }
  }
  
  p{
    font-family: 'Acumin Pro';
    font-style: normal;
    font-weight: 400;
    font-size: 32px;
    line-height: 142.19%;
    margin-top:0.5rem;
    /* identical to box height, or 46px */

    text-align: center;
    color: #fff;

    @media only screen and (max-width: 1250px){
      font-size: 27px;
    }

    @media only screen and (max-width: 768px){
      font-size: 20px;
    }

    @media only screen and (max-width: 425px){
      font-size: 16px;
    }
  }

  @media only screen and (max-width:600px) {
    margin: 0 1rem;
  }
`


const VirtualAmenities = ({ amenities }) => {
  const { headerTitle, assets, bodyTexts } = amenities[0]
  return (
    <VirtualAmenitiesWrapper>
      <div className="banner banner--no-transition banner--normal banner--no-transform banner--pink">
        <h2 data-aos="fade-left" data-aos-once="true">{headerTitle}</h2>
      </div>
      <VirtualAmenitiesInnerWrapper>
        <div className="upperRow">
          {assets.map((asset, index) =>{
            const thisAmenity = (index < 3 ? <Amenity key={index}>
                <GatsbyImage alt={asset.title} className="amenity-img" image={asset.gatsbyImageData} />
                <p>{bodyTexts[index].text}</p>
              </Amenity> : <></>)
            return(
              thisAmenity
            )
          })}
        </div>
        <div className="lowerRow">
          {assets.map((asset, index) =>{
            const thisAmenity = (index >= 3 ? <Amenity key={index}>
                <GatsbyImage alt={asset.title} className="amenity-img" image={asset.gatsbyImageData} />
                <p>{bodyTexts[index].text}</p>
              </Amenity> : <></>)
            return(
              thisAmenity
            )
          })}
        </div>

      </VirtualAmenitiesInnerWrapper>

    </VirtualAmenitiesWrapper>
  )
}

export default VirtualAmenities