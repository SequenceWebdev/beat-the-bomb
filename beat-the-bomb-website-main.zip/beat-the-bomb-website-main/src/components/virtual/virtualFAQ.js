import React from 'react'
import styled from "styled-components"
import FaqQa from '../question-faq'

const VirtualFAQWrapper = styled.div`
  /* margin-bottom: 5rem; */

  .banner--normal{
    @media only screen and (max-width:500px){
      padding: 20px 0px;
    }
  }
  
  .banner h2{
    font-family: 'Acumin-Pro-700';
    font-size: 60px;
    text-transform: uppercase;
    color:#fff;

    @media only screen and (max-width: 768px){
      font-size:40px;
    }

    @media only screen and (max-width: 500px){
      font-size:22px;
    }
  }
`

const VirtualFAQInnerWrapper = styled.div`
  margin-top: 2rem;
  max-width:1920px;
  padding: 0 80px;

  p {
    font-family: "Acumin Pro", sans-serif;
    font-size: 30px;

    @media only screen and (max-width: 1024px){
      font-size: 27px;
    }

    @media only screen and (max-width: 768px){
      font-size: 22px;
    }

    @media only screen and (max-width: 500px){
      font-size: 20px;
    }
  }

  @media only screen and (max-width: 900px){
    padding: 0 60px;
  }

  @media only screen and (max-width: 600px){
    padding: 0 40px;
  }

  @media only screen and (max-width: 500px){
    padding: 0 30px;
  }

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }
`

const VirtualFAQ = ({ faq }) => {
  const { headerTitle, bodyTexts } = faq[0]
  return (
    <VirtualFAQWrapper>
      <div className="banner banner--no-transition banner--normal banner--no-transform banner--pink">
        <h2 data-aos="fade-left" data-aos-once="true">{headerTitle}</h2>
      </div>
      <VirtualFAQInnerWrapper>
        {faq[0].faq.map((set, index)=>{
          return(
            // <VirtualQuestionPrompt key={index} qa={faq} />
            <FaqQa q={set.question.question} a={set.answer.answer}/>
          )
        })}
      </VirtualFAQInnerWrapper>
    </VirtualFAQWrapper>
  )
}

export default VirtualFAQ