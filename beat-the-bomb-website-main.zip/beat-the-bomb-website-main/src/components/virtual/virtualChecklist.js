import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from 'styled-components'

const VirtualChecklistWrapper = styled.div`
  margin-bottom: 5rem;

  .banner--normal{
    @media only screen and (max-width:500px){
      padding: 20px 0px;
    }
  }
  
  .banner h2{
    font-family: 'Acumin-Pro-700';
    font-size: 60px;
    text-transform: uppercase;
    color: #fff;

    @media only screen and (max-width: 768px){
      font-size:40px;
    }

    @media only screen and (max-width: 500px){
      font-size:22px;
    }
  }
`

const VirtualChecklistInnerWrapper = styled.div`
  max-width: 1920px;
  width:100%;
  position: relative;
  padding: 0 300px 0 250px;
  /* height: 750px; */
  display:flex;
  align-items: center;
  flex-direction: column;
  justify-content: space-between;

  @media only screen and (max-width: 1250px){
    padding: 0 175px 0 125px;
  }

  @media only screen and (max-width: 768px){
    padding: 0 90px 0 60px;
  }

  @media only screen and (max-width: 600px){
    padding: 0 10px 0 30px;
  }

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }

`

const CheckItem = styled.div`
  margin-top: 5rem;
  display:flex;
  justify-content: flex-start;
  align-items: center;
  width:100%;
  position:relative;

  .checkItem__text{
    margin-left: 1rem;
    font-family: 'Acumin-Pro-700';
    font-style: italic;
    font-weight: 700;
    font-size: 40px;
    line-height: 120%;
    letter-spacing: 0.065em;
    color: #fff;
    width:100%;

    @media only screen and (max-width: 1250px){
      font-size: 32px;
    }

    @media only screen and (max-width: 900px){
      font-size: 25px;
    }

    @media only screen and (max-width: 768px){
      font-size:20px
    }

    @media only screen and (max-width: 500px){
      font-size:16px
    }
  }

  .divider{
    position: absolute;
    bottom:0;
    left:0;
    width: 100%;
    height: 100%;
    transform: translate(10%, -25%);
    border-bottom: 4px solid var(--neon-green);

    @media only screen and (max-width:600px){
      display:none;
    }
  }

  .extra{
    position:absolute;
    top: 0;
    left:0;
    width:100%;
    height:100%;
    transform: translate(13%, 75%);

    font-family: 'Acumin-Pro';
    font-style: normal;
    font-weight: 400;
    font-size: 32px;
    line-height: 118%;
    letter-spacing: 0.065em;
    color: #fff;

    @media only screen and (max-width: 1250px){
      font-size: 24px;
    }

    @media only screen and (max-width: 900px){
      font-size: 20px;
      transform: translate(18%, 75%);
    }

    @media only screen and (max-width: 600px){
      font-size:12px;
      transform: translate(20%, 80%);
    }

  }

  @media only screen and (max-width: 600px) {
    align-items: end;
    margin-top: 2rem;
  }

  @media only screen and (max-width: 425px) {
    align-items: end;
    margin-top: 0.75rem;
  }
`

const VirtualChecklist = ({ checklist }) => {
  const { headerTitle, assets, bodyTexts } = checklist[0]
  return (
    <VirtualChecklistWrapper>
      <div className="banner banner--no-transition banner--normal banner--no-transform banner--blue">
        <h2 data-aos="fade-right" data-aos-once="true">{headerTitle}</h2>
      </div>
      <VirtualChecklistInnerWrapper>
        <CheckItem>
          <GatsbyImage alt={assets[0].title} image={getImage(assets[0].gatsbyImageData)} />
          <p className='checkItem__text'>{bodyTexts[0].text}</p>
          <div className="divider"></div>
        </CheckItem>
        <CheckItem>
          <GatsbyImage alt={assets[0].title} image={getImage(assets[0].gatsbyImageData)} />
          <p className='checkItem__text'>{bodyTexts[1].text}</p>
          <div className="divider"></div>
          <p className='extra'>{bodyTexts[2].text}</p>
        </CheckItem>
        <CheckItem>
          <GatsbyImage alt={assets[0].title} image={getImage(assets[0].gatsbyImageData)} />
          <p className='checkItem__text'>{bodyTexts[3].text}</p>
          <div className="divider"></div>
        </CheckItem>
        <CheckItem>
          <GatsbyImage alt={assets[0].title} image={getImage(assets[0].gatsbyImageData)} />
          <p className='checkItem__text checkItem__text--last'>{bodyTexts[4].text}</p>
          <div className="divider"></div>
        </CheckItem>
      </VirtualChecklistInnerWrapper>
    </VirtualChecklistWrapper>
  )
}

export default VirtualChecklist