import { graphql, useStaticQuery } from "gatsby";
import React from "react";
import { Helmet } from "react-helmet";
import PropTypes from "prop-types";

import site_image from "../../assets/images/site.jpg";

function Seo({path, seoImage, description, title }) {
  const { site } = useStaticQuery(graphql`
    query {
      site {
        siteMetadata {
          title
          siteUrl
        }
      }
    }
  `);

  const image = seoImage ? seoImage.url : site_image;
  const metaDescription = description ? description : "Discover excitement at Beat the Bomb – your ultimate destination for thrilling gaming adventures. Engage in immersive challenges, conquer puzzles, and experience unforgettable fun. Join us now!";
  const pageTitle = title ? title : "BTB | Immersive Team Building Experience";
  const site_url = site.siteMetadata.siteUrl;
  const site_name = site.siteMetadata.title

  return (
    <Helmet>
      <title>{pageTitle}</title>
      <meta name="description" content={metaDescription} />
      <meta name="url" content={site_url + path} />
      <link rel="canonical" href={site_url + path} />
      {/* Open Graph */}
      <meta property="og:title" content={pageTitle} />
      <meta property="og:description" content={metaDescription} />
      <meta property="og:type" content="website" />
      <meta property="og:url" content={site_url + path} />
      <meta property="og:image:src" content={image} />
      <meta property="og:site_name" content={site_name} />
      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={pageTitle} />
      <meta name="twitter:description" content={metaDescription} />
      <meta name="twitter:image" content={image} />
    </Helmet>
  );
}

Seo.propTypes = {
  description: PropTypes.string,
  path: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
};

export default Seo;

