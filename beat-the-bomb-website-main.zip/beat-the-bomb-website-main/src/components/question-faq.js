import React from 'react'
import styled from 'styled-components'
import ReactMarkdown from "react-markdown";
import rehypeRaw from 'rehype-raw'

import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import ExpandMore from '@mui/icons-material/ExpandMore';


const OuterWrapper = styled.div`
  max-width: 1440px;

  position: relative;
  left: 50%;
  transform: translateX(-50%);

  @media only screen and (max-width: 768px){
    padding: 0 2rem;
  }

  @media only screen and (max-width: 500px){
    padding: 0;
  }

  .accordion_container {
    background-color: rgba(255, 255, 255, 0.1);
  }

  .accordionSummary_container{
    color: var(--neon-blue);
    background-color: black;
    font-size: 18px;
  }


  .accordionDetails_container {
    color: #FFFFFF;
    font-size: 18px;
  }
`

const FaqQa = ({ q, a }) => {
  const question = q
  const answer = a
  return (
    <OuterWrapper>
    <Accordion
      className="accordion_container">
      <AccordionSummary
        expandIcon={<ExpandMore style={{color: "#FFFFFF"}}/>}
        aria-controls="panel1a-content"
        className="accordionSummary_container"
      >
        <Typography>{question}</Typography>
      </AccordionSummary>
      <AccordionDetails 
        className="accordionDetails_container">
        <Typography>
          <ReactMarkdown rehypePlugins={[rehypeRaw]} children={answer} />
        </Typography>
      </AccordionDetails>
    </Accordion>
    </OuterWrapper>
  )
}

export default FaqQa