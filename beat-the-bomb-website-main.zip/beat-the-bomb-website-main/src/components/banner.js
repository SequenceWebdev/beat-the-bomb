import React from "react";

const Banner = ({ text, subtext, angle, color, fade, tight }) => {
  const fadeDirection = fade || "right";
  return (
    <div className={`banner banner--${color || "blue"} banner--angle-${angle || 2} ${tight && "banner--tight"}`}>
      <h1 data-aos={`fade-${fadeDirection}`} data-aos-once="true">{text}</h1>
      {subtext &&
        <div className="banner__subtext-container" data-aos={`fade-${fadeDirection}`} data-aos-once="true">
          <h2 className="h2-standard">{subtext.text}</h2>
        </div>}
    </div>);
};

export default Banner;
