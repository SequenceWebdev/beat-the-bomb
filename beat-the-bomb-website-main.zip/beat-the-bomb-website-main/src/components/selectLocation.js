// React
import React from "react";
// Styles
import * as styles from "../pages/styles/leaderboards.module.css";
// import * as rootStyles from "./styles/leaderboardRoot.module.css";
// Images
import location from "../assets/images/leaderboard/location.png";
import online from "../assets/images/leaderboard/virtual.png";
import proleague from "../assets/images/leaderboard/proleague-hexagon.png";

const images = [
  {
    alt: "online",
    color: "divStyleBlue",
    src: online,
  },
  {
    alt: "location",
    color: "divStylePink",
    src: location,
  },
  {
    alt: "pro",
    color: "divStyleYellow",
    src: proleague,
  },
];

export default function mappedImages({ _handleClick, selected, pro }) {
  const mapped = images.map((image, i) => {
    if(i === 2 && !pro) return null;
    const active = selected === image.alt;
    const divStyleBlue = {
      content: "",
      display: active ? "block" : "none",
      height: "0.25rem",
      margin: "1rem auto",
      width: "20%",
      backgroundColor: "var(--neon-blue)",
    };

    const divStylePink = {
      content: "",
      display: active ? "block" : "none",
      height: "0.25rem",
      margin: "1rem auto",
      width: "20%",
      backgroundColor: "var(--neon-pink)",
    };

    const divStyleYellow = {
      content: "",
      display: active ? "block" : "none",
      height: "0.25rem",
      margin: "1rem auto",
      width: "20%",
      backgroundColor: "var(--neon-yellow)",
    };
    return (
      <div key={image.alt}>
        <div className={[styles.logoContainer, !active && styles.opaque].join(" ")}>
          { i === 0 && 
            <button onClick={_handleClick}>
              <img
              alt={image.alt}
              src={online}
              />
            </button>
            
          }
          { i === 1 &&
        
            <button onClick={_handleClick}>
              <img alt={image.alt} src={location}/>
            </button>
            
          }
          { i === 2 &&
            <button onClick={_handleClick}>
              <img
              alt={image.alt}
              src={proleague}
              />
            </button>
            
          }
        </div>
        {image.color === "divStyleBlue" && <div  style={divStyleBlue} />}
        {image.color === "divStylePink" && <div  style={divStylePink} />}
        {image.color === "divStyleYellow" && <div  style={divStyleYellow} />}
      </div>);
  });
  return (
    <div className={styles.chooseContainer}>
      {mapped}
    </div>
  );
} 