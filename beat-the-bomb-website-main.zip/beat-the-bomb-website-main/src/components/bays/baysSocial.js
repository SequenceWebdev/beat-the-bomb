import React from 'react'
import styled from 'styled-components'
import { FaInstagram, FaTiktok } from "react-icons/fa";
import EmailListForm from '../forms/emailListForm'
import { GatsbyImage, getImage } from 'gatsby-plugin-image'


const BaysSocialWrapper = styled.div`
  display:flex;
  flex-direction: column;
  align-items: center;
`

const BaysSocialInnerWrapper = styled.div`
  max-width: 1440px;
  position: relative;


  .mailingList__text{
    position:absolute;
    top:20%;
    left:0;
    width:100%;
    height:50%;

    padding: 3rem;
    display:flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;

    @media only screen and (max-width: 1024px){
      /* top:40%; */
    }

    @media only screen and (max-width: 768px){
      padding: 1rem 5px;
      top:25%;
    }

    @media only screen and (max-width: 500px){
      top:10%;
    }
  }


  .mailing__header{
    color: #fff;
    font-family: 'Acumin-Pro-700';
    font-style: italic;
    font-weight: 700;
    font-size: 50px;
    line-height: 60px;
    text-align: center;
    letter-spacing: 0.065em;
    text-transform: uppercase;
    z-index: 11;
    width:100%;

    @media screen and (max-width: 1024px) {
      font-size: 32px;
    }

    @media screen and (max-width: 768px) {
      font-size: 24px;
      padding: 0 1rem;
    }
  }

  .mailing__body{
    /* max-width: 500px; */
    margin: auto;
    color: #fff;
    z-index: 11;
    font-family: 'Acumin-Pro-L';
    font-style: italic;
    font-weight: 400;
    font-size: 40px;
    line-height: 141%;
    /* or 56px */
    text-align: center;
    letter-spacing: 0.065em;

    @media only screen and (max-width: 1250px) {
      font-size: 32px;
    }

    @media only screen and (max-width: 1024px) {
      font-size: 25px;
    }

    @media only screen and (max-width: 768px){
      padding: 0;
      font-size: 18px;
      padding: 0 1rem;
    }

    @media only screen and (max-width: 500px){
      font-size: 15px;
    }
  }

  .mailing__form_container{
    z-index: 11;
    width:100%;

    @media only screen and (max-width: 1024px){
      width:75%;
    }

    @media only screen and (max-width: 768px){
      width:60%;
    }

    @media only screen and (max-width: 500px){
      width:80%;
    }
  }

`

const BackgroundImage = styled.div`
  position: relative;

  .bgImg{
    z-index: 2;
  }

  .overlay{
    position: absolute;
    z-index: 10;
    background: linear-gradient(to bottom, rgba(0, 0, 0, 1), rgba(0, 0, 0, 0.6));
    width:100%;
    height:100%;
    top:0;
    left:0;
  }
`

const SocialIcons = styled.div`
  display: grid;
  grid-template-columns: 500px 500px;
  place-items: center;
  padding: 0 1rem;

  .button{
    font-family: 'Acumin-Pro-700';
    font-style: italic;
    padding-top:17px;

    @media only screen and (max-width:1024px){
      font-size: 25px;
      line-height: normal;
      
    }

    @media only screen and (max-width:768px){
      font-size: 15px;
      /* padding: 13px 20px 10px 20px; */
    }

    @media only screen and (max-width:500px){
      padding: 13px 20px 10px 20px;
    }
  }

  .icon__container{
    border: 5px solid var(--neon-pink);
    border-radius: 5rem;
    padding: 1rem;
    /* margin-bottom: 5rem; */

    @media only screen and (max-width: 768px){
      /* margin-bottom: 3rem; */
    }

    @media only screen and (max-width: 500px){
      border: 9px solid var(--neon-pink);
      padding: 0.5rem;
      /* margin-bottom: 2rem; */
    }

  }

  .social_icon{
    font-size: 80px;
    color: #fff;

    @media only screen and (max-width: 500px){
      font-size: 40px;
    }
  }

  .socialContainer{
    display: flex;
    flex-direction: column;
    align-items: center;
    /* margin: 0 100px; */
  }

  .socialContainer a{
    margin-top: 1rem;
  }

  @media only screen and (max-width: 1024px){
    grid-template-columns: 400px 400px;
  }
  
  @media only screen and (max-width: 768px){
    grid-template-columns: 300px 300px;
  }

  @media only screen and (max-width: 500px){
    grid-template-columns: 200px 200px;
  }

  @media only screen and (max-width: 425px){
    grid-template-columns: 150px 150px;
  }
`

const FollowContainer = styled.div`
  display: flex;
  background-color: black;
  flex-wrap: wrap;
  flex-direction: column;
  padding: 0 50px 50px 50px;
  font-family: "Acumin-Black", sans-serif;

  .row1{
    color: white;
    text-align: center;
    width: 100%;
  }

  .row1 p{
    font-family: 'Acumin-Pro';
    font-style: normal;
    font-weight: 400;
    font-size: 45px;
    letter-spacing: 0.065em;
    margin-top: 15px;

    @media only screen and (max-width:500px){
      font-size: 24px;
    }
    

  }
`

const BaysSocial = ({ context }) => {
  const { imageAssets, bodyTexts } = context[0]
  return (
    <BaysSocialWrapper>
      {/* <div className="banner banner--normal banner--angle-2 banner--blue">
        <h2 data-aos="fade-right" data-aos-once="true">{headerTitle}</h2>
      </div> */}
      
      <FollowContainer>
        <div className="row1">
          <p data-aos="fade-in" data-aos-once="true">@beatthebomb</p>
        </div>
        <SocialIcons>
          <div data-aos="fade-right" data-aos-once="true" className="socialContainer">
            <div className="icon__container">
              <FaInstagram className="social_icon"/>
            </div>
            <a className="button button--large button--pink button--text-white" href="https://www.instagram.com/beatthebomb/">Follow</a>
          </div>
          <div data-aos="fade-left" data-aos-once="true" className="socialContainer">
            <div className="icon__container">
              <FaTiktok className="social_icon"/>
            </div>
            <a className="button button--large button--blue button--text-white" href="https://www.tiktok.com/@beatthebomb">Follow</a>
          </div>
        </SocialIcons>
      </FollowContainer>

      <BaysSocialInnerWrapper>
        <BackgroundImage>
          <GatsbyImage alt="background image" className="bgImg" image={getImage(imageAssets[0].gatsbyImageData)} />
          <div className="overlay"></div>
        </BackgroundImage>
        <div className="mailingList__text">
          <h3 className="mailing__header">{bodyTexts[0].text}</h3>
          <p className="mailing__body">{bodyTexts[1].text}</p>
          <div className="mailing__form_container">
            <EmailListForm/>
          </div>
        </div> 
      </BaysSocialInnerWrapper>
      
    </BaysSocialWrapper>
  )
}

export default BaysSocial