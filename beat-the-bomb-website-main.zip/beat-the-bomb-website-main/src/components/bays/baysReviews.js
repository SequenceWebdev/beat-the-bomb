import React from 'react'
import styled from 'styled-components'
import { FcGoogle } from 'react-icons/fc'
import StarContainer from '../starContainer'
import { FaTripadvisor } from 'react-icons/fa'
import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import { Player, BigPlayButton } from 'video-react';
import poster from '../../assets/images/tiktok_poster.jpg'
import paintBlastVidPoster from "../../assets/images/winlose/winLose_poster1.png"
import { BsFillPlayFill } from "react-icons/bs";
import {IoHeartCircle, IoArrowRedoCircleSharp} from "react-icons/io5";

const BaysReviewsWrapper = styled.div`
  .banner h2{
    @media only screen and (max-width: 500px){
      font-size:28px;
    }

    @media only screen and (max-width: 425px){
      font-size:23px;
    }
  }
`

const BaysReviewsInnerWrapper = styled.div`
  max-width:1920px;
  margin-top: 7rem;

  .media__container{
    display:grid;
    grid-template-columns: repeat(2, 1fr);
    place-items: center;
    column-gap: 100px;
    row-gap: 45px;
    padding: 0 3rem;
    margin-bottom: 5rem;

    .tiktok_video{
      width:70%;
      height: auto;
      /* background-color: red; */
      /* grid-row: span 2; */
      position: relative;  
    }

    .play_icon_overlay{
      position: absolute;
      /* width:10%;
      height:5%; */
      left:0;
      bottom:3%;
    }

    .play_icon_container{
      position:absolute;
      left:0;
      bottom:0;
      display:flex;
      justify-content: center;
      align-items: flex-start;

      p{
        font-family: 'Acumin-Pro-700';
        font-style: normal;
        font-weight: 700;
        font-size: 32px;

        text-align: center;
        letter-spacing: 0.03em;

        color: #FFFFFF;

        @media only screen and (max-width: 1024px){
          font-size: 25px;
        }

        @media only screen and (max-width: 500px){
          font-size: 16px;
        }
      }
    }

    .play{
      color: #fff;
      font-size: 50px;

      @media only screen and (max-width: 1024px){
        font-size: 30px;
      }

      @media only screen and (max-width: 500px){
        font-size: 20px;
      }
    }

    .right_grid_col{
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: space-between;
      height:100%;
      row-gap: 3rem;
    }

    .top_block{
      width:100%;
      height:100%;
      /* max-height: 506px; */
      /* grid-column: 2;
      grid-row: 1; */
      /* background-color: yellow; */
      @media only screen and (max-width:768px){
        order:2;
      }
    }

    .bot_block{
      /* grid-column: 2;
      grid-row: 2; */
      /* height:50%; */
      width:100%;

      @media only screen and (max-width:768px){
        order:1;
      }
    }

    .bot_block video{
      width:100%;
      height:100%;
      /* max-height: 341px; */
    }

    @media only screen and (max-width:768px){
      display:flex;
      flex-direction: column;
      align-items: center;
      row-gap: 3rem;
      padding: 0 1rem;
    }

  }

  .review__container{
    display:flex;
    flex-direction: column;
    align-items: center;

    .review__desktopText h4, .review__mobileText h4{
      font-family: 'Pixel';
      font-style: normal;
      font-weight: 400;
      text-align: center;
      color:#ffffff;
      margin-bottom: 2rem;
    }

    .review__desktopText{
      & h4{
        font-size: 70px;
        line-height: 82px;

        @media only screen and (max-width:1250px){
          font-size: 60px;
          line-height: 70px;
        }

        @media only screen and (max-width:1024px){
          font-size: 45px;
          line-height: 53px;
        }
      }
      
      @media only screen and (max-width:768px){
        display:none;
      }
    }

    .review__mobileText{
      & h4{
        font-size: 40px;
        line-height: 47px;

        @media only screen and (max-width:500px){
          font-size: 35px;
          line-height: 41px;
        }

        @media only screen and (max-width:425px){
          font-size: 30px;
          line-height: 35px;
        }
      }

      @media only screen and (min-width:769px){
        display:none;
      }
    }
  }

  .reviews{
    display: grid;
    grid-template-columns: repeat(3,1fr);
    column-gap: 60px;
    padding: 0 80px;

    @media only screen and (max-width:1024px){
      grid-gap: 20px;
      padding: 0 1rem;
    }

    @media only screen and (max-width: 768px){
      display: flex;
      align-items: center;
      flex-direction: column;
    }
  }

  .red_outline{
    padding: 10px;
    border: 2px solid var(--neon-pink);
  }


  @media only screen and (min-width:1920px){
    position:relative;
    left:50%;
    transform: translateX(-50%);
  }

  @media only screen and (max-width:768px){
    margin-top: 3rem;
  }
`

const ReviewTestimonial = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  position: relative;
  justify-content: space-evenly;
  font-family: 'Acumin-Pro-L';
  font-size: 23px;
  line-height: 30px;
  color: #000000;
  height:100%;
  text-align: center;
  background-color: #ffffff;
  padding: 20px 60px 20px 60px;

  @media only screen and (max-width: 1250px) {
    padding: 20px;
    
  }

  @media only screen and (max-width: 900px) {
    font-size: 20px;
    padding-top: 30px;
  }

  @media only screen and (max-width: 768px) {
    padding: 10px;
    padding-top: 20px;
  }
`

const Badge = styled.div`
  position: absolute;
  top:-10%;
  right: -10%;
  width: 280px;

  @media only screen and (max-width: 1024px){
    width: 200px;
  }

  @media only screen and (max-width: 768px){
    top:-7%;
    /* width: 250px; */
  }

  @media only screen and (max-width: 500px){
    top:-10%;
    width:180px;
  }

  @media only screen and (max-width: 425px){
    width:125px;
  }

`

const Icons = styled.div`
  position: absolute;
  top:45%;
  right: -5%;
  display: flex;
  flex-direction: column;
  align-items: center;

  & p {
    font-size: 30px;
    font-family: "Montserrat",sans-serif;
    text-align: center;
    font-size: 30px;
    text-transform: uppercase;
    font-weight: 600;
    letter-spacing: .065em;
    color: white;
  }

  & .likes, & .comments, & .replies{
    display:flex;
    flex-direction: column;
    align-items: center;
    width: 80px;
  }

  .tiktok_reactIcon{
    font-size:95px;
    color:white;
  }

  @media only screen and (max-width: 1250px) {
    /* top:30%; */
    right: -10%;
    & p{
      font-size:25px;
    }

    & .likes, & .comments, & .replies{
      width: 60px;
    }

    .tiktok_reactIcon{
      font-size:75px;
      
    }
  }

  @media only screen and (max-width: 1024px){
    top:35%;
    
    & p{
      font-size:20px;
    }

    & .likes, & .comments, & .replies{
      width: 42px;
    }

    .tiktok_reactIcon{
      font-size:49px;
      
    }
  }

  @media only screen and (max-width: 768px){
    right: 0%;
    & p{
      font-size:20px;
    }

    & .likes, & .comments, & .replies{
      width: 37px;
    }

    .tiktok_reactIcon{
      font-size:45px;
      
    }
  }

  @media only screen and (max-width: 500px){
    & p{
      font-size:16px;
    }

    & .likes, & .comments, & .replies{
      width: 30px;
    }

    .tiktok_reactIcon{
      font-size:38px;
      
    }
  }
`




const BaysReviews = ({ context }) => {
  const { headerTitle, imageAssets, reviewTestimonial, bodyTexts } = context[0]
  const fullStar = imageAssets.filter(imageAsset => imageAsset.title==="star")
  return (
    <BaysReviewsWrapper>
      <div className="banner banner--normal banner--angle-2 banner--blue">
        <h2 data-aos="fade-right" data-aos-once="true">
          {headerTitle}
        </h2>
      </div>
      <BaysReviewsInnerWrapper>

        {/* media section */}
        <div className="media__container">
          <div className="tiktok_video">
            <Player src={imageAssets[0].url} muted autoPlay poster={poster} preload="auto">
              <BigPlayButton position="center" />
            </Player>

            <div className="play_icon_overlay">
              <div className="play_icon_container">
                <BsFillPlayFill className="play"/>
                <p>2.9M</p>
              </div>
            </div>

            <Icons>
              <div className="likes">
                {/* <GatsbyImage alt={tiktokLikes[0].title} placeholder="tracedSVG" image={getImage(tiktokLikes[0].gatsbyImageData)} /> */}
                <IoHeartCircle className="tiktok_reactIcon"/>
                <p>610.7K</p>
              </div>
              <div className="comments">
                <GatsbyImage alt={imageAssets[4].title} placeholder="tracedSVG" image={getImage(imageAssets[4].gatsbyImageData)} />
                <p>9017</p>
              </div>
              <div className="replies">
                {/* <GatsbyImage alt={tiktokReplies[0].title} placeholder="tracedSVG" image={getImage(tiktokReplies[0].gatsbyImageData)} /> */}
                <IoArrowRedoCircleSharp className="tiktok_reactIcon"/>
                <p>88.6K</p>
              </div>
            </Icons>

            <Badge>
              <GatsbyImage alt={imageAssets[3].title} placeholder="tracedSVG" image={getImage(imageAssets[3].gatsbyImageData)} />
            </Badge> 
          </div>
          
          <div className="right_grid_col">
            <div className="top_block">
              <GatsbyImage alt={imageAssets[1].title} image={getImage(imageAssets[1].gatsbyImageData)}/>
            </div>
            <div className="bot_block">
              <video autoPlay playsInline loop muted poster={paintBlastVidPoster}>
                <source src={imageAssets[2].url} type="video/mp4" />
              </video>
            </div>
          </div>
          
        </div>

        {/* review section */}

        <div className="review__container">
         
          <div className="review__desktopText">
            <h4>{bodyTexts[5].text}</h4>
          </div>

          {/* <div className="review__mobileText">
            <h4>{bodyTexts[6].text}</h4>
            <h4>{bodyTexts[7].text}</h4>
          </div> */}
          
          <div className="reviews">
          {reviewTestimonial.references.map((testimonial, index) =>{
            const {name, review, logo} = testimonial
            const review_text = review.review
            return(
              <div className="red_outline">
                <ReviewTestimonial key={index}>
                  <StarContainer star={fullStar[0].gatsbyImageData} />
                  <br></br>
                  <p>{review_text}</p>
                  <p>{name}</p>
                  { logo === "Google" ? <FcGoogle /> : <FaTripadvisor />}
                  
                </ReviewTestimonial>
              </div>
            
            )
          })}
          </div>
          
        </div>
      </BaysReviewsInnerWrapper>
    </BaysReviewsWrapper>
  )
}

export default BaysReviews