import React from 'react'
import styled from 'styled-components';

const AnnouncementBannerWrapper = styled.div`
  /* width: calc(100% - 20px); */
  text-align: center;
  padding: 10px;
  padding-top: 20px;
  background-color: #EE088C;
  position: relative;
  z-index: 5;

  & p, & a {
    color: black;
    font-size: 25px;
    text-align: center;
    font-family: "Acumin-BlackItalic", sans-serif;
    margin: 0;
  }

  & a{
    color: var(--neon-green);
  }

  @media screen and (max-width: 600px) {
    & p, & a {
      font-size: 20px;
    }
  }
`

const BaysAnnouncement = ({ context }) => {
  const { announcementUrl, headerTitle } = context[0]
  return (
    <AnnouncementBannerWrapper>
      { announcementUrl ? 
        <a href={announcementUrl}>{headerTitle}</a> 
        :
        <p>{headerTitle}</p>
      }
    </AnnouncementBannerWrapper>
  )
}

export default BaysAnnouncement;