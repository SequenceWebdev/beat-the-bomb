import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from 'styled-components'
import battleModePoster from "../../assets/images/battleMode/battleMode_poster.png"

const BaysExpWrapper = styled.div`
  margin-top: 7rem;
  display:flex;
  flex-direction: column;
  align-items: center;

  @media only screen and (max-width: 768px){
    margin-top: 3rem;
  }
`

const BaysExpInnerWrapper = styled.div`
  max-width:1920px;
  padding: 0 1rem;
  margin-top: 3rem;

  .exp__firstParagraph{
    font-family: 'Acumin-Pro-L';
    font-style: normal;
    font-weight: 400;
    font-size: 40px;
    line-height: 125%;
    /* or 50px */
    text-align: center;
    color:#ffffff;
    margin-bottom: 7rem;

    @media only screen and (max-width: 768px) {
      font-size: 30px;
    }

    @media only screen and (max-width: 500px) {
      font-size: 20px;
      margin-bottom: 3rem;
    }
  }

  .bookings__container{
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    column-gap: 50px;
    row-gap: 12rem;
    place-items: center;

    @media only screen and (max-width:900px){
      row-gap: 7rem;
    }

    @media only screen and (max-width:768px){
      grid-template-columns: repeat(1, 1fr);
      row-gap: 5rem;
    }
  }

  .battle_mode__container{
    margin-top: 10rem;
    display:flex;
    flex-direction: column;
    align-items: center;
    padding: 0 10px;

    @media only screen and (max-width:768px){
      margin-top: 5rem;
      padding:0;
    }

  }

  .battle_mode__topRow{
    /* margin-top: 5rem; */
    display:flex;
    flex-direction: column;
    align-items: center;

    h4{
      font-family: 'Acumin-Pro-700';
      font-style: italic;
      font-weight: 700;
      font-size: 60px;
      line-height: 165%;
      /* or 99px */

      text-align: center;
      letter-spacing: 0.065em;
      color:#ffffff;

      @media only screen and (max-width: 1250px){
        font-size: 50px;
        line-height: 82px;
      }

      @media only screen and (max-width: 900px){
        font-size: 37px;
        line-height: 64px;
      }

      @media only screen and (max-width:500px){
        font-size: 30px;
        line-height: 40px;
      }

      @media only screen and (max-width:425px){
        font-size: 25px;
        line-height: 33px;
      }
    }
  }

  .activate_mbm{
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 1rem;

    @media only screen and (max-width: 500px){
      flex-direction: column;
    }
  }

  .activate, .mission_battle_mode{
    font-family: 'Acumin-Pro-700';
    font-style: normal;
    font-weight: 700;
    font-size: 45px;
    line-height: 165%;
    /* or 74px */
    color:#ffffff;
    text-align: center;
    letter-spacing: 0.065em;
    margin: 0 0.25rem;
    padding: 0 1rem;

    @media only screen and (max-width: 1250px){
      font-size: 35px;
      line-height: 57px;
    }

    @media only screen and (max-width: 900px){
      font-size: 25px;
      line-height: 41px;
    }

    @media only screen and (max-width: 500px){
      font-size: 20px;
      line-height: 32px;
    }
  }

  .battle_mode__botRow{
    display:flex;
    align-items: center;

    @media only screen and (max-width:768px){
      flex-direction: column;
    }
  }

  .bm_botRow_leftCol{
    width:50%;
    margin-block: 3rem;

    @media only screen and (max-width:768px){
      width:100%;
    }

    @media only screen and (max-width:500px){
      margin-bottom: 0;
    }
  }

  .leftCol__text{
    font-family: 'Acumin-Pro-L';
    font-style: normal;
    font-weight: 400;
    font-size: 40px;
    line-height: 135.5%;
    padding: 0 1rem;
    /* or 54px */
    color:#ffffff;
    text-align: center;

    @media only screen and (max-width: 1250px) {
      font-size: 32px;
    }

   @media only screen and (max-width: 1024px) {
      font-size: 25px;
    }

    @media only screen and (max-width: 768px) {
      font-size: 22px;
    }

    @media only screen and (max-width: 500px) {
      font-size: 20px;
    }
  }

  .bm_botRow_rightCol{
    width:50%;

    & video{
      width:100%;
    }
    @media only screen and (max-width:768px){
      width:100%
    }
    
  }
`

const Booking = styled.div`
  display:flex;
  flex-direction: column;
  align-items: center;
  border: 1px solid red;
  position:relative;
  height:100%;
  min-height:400px;
  max-width:540px;

  .book__title{
    font-family: 'Acumin-Pro-700';
    font-style: italic;
    font-weight: 700;
    font-size: 40px;
    line-height: 48px;
    text-align: center;
    letter-spacing: 0.065em;
    text-transform: uppercase;
    color: red;
    background-color: #000000;
    transform: translateY(-50%);
    padding: 0 1rem;

    @media only screen and (max-width: 1024px) {
      font-size: 30px;
    }

    @media only screen and (max-width: 768px) {
      font-size: 25px;
    }

    @media only screen and (max-width: 500px) {
      font-size: 20px;
    }
  }

  .inner__container{
    height:100%;
    width:100%;
    display:flex;
    flex-direction:column;
    align-items: center;
    position:relative;
    border: 1px solid red;
    z-index:1;
  }

  .booking__bg_img{
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:100%;
    z-index:-1;
  }

  .button{
    font-family: 'Acumin-Pro-700';
    font-style: italic;
    padding-top:17px;
    position:absolute;
    bottom:0;
    transform: translateY(50%);

    @media only screen and (max-width:1024px){
      font-size: 25px;
      line-height: normal;
      
    }

    @media only screen and (max-width:768px){
      font-size: 15px;
      padding: 13px 20px 10px 20px;
    }
  }

  .inner__bodyContainer{
    /* position: relative;
    top:50%;
    left:50%;
    transform: translate(-50%,-50%); */
    height:100%;
    display:flex;
    align-items: center;
    justify-content: space-evenly;
    flex-direction: column;
    padding: 1rem 1rem 3rem 1rem;
  }

  .bodyContainer_text, .detailContainer_text{
    font-family: 'Acumin-Pro-L';
    font-style: normal;
    font-weight: 400;
    font-size: 32px;
    line-height: 125%;
    /* or 40px */
    color: #ffffff;
    text-align: center;
    padding:0;

    @media only screen and (max-width: 1250px) {
      font-size: 27px;
    }

    @media only screen and (max-width: 1024px) {
      font-size: 25px;
    }

    @media only screen and (max-width: 768px) {
      font-size: 20px;
    }

    @media only screen and (max-width: 500px) {
      font-size: 18px;
    }
  }

  .detailContainer_text{
    line-height: normal;
    margin:0;

  }



  &:nth-child(2){
    border: 1px solid var(--neon-blue);

    .book__title{
      color: var(--neon-blue);
    }

    .inner__container{
      border: 1px solid var(--neon-blue);
    }

    .button{
      color:white;
    }

    .button:hover{
      color:var(--neon-blue);
    }
  }

  &:nth-child(3){
    border: 1px solid var(--neon-green);

    .book__title{
      color: var(--neon-green);
    }

    .inner__container{
      border: 1px solid var(--neon-green);
    }

    .button{
      color:black;
    }

    .button:hover{
      color:var(--neon-green);
    }
  }

  &:last-child{
    border: 1px solid var(--neon-yellow);

    .book__title{
      color: var(--neon-yellow);
    }

    .inner__container{
      border: 1px solid var(--neon-yellow);
    }

    .button{
      color:white;
    }

    .button:hover{
      color:var(--neon-yellow);
    }
  }

  @media only screen and (max-width: 768px){
    max-width:350px;
    min-height: 300px;
  }

`



const BaysExp = ({ context }) => {
  const { headerTitle, bodyTexts, imageAssets, bookings } = context[0]
  return (
    <BaysExpWrapper>
      <div className="banner banner--normal banner--angle-1 banner--pink">
        <h2 data-aos="fade-right" data-aos-once="true">{headerTitle}</h2>
      </div>
      <BaysExpInnerWrapper>
        <p className='exp__firstParagraph'>{bodyTexts[0].text}</p>
        {/* booking grid layout */}
        <div className="bookings__container">
          {bookings.references.map((book, index)=>{
            return(
              <Booking key={index}>
                <h4 className="book__title">{book.title}</h4>
                <div className="inner__container">
                   <GatsbyImage alt={book.imageAssets.title} className="booking__bg_img" image={getImage(book.imageAssets.gatsbyImageData)}/>
                   <div className="inner__bodyContainer">
                    {book.bodyTexts.map((text, index)=>{
                      return index!== book.bodyTexts.length-1 ?
                        (<p className="bodyContainer_text" key={index}>{text.text}</p>):(<></>)
                    })}

                    {book.details.map((text, index) =>{
                      return(
                        <p key={index} className="detailContainer_text">{text.text}</p>
                      )

                    })}
                   </div>
                   {(index===0) && <a class="button button--large button--red button--xola" href={book.url}>{book.bodyTexts[book.bodyTexts.length-1].text}</a> }
                   {(index===1) && <a class="button button--large button--blue button--xola" href={book.url}>{book.bodyTexts[book.bodyTexts.length-1].text}</a> }
                   {(index===2) && <a class="button button--large button--green button--xola" href={book.url}>{book.bodyTexts[book.bodyTexts.length-1].text}</a> }
                   {(index===3) && <a class="button button--large button--yellow button--xola" href={book.url}>{book.bodyTexts[book.bodyTexts.length-1].text}</a> }
                </div>                
              </Booking>
            )
          })}
        </div>
        {/* mission battle mode */}
        <div className="battle_mode__container">
          {/* <div className="battle_mode__topRow">
            <h4>{bodyTexts[1].text}</h4>
            <div className="activate_mbm">
              <p className='activate'>{bodyTexts[2].text}</p>
              <p className='mission_battle_mode'>{bodyTexts[3].text}</p>
            </div>
            
          </div> */}
          <div className="battle_mode__botRow">
            <div className="bm_botRow_leftCol">
              <p className="leftCol__text">{bodyTexts[1].text}</p>
            </div>
            <div className="bm_botRow_rightCol">
              <video autoPlay playsInline loop muted poster={battleModePoster}>
                <source src={imageAssets[0].url} type="video/mp4" />
              </video>
            </div>
          </div>
        </div>

      </BaysExpInnerWrapper>


    </BaysExpWrapper>
  )
}

export default BaysExp