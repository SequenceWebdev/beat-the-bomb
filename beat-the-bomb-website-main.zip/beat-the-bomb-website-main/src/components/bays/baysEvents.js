import React from 'react'
import styled from 'styled-components'
import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import CompLogoScroller from '../compLogoScroller' 

import Slider from "react-slick";
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";

const BaysEventsWrapper = styled.div`
  .banner{
    margin-bottom: -35px;

    @media only screen and (max-width:1024px){
      margin-bottom: -20px;
    }

    @media only screen and (max-width:768px){
      margin-bottom: -5px;
    }
  }

  .banner h2{
    @media only screen and (max-width: 500px){
      font-size:31px;
    }

    @media only screen and (max-width: 425px){
      font-size:27px;
    }
  }
`

const BaysEventsInnerWrapper = styled.div`
  max-width: 1920px;

 .button{
    font-family: 'Acumin-Pro-700';
    font-style: italic;
    padding-top:17px;
    padding-left:0;
    padding-right:0;
    width:22%;
    margin-top:3rem;
    margin-bottom: 5rem;

    @media only screen and (max-width:1024px){
      font-size: 25px;
      line-height: normal;
      
    }

    @media only screen and (max-width:768px){
      margin-top:1rem;
      margin-bottom: 2rem;
      font-size: 15px;
      width:auto;
      padding: 13px 20px 10px 20px;
    }
  }

  .slider__viewer{
    display: flex;
    align-items: center;
    justify-content: center;

    @media only screen and (max-width:500px){
      flex-direction: column;
    }
  }

  .slider__container{
    width:100%;
    /* width: 27%;

    @media only screen and (max-width: 500px){
      width:100%;
    }

    @media (min-width: 501px) and (max-width: 768px){
      width:34%
    }

    @media (min-width: 769px) and (max-width: 1024px){
      width:30%
    } */
  }
  
  .pe_header{
    font-family: 'Acumin-Pro-700';
    font-style: normal;
    font-weight: 700;
    font-size: 45px;
    line-height: 54px;
    text-align: center;
    letter-spacing: 0.065em;
    text-transform: uppercase;
    color: #ffffff;
    margin-bottom: 0;

    @media screen and (max-width: 1250px) {
      font-size: 32px;
    }

    @media screen and (max-width: 1024px) {
      font-size: 25px;
    }

    @media screen and (max-width: 768px) {
      font-size: 20px;
    }

    @media screen and (max-width: 500px) {
      font-size: 18px;

    }
  }

  .comp_logo_header{
    font-family: 'Acumin-Pro-700';
    font-style: normal;
    font-weight: 700;
    font-size: 45px;
    line-height: 54px;
    text-align: center;
    letter-spacing: 0.065em;
    color: #ffffff;

    padding: 0 3rem;

    @media screen and (max-width: 1024px) {
      font-size: 32px;
    }

    @media screen and (max-width: 768px) {
      font-size: 24px;
      padding: 0 1rem;
      line-height:normal;
    }

    @media screen and (max-width: 500px) {
      font-size: 18px;

    }
  }

  .pro_league__bodyText{
    font-family: 'Acumin-Pro-L';
    font-style: normal;
    font-weight: 400;
    font-size: 40px;
    line-height: 125%;
    /* or 50px */
    padding: 0 5rem;
    text-align: center;
    color:#ffffff;
    margin-block: 3rem;
    padding: 0 3rem;

    @media only screen and (max-width: 1024px) {
      font-size: 25px;
    }

    @media only screen and (max-width: 500px) {
      font-size: 20px;
    }
  }

  .pe_body{
    font-family: 'Acumin-Pro-L';
    font-style: normal;
    font-weight: 400;
    font-size: 40px;
    line-height: 125%;
    /* or 50px */
    text-align: center;
    color:#ffffff;
    margin-top: 3rem;
    margin-bottom: 3rem;
    padding: 0 3rem;

    @media only screen and (max-width: 1024px) {
      font-size: 25px;
      margin-top: 1rem;
      margin-bottom: 2rem;
    }

    @media only screen and (max-width: 500px) {
      font-size: 20px;
    }
  }

  .company__container{
    display:flex;
    align-items: center;
    flex-direction: column;
  }

  .comp_logo_container{
    display:flex;
    align-items: center;
  }

  .league__container{
    display:flex;
    align-items: center;
    flex-direction: column;

    .pro_league_logo{
      width:36%;

      @media only screen and (max-width: 768px){
        width:75%;
      }
    }
  }

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }
`

const ImageGallery = styled.div`
  display:grid;
  grid-template-columns: repeat(3,1fr);
  margin-bottom: 2rem;

  @media only screen and (max-width: 768px){
    display:flex;
    flex-direction: column;
    align-items: center;
  }
`

const SlideItem = styled.div`
  width:100%;
  & p{
    font-family: 'Acumin-Pro-700';
    font-style: normal;
    font-weight: 700;
    font-size: 40px;
    text-align: center;
    letter-spacing: 0.065em;
    text-transform: uppercase;
    color: var(--neon-pink);
    margin-bottom: 0;

    @media screen and (max-width: 1250px) {
      font-size: 32px;
    }

    @media screen and (max-width: 1024px) {
      font-size: 25px;
    }

    @media screen and (max-width: 768px) {
      font-size: 20px;
    }

    @media screen and (max-width: 500px) {
      font-size: 18px;

    }
  }

`


const BaysEvents = ({ pEvents, slider, companies, league }) => {
  const { headerTitle, imageAssets, bodyTexts } = pEvents[0]
  const pe_images = imageAssets
  const settings = {
    arrows: false,
    autoplay: true,
    dots: false,
    infinite: true,
    pauseOnFocus: false,
    pauseOnHover: false,
    slidesToScroll: 1,
    slidesToShow: 1,
    speed: 500,
  };


  return (
    <BaysEventsWrapper>
      <div className="banner banner--normal banner--angle-1 banner--pink">
        <h2 data-aos="fade-right" data-aos-once="true">{headerTitle}</h2>
      </div>
      <BaysEventsInnerWrapper>
        {/* image banner */}
        <ImageGallery>
          {pe_images.map((image, index)=>{
            return(
              <GatsbyImage alt={image.title} key={index} image={getImage(image.gatsbyImageData)}/>
            )
          })}
        </ImageGallery>


        <h4 className='pe_header'>{bodyTexts[0].text}&nbsp;</h4> 
          <div className="slider__container">
            <Slider {...settings}>
              {slider[0].bodyTexts.map((text, index) =>{ 
                return (
                  <SlideItem key={index}>
                    <p>{text.text}</p>
                    <div className="divider"></div>
                  </SlideItem>
                )
              })}
            </Slider>
          </div>
        <h4 className='pe_header'>&nbsp;{bodyTexts[1].text}</h4>
          
        {/* <div className="slider__viewer">
          <h4 className='pe_header'>{bodyTexts[0].text}&nbsp;</h4> 
          <div className="slider__container">
            <Slider {...settings}>
              {slider[0].bodyTexts.map((text, index) =>{ 
                return (
                  <SlideItem key={index}>
                    <p>{text.text}</p>
                    <div className="divider"></div>
                  </SlideItem>
                )
              })}
            </Slider>
          </div>
          <h4 className='pe_header'>&nbsp;{bodyTexts[1].text}</h4>
        </div> */}

        <p className="pe_body">{bodyTexts[2].text}</p>

        {/* carousel logo */}
        <div className="company__container">
          <h4 className='comp_logo_header'>{bodyTexts[3].text}</h4>
          <div className="comp_logo_container">
            <CompLogoScroller assets={companies[0].imageAssets} page="Home"/>
          </div>
          <a className="button button--large button--pink button--text-white" href="mailto:groupsales@beatthebomb.com">Email Us</a>
        </div>
        

        {/* gatsby image */}
        <div className="league__container">
          <GatsbyImage alt={league[0].imageAssets[0].title} className="pro_league_logo" image={getImage(league[0].imageAssets[0].gatsbyImageData)}/>
          <p className='pro_league__bodyText'>{league[0].bodyTexts[0].text}</p>

          {/* gatsby image */}
          <GatsbyImage alt={league[0].imageAssets[1].title} image={getImage(league[0].imageAssets[1].gatsbyImageData)}/>
        </div>
        
      </BaysEventsInnerWrapper>
    </BaysEventsWrapper>
  )
}

export default BaysEvents