import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from 'styled-components'
import { Carousel } from "react-bootstrap";

const BaysHeroWrapper = styled.div`
  margin-bottom: 3rem;

  .banner h2{
    @media only screen and (min-width: 376px){
      font-size:26px;
    }

    @media only screen and (min-width: 426px){
      font-size:30px;
    }

    @media only screen and (min-width: 501px){
      font-size:40px;
    }

    @media only screen and (min-width: 769px){
      font-size:58px;
    }

    @media only screen and (min-width: 1025px){
      font-size:79px;
    }

    @media only screen and (min-width: 1251px){
      font-size:82px;
    }
    
  }
`


const CarouselContainer = styled.div`
  position: relative;
  margin-bottom: 1rem;
  max-width: 1920px;

  .cItem{
    padding:0px 0px 50px 0px;
  }

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }
`

const BodyText = styled.div`
  max-width: 1920px;
  display:flex;
  align-items: center;
  flex-direction: column;

  .button{
    font-family: 'Acumin-Pro-700';
    font-style: italic;
    font-weight: 700;
    margin: 0.5rem 0 2rem 0;
    padding-top:17px;

    @media only screen and (max-width:1024px){
      font-size: 25px;
      line-height: normal;
      
    }

    @media only screen and (max-width:768px){
      font-size: 15px;
      padding: 13px 20px 10px 20px;
    }
  }

  p{
    margin: 10px auto;
    padding: 0 20px;
    font-family: 'Acumin-Pro-L';
    font-size: 40px;
    /* letter-spacing: -1.5px; */
    color: #fff;
    text-align: center;
  }

  @media only screen and (max-width: 768px) {
    p{
      font-size: 30px;
    }
  }

  @media only screen and (max-width: 500px) {
    p{
      font-size: 20px;
    }
  }

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }
  
`

const BaysHero = ({ context }) => {
  const { headerTitle, imageAssets, bodyTexts } = context[0]
  return (
    <BaysHeroWrapper>
      <div className="banner banner--no-transition banner--normal banner--no-margin banner--no-transform banner--blue">
        <h2>
          {headerTitle}
        </h2>
      </div>
      <CarouselContainer>
        <Carousel controls={false}>
          <Carousel.Item interval={5000} className="cItem">
            <GatsbyImage loading="eager" imgStyle={{objectFit:"contain"}} image={getImage(imageAssets[0].gatsbyImageData)} alt={imageAssets[0].title}/>
          </Carousel.Item>
          <Carousel.Item interval={5000} className="cItem">
            <GatsbyImage loading="eager" imgStyle={{objectFit:"contain"}} image={getImage(imageAssets[1].gatsbyImageData)} alt={imageAssets[1].title}/>
          </Carousel.Item>
          <Carousel.Item interval={5000} className="cItem">
            <GatsbyImage loading="eager" imgStyle={{objectFit:"contain"}} image={getImage(imageAssets[2].gatsbyImageData)} alt={imageAssets[2].title}/>
          </Carousel.Item>
          <Carousel.Item interval={5000} className="cItem">
            <GatsbyImage loading="eager" imgStyle={{objectFit:"contain"}} image={getImage(imageAssets[3].gatsbyImageData)} alt={imageAssets[3].title}/>
          </Carousel.Item>
        </Carousel>
      </CarouselContainer>

      <BodyText>
        <a className="button button--large button--blue button--xola" href="https://checkout.xola.com/index.html#buttons/62cc442c2336e83b091d3183?cache=1657826395802">
            {bodyTexts[2].text}
        </a>
        
        {bodyTexts.map((text, index)=>{
          return index ===2 ?
          (<></>):(<p key={index}>{text.text}</p>)
        })}
      </BodyText>
      

    </BaysHeroWrapper>
  )
}

export default BaysHero