import React from 'react'
import styled from 'styled-components'
import { GatsbyImage, getImage } from 'gatsby-plugin-image'

const BayGameWrapper = styled.div`
  display:flex;
  flex-direction: column;
  align-items: center;

  & .modal_mission_title{
    font-family: "Pixel", monospace;
    font-style: italic;
    font-size: 85px;
    text-align: center;
    margin-bottom: 1rem;

    @media only screen and (max-width: 768px){
      font-size: 60px;
      padding: 1rem 0;
    }

    @media only screen and (max-width: 500px){
      font-size: 40px;
    }
  }

  .modal_mission_descrip{
    font-family: 'Acumin-Pro';
    font-style: normal;
    font-weight: 700;
    font-size: 45px;
    line-height: 60px;
    /* or 133% */
    color: #ffffff;
    text-align: center;
    letter-spacing: 0.065em;

    @media screen and (max-width: 1024px) {
      font-size: 32px;
    }

    @media screen and (max-width: 768px) {
      font-size: 24px;
      padding: 0 1rem;
      line-height: normal;
    }

    @media screen and (max-width: 500px) {
      font-size: 20px;

    }
  }

  .button{
    margin-top: 3rem;
    margin-bottom: 3rem;
    font-family: 'Acumin-Pro-700';
    font-style: italic;
    font-weight: 700;
    padding-top:17px;
    padding-left: 0;
    padding-right: 0;
    width:25%;

    @media only screen and (max-width:1250px){
      font-size: 30px;
      line-height: normal;
      
    }

    @media only screen and (max-width:1024px){
      font-size: 25px;
    }

    @media only screen and (max-width:768px){
      font-size: 15px;
      padding: 13px 20px 10px 20px;
      margin-top:1rem;
      margin-bottom: 3rem;
      width:45%;
    }
  }
`

const GameInfo = styled.div`
  margin-top:3rem;
  display:flex;
  width:100%;
  flex-direction: column;
  align-items: center;

  .gameInfo__text{
    width:100%;
    /* padding: 0 1rem; */
    display:flex;
    flex-direction: column;
    align-items: left;
  }

  .gameType_name, .gameType_desc{
    font-family: 'Acumin-Pro';
    font-style: italic;
    font-weight: 700;
    font-size: 50px;
    line-height: 120%;
    letter-spacing: 0.065em;
    text-transform: uppercase;
    color: var(--neon-blue);

    @media only screen and (max-width: 1250px) {
      font-size: 35px;
    }

    @media only screen and (max-width: 1024px) {
      font-size: 30px;
    }

    @media only screen and (max-width: 768px) {
      font-size: 25px;
    }

    @media only screen and (max-width: 500px) {
      font-size: 22px;
    }
  }

  .gameType_name{
    color: var(--neon-blue);
  }

  .gameType_desc{
    color: #ffffff;
  }
`

const GameRow = styled.div`
  display:flex;
  align-items: center;
  justify-content: space-evenly;

  .single_game{
    display:flex;
    flex-direction: column;
    align-items: center;
    position:relative;
    margin: 0 2rem 0.5rem 2rem;

    /* @media only screen and (max-width: 768px){
      margin: 0 0rem 1rem 0rem;
    } */
  }

  .game_description{
    font-family: 'Acumin-Pro-L';
    font-style: normal;
    font-weight: 400;
    font-size: 32px;
    line-height: 125%;
    /* or 40px */
    color:#ffffff;
    text-align: center;
    @media only screen and (max-width: 1250px) {
      font-size: 25px;
    }

    @media only screen and (max-width: 1024px) {
      font-size: 22px;
    }

    @media only screen and (max-width: 768px){
      position:relative;
      top:-32px;
      font-size: 20px; 
    }

    @media only screen and (max-width: 500px){
      top:-38px;
  
    }
  }

  @media only screen and (max-width: 768px){
    flex-direction: column;
  }
`

const BaysGame = ({ missionCategories, missionTitle, missionDescription, url }) => {

  return (
    <BayGameWrapper>
      <h2 className='modal_mission_title'>{missionTitle}</h2>
      <p className='modal_mission_descrip'>{missionDescription[0].text}</p>
      <a className="button button--pink button--text-white" href={url}>Book Now</a>
      <p className='modal_mission_descrip'>{missionDescription[1].text}</p>
      {missionCategories.references.map((cat, index) => {
        const { gameType, gameTypeDescription, missionGames } = cat
        return(
          <GameInfo key={index}>
            <div className="gameInfo__text">
              <h4 className="gameType_name">{gameType}</h4>
              <h4 className="gameType_desc">{gameTypeDescription}</h4>
            </div>
            
            <GameRow key={index}>
              {missionGames.references.map((game,index) =>{
                const {name, gameDescription, gameMissionImageAssets} = game
                return(
                    <div className="single_game" key={index}>
                      <GatsbyImage alt={name} image={getImage(gameMissionImageAssets[0].gatsbyImageData)}/>
                      <p className='game_description'>{gameDescription.gameDescription}</p>
                    </div>
                )
              })}
            </GameRow>
            
          </GameInfo>
        )
      })}
    </BayGameWrapper>
  )
}

export default BaysGame