import React from 'react'
import styled from 'styled-components'
import Mission from '../home/mission.js'
import BaysMission from './baysMission.js'

import { Carousel } from "react-bootstrap";

const BaysGamesInnerWrapper = styled.div`
  max-width:1920px;
  padding: 0rem 3rem;

  .body_text{
    font-family: "Acumin-Black",sans-serif;
    font-size: 45px;
    letter-spacing: .065em;
    color: #fff;
    text-align: center;
    margin-bottom: 1rem;
    padding-top:1rem;
  }

  & a{
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }

  @media screen and (max-width: 768px) {
    padding: 0 1rem;
    .body_text{
      font-size: 25px;
    }
  }

  @media screen and (max-width: 500px) {
    .body_text{
      font-size: 20px;
    }
  }

  @media screen and (max-width: 425px) {
    .body_text{
      font-size: 18px;
    }
  }
`

const CarouselContainer = styled.div`
  position: relative;
  margin-bottom: 1rem;
  max-width: 1920px;

  .carousel-control-prev{
    position: absolute;
    left:45%;
    top:95%;
  }

  .carousel-control-next{
    position: absolute;
    left:55%;
    top:95%;
  }

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }
`

const BaysMissions = ({ context }) => {
  const { headerTitle, bodyTexts, missions } = context[0]
  const mission1 = missions.references[0]
  const mission2 = missions.references[1]
  const bay = missions.references[2]
  return (
    <>
      <div className="banner banner--normal banner--angle-2 banner--blue">
        <h2 data-aos="fade-right" data-aos-once="true">{headerTitle}</h2>
      </div>
      <BaysGamesInnerWrapper>
        {/* <BaysMission mission={mission1} buttonText={bodyTexts[0].text}/> */}
        <CarouselContainer>
          <Carousel interval={null} indicators={false}>
            <Carousel.Item className="cItem">
              <Mission mission={mission1} buttonText={bodyTexts[0].text}/>
            </Carousel.Item>
            <Carousel.Item className="cItem">
              <Mission mission={mission2} buttonText={bodyTexts[0].text}/>
            </Carousel.Item>
          </Carousel>
        </CarouselContainer>

        <BaysMission mission={bay} buttonText={bodyTexts[0].text}/>
      </BaysGamesInnerWrapper>

    </>
  )
}

export default BaysMissions