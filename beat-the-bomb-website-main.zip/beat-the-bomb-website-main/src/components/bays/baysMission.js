import React, { useState } from 'react'
import styled from 'styled-components'
import { GatsbyImage, getImage } from 'gatsby-plugin-image'

import 'react-responsive-modal/styles.css';
import '../styles/modal.css'
import { Modal } from 'react-responsive-modal';

import {AiOutlineClose} from 'react-icons/ai'
import BaysGame from './baysGame';

const BaysMissionWrapper = styled.div`
  margin-top: 10rem;
  position:relative;
  /* display:flex;
  align-items: center;
  flex-direction: column; */
  max-width:1086px;
  left:50%;
  transform:translateX(-50%);

  .title__container{
    background-color: #FFFFFF;
    height: 270px;
    width:80%
  }

  .mission_logo{
    width:83%;
    height:41%;
    position:absolute;
    left:50%;
    top:0%;
    z-index:1;
    transform: translate(-50%,-50%);
  }

  .mission__container{
    max-width:1440px;
    display:flex;
    align-items:center;
    justify-content: center;
    border: 2px solid #FFFFFF;
    padding: 0;
    z-index:-1;


    /* @media only screen and (max-width:768px){
      padding: 0;
    } */
  }

  .button{
    margin-top: 3rem;
    margin-bottom: 5rem;
    width:41%;

    font-family: 'Acumin-Pro-700';
    font-style: italic;
    padding-top:17px;

    position:relative;
    left:50%;
    transform: translate(-50%);
    
    @media only screen and (max-width:1024px){
      font-size: 25px;
      line-height: normal;
      
    }

    @media only screen and (max-width:768px){
      font-size: 15px;
      padding: 13px 20px 10px 20px;
      width:43%;
    }
  }

  @media only screen and (max-width:500px){
    margin-top:5rem;
  }
`

const BaysMission = ({ mission, buttonText }) => {
  const { gameMissionTitle, missionDescription, missionImages, missionCategories, url } = mission
  const [open, setOpen] = useState(false);

  const onOpenModal = () => setOpen(true);
  const onCloseModal = () => setOpen(false);

  const closeIcon = (<AiOutlineClose color='white' size={36} />);

  return (
    <>
      <BaysMissionWrapper>
        <GatsbyImage alt={missionImages[0].title} objectFit="contain" className="mission_logo" image={getImage(missionImages[0].gatsbyImageData)}/>
        <div className="mission__container">
          <GatsbyImage alt={gameMissionTitle.title} image={getImage(missionImages[1].gatsbyImageData)} />
        </div>
        <button type="button" className="button button--large button--blue button--text-white" onClick={onOpenModal}>{buttonText}</button>
      </BaysMissionWrapper>
      <Modal 
      open={open} 
      onClose={onCloseModal} 
      center 
      showCloseIcon 
      classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      closeIcon={closeIcon}>
        <BaysGame missionCategories={missionCategories} missionTitle={gameMissionTitle} missionDescription={missionDescription} url={url}/>
      </Modal>

    </>
  )
}

export default BaysMission