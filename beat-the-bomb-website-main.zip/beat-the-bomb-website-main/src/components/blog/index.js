import BlogPage from "./blog-page";

export {
  BlogPage,
};