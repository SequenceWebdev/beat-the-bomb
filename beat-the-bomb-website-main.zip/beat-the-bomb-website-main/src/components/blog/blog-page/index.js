import { GatsbyImage, getImage } from 'gatsby-plugin-image';
import React from 'react';
import styled from 'styled-components';
import { documentToReactComponents } from '@contentful/rich-text-react-renderer'
import { BLOCKS } from '@contentful/rich-text-types'

const BlogOuterWrapper = styled.div`
  width: 100%;
  margin-top: 3rem;


  .content{
    width: 100%;
    max-width: 1920px;
    margin-left: auto;
    margin-right: auto;
    padding-left: 128px;
    padding-right: 128px;

    @media only screen and (max-width: 900px){
      padding: 0 20px;
    }
  }

  .top-content {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    column-gap: 3rem;
    margin-bottom: 2rem;
  }

  .top-content--left {
    width: 70%;

    h1 {
      font-family: 'Acumin Pro';
      font-style: normal;
      font-weight: 700;
      font-size: 60px;
      color: #FFFFFF;
      text-align: left;
      width: 100%;

      @media only screen and (max-width: 1600px){
        font-size: 54px;
      }
      
      @media only screen and (max-width: 1440px){
        font-size: 48px;
      }

      @media only screen and (max-width: 1024px){
        font-size: 42px;
      }

      @media (max-width: 900px){
        font-size: 36px;
      }

      @media (max-width: 480px){
        font-size: 22px;
      }
    }
  }

  .top-content--right {
    width: 30%;
  }

  .blog-info {
    color: #FFFFFF;
    margin-bottom: 2rem;
    h4 {
      font-family: "Acumin Pro";
      font-weight: 400;
    }

    a {
      font-family: "Acumin Pro";
      font-weight: 400;
      text-decoration: underline;
    }

    p {
      font-family: "Acumin Pro";
      font-weight: 300;
    }
  }
`

const RichTextContainer = styled.div`
  width: 100%;
  margin-left: auto;
  margin-right: auto;
  margin-bottom: 2rem;

  .rich_paragraph{
    font-family: "Acumin Pro";
    font-style: normal;
    font-weight: 300;
    font-size: 33px;
    line-height: 133%;
    color: #FFFFFF !important;
    margin-bottom: 2rem;
    text-align: left;

    a {
      text-decoration: underline;
    }

    @media only screen and (max-width: 1600px){
      font-size: 24px;
    }
    
    @media only screen and (max-width: 1440px){
      font-size: 20px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 18px;
    }

    @media only screen and (max-width: 900px){
      font-size: 16px;
    }

    @media only screen and (max-width: 480px){
      font-size: 15px;
      line-height: 18px;
    }
  }
`

const RICHTEXT_OPTIONS = {
  renderNode: {
    [BLOCKS.PARAGRAPH]: (node, children) =>{
      return children!='' && (<p className='rich_paragraph'>{children}</p>)
    },
  }
}

const BlogPage = ({ data }) => {
  const json_text = JSON.parse(data.richText.raw);
  return (
    <BlogOuterWrapper>
      <div className="content">
        <div className="top-content">
          <div className="top-content--left">
            <h1>{data.blogTitle}</h1>
          </div>
          {/* <div className="top-content--right">
            <GatsbyImage alt={data.image.title} image={getImage(data.image.gatsbyImageData)}/>
          </div> */}
        </div>

        <div className="blog-info">
          <h4>News Provided By<br/>
            <a href={data.sourceUrl}>{data.sourceLabel}</a>
          </h4>
          <p>{data.publishedTime} ET</p>
        </div>

        <RichTextContainer>
          {documentToReactComponents(json_text, RICHTEXT_OPTIONS)}
        </RichTextContainer>
      </div>
    </BlogOuterWrapper>
  )
}

export default BlogPage;