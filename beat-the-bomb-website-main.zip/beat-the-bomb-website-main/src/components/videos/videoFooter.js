import React from 'react'
import styled from 'styled-components'

const VideoFooterWrapper = styled.div`
  margin-bottom: 5rem;
`
const VideoFooterInnerWrapper = styled.div`
  max-width: 1920px;
  background-image: url(${(props)=>props.imgUrl});
  background-position: 100% 100%;
  background-repeat: no-repeat;
  max-height: 900px;
  height: 900px;
  padding-left: 100px;
  background-size: contain;
  position: relative;

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }

  @media screen and (max-width: 768px) {
    padding: 10px;
    height: 400px;
    /* background-position: bottom; */
    /* background-size: 100%; */
    
  }

  @media screen and (max-width: 500px) {
    background-size: cover;
    
  }
`

const FooterText = styled.div`
  display:flex;
  align-items: center;
  flex-direction: column;
  text-align: center;
  color:white;
  padding: 0 20px;

  position: absolute;
  top:50%;
  left:50%;
  transform: translate(-75%, -50%);
  
  font-style: normal;
  font-weight: 900;
  text-shadow: 0 1px 5px rgb(0 0 0 / 50%);

  h2{
    font-family: "Acumin-Bold";
    font-size: 64px;
    line-height: 77px;
    color: #fff;
    

    @media only screen and (max-width: 768px){
      font-size: 35px;
      line-height: 42px;
    }
  }

  & p{
    font-family: 'Acumin-Pro';
    font-size: 22px;
    line-height: 26px;

    @media only screen and (max-width: 768px){
      font-size: 16px;
      line-height: 19px;
    }
  }

  @media only screen and (max-width: 768px){
    width:100%;
    transform: translate(-50%, -50%);
    
  }

`


const VideoFooter = ({ footer }) => {
  const { bodyTexts, backgroundImage } = footer[0]

  return (
    <VideoFooterWrapper>
      <VideoFooterInnerWrapper imgUrl={backgroundImage.gatsbyImageData.images.fallback.src}>
        <FooterText>
          <h2>{bodyTexts[0].text}</h2>
          <p>{bodyTexts[1].text}</p>
          <a class="button button--blue" href="mailto:info@beatthebomb.com">{bodyTexts[2].text}</a>
        </FooterText>
      </VideoFooterInnerWrapper>
    </VideoFooterWrapper>
  )
}

export default VideoFooter