import React from 'react'
import styled from 'styled-components'
import { Link } from 'gatsby'

//Bootstrap
import { Carousel } from "react-bootstrap";

const VideoCarouselWrapper = styled.div`
  margin-bottom: 5rem;

  h2{
    text-align: center;
    font-family: "Pixel",monospace;
    font-style: normal;
    font-weight: 400;
    font-size: 48px;
    line-height: 55px;
    text-align: center;
    color: #fff;
    margin-bottom: 45px;
    padding: 0 30px;

    @media only screen and (max-width: 768px){
      font-size: 30px;
      line-height: 29px;
    }
  }
`

const VideoCarouselInnerWrapper = styled.div`
  max-width: 1920px;

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }
`

const SlideWrapper = styled.div`
  display:flex;
  justify-content: center;
  align-items: center;
  padding: 0 150px;
  column-gap: 10px;
  margin-bottom: 5rem;

  .video_container{
    width:50%;

    & iframe{
      width:100%;
      height:350px;
    }

    @media only screen and (max-width: 768px){
      width: 100%;
    }

  }

  .text_container{
    display:flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    width:50%;
    color: #fff;

    h3{
      font-family: "Pixel",monospace;
      font-style: normal;
      font-weight: 400;
      font-size: 36px;
      line-height: 42px;
      color: #fff;

      @media only screen and (max-width: 768px){
        font-size: 25px;
        line-height: 29px;
      }
    }

    p{
      font-family: 'Acumin-Pro';
      font-style: normal;
      font-weight: 300;
      font-size: 18px;
      line-height: 22px;
      color: #fff;
      margin-bottom: 50px;

      @media only screen and (max-width: 768px){
        font-size: 16px;
        line-height: 19px;
        margin-bottom: 1rem;
      }
    }

    @media only screen and (max-width:768px){
      width:100%;
    }
  }

  @media only screen and (max-width: 768px){
    padding: 0 100px;
    flex-direction: column;
  }

  @media only screen and (max-width: 500px){
    padding: 0 2rem;
  }
`


const VideoCarousel = ({carousel}) => {
  const { bodyTexts, carouselItems } = carousel[0]
  const slides = carouselItems.references 
  return (
    <VideoCarouselWrapper>
      <h2>{bodyTexts[0].text}</h2>
      <VideoCarouselInnerWrapper>
        <Carousel>
          {slides.map((slide, index) =>{

            function hrefUrl(){
              if(slide.isOnline === true){
                if(index%2===0){
                  return (<Link class="button button--pink" to="/virtual">Book Now</Link>)
                }
                return (<Link class="button button--blue" to="/virtual">Book Now</Link>)
              }

              if(index%2===0){
                return (<a class="button button--pink xola-checkout" href="https://checkout.xola.com/index.html#buttons/61703987a2d9f8052c6bb522">Book now</a>)
              }
              return (<a class="button button--blue xola-checkout" href="https://checkout.xola.com/index.html#buttons/61703987a2d9f8052c6bb522">Book now</a>)
            }

            return(
              <Carousel.Item key={index} >
                <SlideWrapper>
                  <div className="video_container">
                    <iframe loading="lazy" title={slide.carouselHeader} src={slide.videoUrl}></iframe>
                  </div>
                  <div className="text_container">
                    <h3>{slide.carouselHeader}</h3>
                    <p>{slide.carouselDescription.carouselDescription}</p>
                    {hrefUrl()}
                  </div>
                </SlideWrapper>
              </Carousel.Item>
            )
          })}
        </Carousel>
      </VideoCarouselInnerWrapper>
    </VideoCarouselWrapper>
  )
}

export default VideoCarousel