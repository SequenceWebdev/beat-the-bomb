import React from 'react'
import styled from "styled-components"

const VideoHeroWrapper = styled.div`
  margin-bottom: 5rem;
`

const VideoHeroInnerWrapper = styled.div`
  max-width: 1920px;
  background-image: url(${(props)=>props.imgUrl});
  background-position: -250px 50%;
  background-repeat: no-repeat;
  max-height: 900px;
  height: 900px;
  padding-right: 100px;
  background-size: contain;
  
  position:relative;

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }

  @media screen and (max-width: 768px) {
    padding: 10px;
    height: 400px;
    background-position: bottom;
    
  }

  @media screen and (max-width: 500px) {
    background-size: cover;
    
  }
`

const HeroText = styled.div`
  display:flex;
  align-items: center;
  flex-direction: column;
  text-align: center;
  color:white;
  padding: 0 20px;
  z-index: 5;

  position: absolute;
  top:50%;
  left:50%;
  transform: translate(0%,-50%);
  font-style: normal;
  font-weight: 900;

  & h1{
    font-family: "Acumin-Bold";
    font-size: 64px;
    line-height: 77px;
    text-transform: uppercase;
    text-shadow: 0 1px 5px rgb(0 0 0 / 50%);

    @media only screen and (max-width: 768px){
      font-size: 35px;
      line-height: 42px;
    }
  }

  & p{
    font-family: 'Acumin Pro';
    font-size: 22px;
    line-height: 26px;

    @media only screen and (max-width: 768px){
      font-size: 16px;
      line-height: 19px;
    }
  }

  @media only screen and (max-width: 768px){
    width:100%;
    transform: translate(-50%,-50%);
    
  }
`

// const Overlay = styled.div`
//   position: absolute;
//   top:0;
//   left:0;
//   width:100%;
//   height:100%;
//   background: linear-gradient(to bottom right, rgba(0,0,0,0.6) 1%, rgba(0,0,0,0));
//   z-index: 2;
// `

const VideoHero = ({ hero }) => {
  const { bodyTexts, backgroundImage } = hero[0]
  return (
    <VideoHeroWrapper>
      <VideoHeroInnerWrapper imgUrl={backgroundImage.gatsbyImageData.images.fallback.src}>
        <HeroText>
          <h1>{bodyTexts[0].text}</h1>
          <p>{bodyTexts[1].text}</p>
          <a class="button button--pink" href="https://www.youtube.com/c/BeatTheBomb?sub_confirmation=1">{bodyTexts[2].text}</a>
        </HeroText>
        {/* <Overlay></Overlay> */}
      </VideoHeroInnerWrapper>
      
    </VideoHeroWrapper>
  )
}

export default VideoHero