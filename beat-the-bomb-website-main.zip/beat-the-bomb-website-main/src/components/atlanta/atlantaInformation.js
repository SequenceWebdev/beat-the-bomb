//React
import React, { Component } from "react";

//Gatsby plugins
import { GatsbyImage, getImage } from "gatsby-plugin-image";
import styled from "styled-components";

import { BsFillPlayFill } from "react-icons/bs";
import poster from '../../assets/images/tiktok_poster.jpg'
import { Player, BigPlayButton } from 'video-react';

// components
import EmailListForm from "../forms/emailListForm";




const AtlantaInformationWrapper = styled.div`
  margin-top: -5rem;

  position:relative;
  z-index:5;

  .banner{
    
    & h2{
      font-family: 'Acumin-Pro-700';
      font-style: normal;
      font-weight: 700;
      text-align: center;
      letter-spacing: 0.065em;
      text-transform: uppercase;
      padding-top: 3.5rem;

      @media only screen and (max-width: 700px){
        padding: 4rem 1rem 1rem 0;
      }
    }

    @media only screen and (max-width: 900px){
      & h2{
        font-size: 40px;
        line-height: 45px;
      }
    }

    @media only screen and (max-width: 500px){
      & h2{
        padding-top: 6.5rem;
        font-size: 20px;
        line-height: 24px;
      }
    }
  }

  .banner--normal{
    @media only screen and (max-width: 500px){
        padding: 25px 1rem 15px 1rem;   
    }
  }
`

const InfoContainer = styled.div`
  max-width:1920px;
  display:flex;
  flex-direction: column;
  align-items: center;
  width:100%;
  height:100%;

  .banner_container{
    width:100%;
    aspect-ratio: calc(1440/470);
    position:relative;

    .bannerImage{
      position: absolute;
      top:0;
      left:0;
      width:100%;
      height:100%

    }
  }

  @media screen and (min-width: 1440px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }
`

const InfoContent = styled.div`
  /* background-image: linear-gradient(to bottom, rgba(0, 0, 0, 0.8), rgba(255, 255, 255, 0)),
  url(${(props)=>props.imgUrl});
  background-repeat:no-repeat; */
  /* max-height: 1500px; */
  /* height: 1500px; */
  width:100%;

  background-size: cover;

  display:flex;
  flex-direction: column;
  align-items: center;
  position:relative;

  .info_content_bg{
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:100%;
    z-index: 0;
  }

  .info_content_overlay{
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:100%;
    z-index: 1;
    background-color: rgba(0, 0, 0, 0.7);
  }



  .info__text{
    display:flex;
    justify-content: space-evenly;
    align-items: center;
    flex-direction: column;
    color:#fff;
    padding: 100px 60px 0px 60px;
    position:relative;
    z-index: 5;

    & p{
      font-family: 'Acumin-Pro';
      font-style: normal;
      font-weight: 400;
      font-size: 25px;
      line-height: 195.39%;
      text-align: center;
      letter-spacing: 0.065em;
      padding-bottom: 20px;

      @media screen and (max-width: 1250px) {
        font-size: 22px;
        padding-bottom: 15px;
      }

      @media screen and (max-width: 900px) {
        font-size: 20px;
      }
    }

    @media screen and (max-width: 1250px) {
      padding: 80px 60px 0px 60px;
    }
  }

  @media screen and (max-width: 900px) {
    max-height: none;

    .info__text{ 
      padding: 40px 24px 0px 24px;
    }

  }

`

const MediaContainer = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);  
  column-gap: 20px;
  align-items: flex-start;
  padding: 0 60px;
  width:100%;
  position:relative;
  z-index: 5;

  .info__tiktok{
    display:flex;
    align-items: center;
    flex-direction: column;
    position: relative;
    width:100%;
  }

  .tiktok__container{
    position: relative;
    max-width: 350px;
    width:100%;
    height: 100%;

  }

  /* .info__tiktok video{
    max-width: 350px;
  } */

  .overlay{
    display:flex;
    justify-content: flex-start;
    align-items: center;
    position: absolute;
    width:100%;
    height:10%;
    left:0%;
    bottom: 5%;
    z-index: 50;

    @media only screen and (max-width: 375px) {
      bottom: 7%;
    }
  }

  .overlay__play{
    color: #fff;
    font-size: 50px;

    @media only screen and (max-width: 500px) {
      font-size: 35px;
    }
  }

  .overlay p{
    font-family: 'Acumin-Pro-700';
    font-style: normal;
    font-weight: 700;
    font-size: 32px;
    line-height: 144%;
    /* or 46px */

    text-align: center;
    letter-spacing: 0.03em;
    margin:0;
    color: #FFFFFF;

    @media only screen and (max-width: 500px) {
      font-size: 18px;
    }
  }

  .tiktok__icons{
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 50px;
    padding: 20px 10px 0 10px;
  }

  .tiktok__icon{
    display:flex;
    align-items: center;
    flex-direction: column;
  }

  .tiktok__icon p {
    font-family: 'Acumin-Pro-700';
    font-style: normal;
    font-weight: 700;
    font-size: 32px;
    line-height: 144%;
    /* or 46px */

    text-align: center;
    letter-spacing: 0.03em;
    color: #fff;
  }

  .like, .replies, .comment{
    width:60px;
  }

  /*right side col */
  .info__media_rightCol{
    display:flex;
    align-items: center;
    flex-direction: column;
    row-gap:50px;
  }


  /*info rating*/
  .info__ratings{
    border: 5px solid #fff;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding-top: 2rem;
  }

  .info__ratings h3{
    font-family: "Pixel", monospace;
    font-style: normal;
    padding: 0 50px 0 50px;
    font-weight: normal;
    font-size: 60px;
    text-align: center;
    color: #fff;
  }

  .stars__container {
    display: inline-flex;
    justify-content: center;
    align-items: center;
  }

  .info__rating_icons{
    /* display: flex;
    flex-direction: column;
    align-items: center; */
    padding: 1rem;
    display:grid;
    grid-template-columns: repeat(2,1fr);
    place-items: center;

  }

  .icon_refs{
    width: 200px;
    padding: 20px;
    
  }

  .facebook{
    width:300px;
  }

  /* .info__ratings_icons_top_row{
    display:flex;
    align-items: center;
    justify-content: space-between;
  }

  .info__ratings_icons_bot_row{
    display: flex;
    align-items: center;
    justify-content: space-between;
  } */

  /* .icon {
    margin: 10px;
  } */

  .icon:hover {
    opacity: 0.7;
  }

  .info__as_seen{
    display:flex;
    align-items:center;
    flex-direction: column;
    height:100%;
    justify-content: center;
    row-gap:30px;
  }

  .info_as_seen_top{
    /* display:flex;
    align-items: center;
    justify-content: center; */
    /* max-height: 120px; */
    position: relative;
    /* left:6%; */

    display:grid;
    grid-template-columns: repeat(2,1fr);
    place-items: center;
    width:75%;
    
  }

  .info_as_seen_bot p{
    font-family: 'Acumin-Pro-700';
    font-style: normal;
    font-weight: 700;
    font-size: 48px;
    line-height: 144%;
    /* or 69px */

    text-align: center;
    letter-spacing: 0.03em;
    color: #fff;
  }

  .tiktok_icon {
    width: 80px;
  }

  .today_show_icon{
    width: 120px;
  }


  @media screen and (max-width: 1250px) {
    padding:0 10px;

    .info__ratings h3{
      font-size: 50px;
    }
    
    .info__media_rightCol{
      row-gap:25px;
    }

    .info_as_seen_bot p{
      font-size: 30px;
    }

    .icon_refs{
      width:175px;
    }

    .facebook{
      width:250px;
    }
    
    /* .tiktok_icon {
      width: 90px;
    } */

    /* .today_show_icon{
      width: 130px;
    } */

  }
  

  @media screen and (max-width: 900px) {
    display: flex;
    flex-direction: column;
    column-gap:0;
    align-items: center;
    padding: 0 20px;

    .info__as_seen{
      row-gap:15px;
    }

    .info_as_seen_top{
      /* left:4%; */
      width:100%;
    }

    /* .tiktok_icon {
      width: 80px;
    } */

    /* .today_show_icon{
      width: 125px;
    } */
    
    /* .info__tiktok video{
      max-width: 425px;
      width: 100%;
    } */

    .info__tiktok{
      flex-direction: row;
      justify-content: center;
    }

    .tiktok__icons{
      display: flex;
      flex-direction: column;
      align-items: center;
      
      grid-gap: 0;
      padding: 20px 10px 0 10px;
    }

    .tiktok__icon p {
      font-size: 16px;
    }

    .like,
    .replies,
    .comment {
      width: 30px;
    }

    .info__media_rightCol{
      margin-top: 1.5rem;
    }

    .info__ratings h3{
      font-family: 'Pixel';
      font-style: normal;
      font-weight: 400;
      font-size: 32px;
      line-height: 38px;
      text-align: center;
    }

    .info_as_seen_bot p{
      font-size:22px;
    }
  }

  @media only screen and (max-width: 500px){
    .info_as_seen_top{
      width:75%;
    }

    .info__rating_icons{
      width:100%;
      
    }

    /* .info__ratings{
      width:100%;
    } */

    .icon_refs{
      width:100px;
      padding:5px;
    }

    .facebook{
      width:150px;
    }

    .tiktok_icon {
      width: 65px;
    }

    .today_show_icon{
      width: 80px;
    }

  }


`

const EmailForm = styled.div`
  width: 100%;
  background-color: white;
  height:124px;
  /* padding: 2rem; */

  display:flex;
  justify-content: space-around;
  align-items: center;

  & p{
    font-family: 'Acumin-Pro-700';
    font-style: normal;
    font-weight: 700;
    font-size: 22px;
    line-height: 119%;
    /* or 26px */

    text-align: center;
    letter-spacing: 0.03em;
    text-transform: uppercase;

    width:40%;
    /* height: 78px; */
    @media only screen and (max-width: 900px){
      width:100%;
      font-size: 18px;
      line-height: 132.5%;
    }
  }

  & button{
    background-color: var(--neon-pink);
    font-family: 'Acumin-Pro-700';
    font-style: normal;
    font-weight: 700;
    font-size: 18px;
    line-height: 22px;
    text-align: center;
    color: #000;
    text-transform: uppercase;
    width: 35%;
    height: 51px;
    max-width: none;  
  }

  & input{
    width: 65%;
    height: 51px;
    max-width: none;    
  }

  & input::placeholder{
    color: #C4C4C4;
    font-family: 'Acumin-Pro';
    font-style: normal;
    font-weight: 400;
    font-size: 20px;
    line-height: 119%;
    /* or 24px */

    letter-spacing: 0.03em;
    text-transform: uppercase;
  }

  & form{
    @media only screen and (max-width: 900px){
      width:100%;
    }
  }

  @media only screen and (max-width: 1250px){
    height: auto;
    padding: 1rem;
  }

  @media only screen and (max-width: 900px){
    flex-direction: column;
    row-gap: 20px;
    width:100%;
  }

`


class AtlantaInformation extends Component {

  render() {
    const headerTitle = this.props.info[0].headerTitle
    const bodyTexts = this.props.info[0].bodyTexts
    const assets = this.props.info[0].assets
    const otherTexts = this.props.info[0].otherTexts
    const pn = this.props.pathname
    
  return (
    <AtlantaInformationWrapper>
      <div className="banner banner--no-transition banner--normal banner--no-margin banner--no-transform banner--blue">
         <h2 data-aos="fade-left" data-aos-once="true" style={{ textTransform: "uppercase" }}>
           {headerTitle}
         </h2>
       </div>
      <InfoContainer>
        
        <div className="banner_container">
          <GatsbyImage alt="atlanta info section banner image" className="bannerImage" image={getImage(assets[1].gatsbyImageData)} />
        </div>
        <InfoContent>
          <GatsbyImage alt="info content bg image" className="info_content_bg" image={getImage(assets[0].gatsbyImageData)}/>
          <div className="info_content_overlay"></div>
          <div className="info__text">
            {bodyTexts.map((text, index) => {
              return(
                <p key={index}>{text.text}</p>
              );
            })}
          </div>
          <MediaContainer>
            <div className="info__tiktok">

              <div className="tiktok__container">
                <Player autoPlay muted src={assets[10].url} poster={poster} preload="auto">
                  <BigPlayButton position="center" />
                </Player>
                <div className="overlay">
                  <BsFillPlayFill className="overlay__play"/>
                  <p>{otherTexts[0].text}</p>
                </div>
              </div> 


              <div className="tiktok__icons">
                <div className="tiktok__icon">
                  <GatsbyImage alt={assets[8].title} className="like" image={getImage(assets[8].gatsbyImageData)} />
                  <p>{otherTexts[1].text}</p>
                </div>
                <div className="tiktok__icon">
                  <GatsbyImage alt={assets[7].title} className="comment" image={getImage(assets[7].gatsbyImageData)} />
                  <p>{otherTexts[2].text}</p>
                </div>
                <div className="tiktok__icon">
                  <GatsbyImage alt={assets[6].title} className="replies" image={getImage(assets[6].gatsbyImageData)} />
                  <p>{otherTexts[3].text}</p>
                </div>
              </div>
            </div>
            <div className="info__media_rightCol">
              <div className="info__ratings">
                <h3>{otherTexts[4].text}</h3>
                <div className="stars__container">
                  <GatsbyImage alt={assets[9].title} image={getImage(assets[9].gatsbyImageData)}></GatsbyImage>
                  <GatsbyImage alt={assets[9].title} image={getImage(assets[9].gatsbyImageData)}></GatsbyImage>
                  <GatsbyImage alt={assets[9].title} image={getImage(assets[9].gatsbyImageData)}></GatsbyImage>
                  <GatsbyImage alt={assets[9].title} image={getImage(assets[9].gatsbyImageData)}></GatsbyImage>
                  <GatsbyImage alt={assets[9].title} image={getImage(assets[9].gatsbyImageData)}></GatsbyImage>
                </div>
                <h3>{otherTexts[5].text}</h3>
                <div className="info__rating_icons">
                  {/* <div className="info__ratings_icons_top_row"> */}
                    <a className="icon_refs" href="https://www.tripadvisor.com/Attraction_Review-g60827-d13168226-Reviews-Beat_The_Bomb-Brooklyn_New_York.html">
                      <GatsbyImage alt={assets[4].title} className="icon" image={getImage(assets[4].gatsbyImageData)}/>
                    </a>
                    <a className="icon_refs facebook" href="https://www.facebook.com/BeatTheBomb/">
                      <GatsbyImage alt={assets[3].title} className="icon" image={getImage(assets[3].gatsbyImageData)}/>
                    </a>
                  {/* </div> */}
                  {/* <div className="info__ratings_icons_bot_row"> */}
                    <a className="icon_refs" href="https://www.google.com/search?sxsrf=ALeKk03xQfAWDqkmxnBHNhqoPwRxx_daCA%3A1612536743352&ei=p1sdYIj7FKzm5NoPlqe3wA8&q=google+review+beat+the+bomb&oq=google+review+beat+the+bomb&gs_lcp=CgZwc3ktYWIQAzIGCAAQFhAeOgcIABBHELADOgQIIxAnOgIIADoICC4QxwEQrwE6BQgAEIYDOgcIABAUEIcCOgUIABCRAjoICAAQsQMQgwE6BAgAEA06CgguEMcBEK8BEA06BggAEA0QHjoICAAQCBANEB46CAghEBYQHRAeULeYBFjJtQRg0bYEaAFwAngAgAGSAYgBtw2SAQQxMS42mAEAoAEBqgEHZ3dzLXdpesgBCMABAQ&sclient=psy-ab&ved=0ahUKEwjI6pi-_9LuAhUsM1kFHZbTDfgQ4dUDCA0&uact=5#lrd=0x89c25a3326bc0279:0xb5b5b137d131ee1d,1,,,">
                      <GatsbyImage alt={assets[5].title} className="icon" image={getImage(assets[5].gatsbyImageData)}/>
                    </a>
                    <a className="icon_refs" href="https://www.yelp.com/biz/beat-the-bomb-brooklyn">
                      <GatsbyImage alt={assets[2].title} className="icon" image={getImage(assets[2].gatsbyImageData)} />
                    </a>
                  {/* </div> */}
                </div>
              </div>
              <div className="info__as_seen">
                <div className="info_as_seen_top">
                  {/* <FaTiktok className="fa_tiktok_icon"/> */}
                  <GatsbyImage alt={assets[12].title} className="tiktok_icon" image={getImage(assets[13].gatsbyImageData)} />
                  
                  {/* <img alt={assets[11].title} className="today_show_icon" src={assets[11].url} /> */}
                  <GatsbyImage alt={assets[11].title} className="today_show_icon" image={getImage(assets[11].gatsbyImageData)} />
                </div>
                <div className="info_as_seen_bot">
                  <p>{otherTexts[6].text}</p>
                </div>
              </div>
            </div>
          </MediaContainer>
        </InfoContent>
        
        <EmailForm>
          <GatsbyImage alt={assets[12].title} image={getImage(assets[12].gatsbyImageData)} />
          <p>{otherTexts[7].text}</p>
          <EmailListForm pathname={pn}/>
        </EmailForm>
      </InfoContainer>
    </AtlantaInformationWrapper>
  );
  }
};

export default AtlantaInformation;
