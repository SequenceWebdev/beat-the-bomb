import React from "react";
import EmailListForm from "../forms/emailListForm";

import styled from "styled-components";


const AtlantaHeroWrapper = styled.div`
  margin-bottom: 5rem;
  position:relative;
  z-index:15;
`

const AtlantaHeroInnerWrapper = styled.div`
  max-width: 1920px;
  background-image: url(${(props)=>props.imgUrl});
  background-size: cover;
  background-repeat: no-repeat;
  max-height: 900px;
  height: 900px;
  position:relative;
  
  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }
  @media screen and (max-width: 1024px) {
    background-position: bottom;
  }
  @media screen and (max-width: 500px) {
    height: 600px;
  }  
`

const HeroText = styled.div`
  display:flex;
  align-items: flex-start;
  flex-direction: column;
  color: #fff;
  z-index:5;
  width:62.5%;
  position: absolute;
  top:10%;
  left:5%;
  
  & h1{
    font-family: 'Acumin Pro';
    font-style: normal;
    font-weight: 700;
    font-size: 115px;
    line-height: 118px;
    letter-spacing: 0.065em;
    text-transform: uppercase;
    margin-bottom: 2rem;

    @media only screen and (max-width: 1440px){
      font-size: 105px;
      line-height: 107px;
    }

    @media only screen and (max-width: 1250px){
      font-size: 88px;
      line-height: 90px;
    }
    @media only screen and (max-width: 768px){
      font-size: 70px;
      line-height: 72px;
    }
    @media only screen and (max-width: 500px){
      font-size: 40px;
      line-height: 46px;
    }
  }
  & p{
    width: 75%;
    font-family: 'Acumin-Pro-700';
    font-style: normal;
    font-weight: 700;
    font-size: 64px;
    line-height: 76px;
    letter-spacing: 0.03em;
    @media only screen and (max-width: 1250px){
      font-size: 55px;
    }
    @media only screen and (max-width: 768px){
      font-size: 40px;
      line-height: 45px;
    }
    @media only screen and (max-width: 500px){
      font-size: 28px;
      line-height: 33px;
    }
  }
  @media only screen and (max-width: 1250px){
    width:75%;
  }
  @media only screen and (max-width: 1024px){
    width:90%;
  }
  @media only screen and (max-width: 768px){
    top:40%;
    transform: translateY(-50%);
  }
`

const EmailForm = styled.div`
  width: 70%;
  background-color: white;
  z-index: 11;
  position: absolute;
  left:0;
  bottom:0;
  transform: translateY(30%);
  height:124px;
  padding: 2rem 2rem 1rem 2rem;
  display:flex;
  justify-content: space-around;
  align-items: center;
  & p{
    font-family: 'Acumin-Pro-700';
    font-style: normal;
    font-weight: 700;
    font-size: 22px;
    line-height: 119%;
    /* or 26px */
    text-align: center;
    letter-spacing: 0.03em;
    text-transform: uppercase;
    width:40%;
    /* height: 78px; */
    @media only screen and (max-width: 1024px){
      width:100%;
    }
    @media only screen and (max-width: 500px){
      font-size:18px;
      line-height: 132.5%;
    }
  }
  & button{
    background-color: var(--neon-green);
    font-family: 'Acumin-Pro-700';
    font-style: normal;
    font-weight: 700;
    font-size: 18px;
    line-height: 22px;
    text-align: center;
    color: #000;
    text-transform: uppercase;
    width: 35%;
    height: 51px;
    max-width: none;  
  }
  & input{
    width: 65%;
    height: 51px;
    max-width: none;    
  }
  & input::placeholder{
    color: #C4C4C4;
    font-family: 'Acumin-Pro';
    font-style: normal;
    font-weight: 400;
    font-size: 20px;
    line-height: 119%;
    /* or 24px */
    letter-spacing: 0.03em;
    text-transform: uppercase;
  }
  & form{
    @media only screen and (max-width: 768px){
      width:100%;
    }
  }
  @media only screen and (max-width: 1250px){
    height: auto;
  }
  @media only screen and (max-width: 1024px){
    flex-direction: column;
  }
  @media only screen and (max-width: 768px){
    width:100%;
  }
  @media only screen and (max-width: 500px){
    transform: translateY(50%);
  }
`

const AtlantaHero = ({ hero, pathname }) => {
  const { headerTitle, bodyTexts, assets } = hero[0];
  return (
    <AtlantaHeroWrapper>
      <AtlantaHeroInnerWrapper imgUrl={assets[0].gatsbyImageData.images.fallback.src}>
        <HeroText>
          <h1>{headerTitle}</h1>
          <p>{bodyTexts[0].text}</p>
        </HeroText>
        <EmailForm>
          <p>{bodyTexts[1].text}</p>
          <EmailListForm pathname={pathname}/>
        </EmailForm>
      </AtlantaHeroInnerWrapper>
    </AtlantaHeroWrapper>

  );
};

export default AtlantaHero;