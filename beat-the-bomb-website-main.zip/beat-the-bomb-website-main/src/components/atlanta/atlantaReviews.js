//React
import React from "react";
import styled from "styled-components";
import StarContainer from "../starContainer";

import { FcGoogle } from "react-icons/fc";
import { FaTripadvisor } from "react-icons/fa";
import { GatsbyImage, getImage } from "gatsby-plugin-image";


const AtlantaReviewsWrapper = styled.div`
  margin-top: -2rem;
  margin-bottom: 5rem;

  .banner {

    & h2{
      font-family: 'Acumin-Pro-700';
      font-style: normal;
      font-weight: 700;
      text-align: center;
      letter-spacing: 0.065em;
      text-transform: uppercase;

      @media only screen and (max-width: 900px){
        font-size: 40px;
        line-height: 45px;
      }

      @media only screen and (max-width: 700px){
        padding: 1rem 0;
      }

      @media only screen and (max-width:500px){
        font-size: 20px;
        line-height: 24px;
      }
    }

    @media only screen and (max-width: 900px){
      margin-top:2rem;
    }
  }
`
const AtlantaReviewInnerWrapper = styled.div`
  max-width:1920px;

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }
`

const ReviewContent = styled.div`

  text-align: center;
  margin-top:-2rem;
  padding-bottom: 5rem;

  position:relative;

  .test_bg{
    position:absolute;
    z-index:0;
    width:100%;
    height:100%;
    top:0;
    left:0;
  }

  .review_bg_overlay{
    position:absolute;
    z-index:1;
    width:100%;
    height:100%;
    top:0;
    left:0;
    background-color: rgba(0, 0, 0, 0.6);
  }

  h3{
    margin-top: 5rem;
    font-family: 'Acumin-Pro-700';
    font-style: normal;
    font-weight: 700;
    font-size: 32px;
    line-height: 119%;
    padding: 0 20px;
    /* or 38px */

    text-align: center;
    letter-spacing: 0.03em;

    color: #FFFFFF;
    z-index: 5;
    position:relative;
  }

  .review__reviews{
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 40px;
    padding: 0 20px;
    padding-bottom: 2rem;
    z-index: 5;
    position:relative;
  }

  .testimonial__border{
    border: 2px solid var(--neon-pink);
    padding: 10px;
  }

  .testimonial{
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    justify-content: space-evenly;
    background-color: #ffffff;
    padding: 20px;
  }

  .testimonial p{
    font-family: 'Acumin-Pro';
    font-size: 20px;
    /* line-height: 30px; */
    color: #000000;
    text-align: center;
    
  }

  .stars__container{
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .testimonial__logo{
    font-size: 36px;
  }

  @media screen and (max-width: 1024px) {
    .testimonial p{
      font-size: 15px;
    }

    .testimonial__logo {
      font-size: 25px;
    }

    .star{
      width:20px;
    }

    & h3{
      font-size: 25px;
    }
  }

  @media screen and (max-width: 768px) {
    .review__reviews {
      display:flex;
      flex-direction: column;
      padding: 0 30px;
    }
  }

  @media screen and (max-width: 500px) {
 
    background-size: cover;

    & h3 {
      font-family: 'Acumin-Pro-700';
      font-style: normal;
      font-weight: 700;
      font-size: 23px;
      line-height: 28px;
      text-align: center;
      letter-spacing: 0.065em;
      text-transform: uppercase;
    }

    .testimonial__border {
      border: none;
    }

    .testimonial p{
      font-family: 'Acumin-Pro';
      font-style: normal;
      font-weight: 400;
      font-size: 18px;
      line-height: 30px;
      /* or 167% */
    
      text-align: center;
    }

  }

  @media screen and (max-width: 320px) {
    .star {
      width: 16px;
    }

  }


`




const AtlantaReviews = ({ reviewData }) => {
  const { headerTitle, reviews, bodyTexts, assets } = reviewData[0];
  return (
    <AtlantaReviewsWrapper>
      <div className="banner banner--no-transition banner--normal banner--no-transform banner--pink banner--custom">
        <h2 data-aos="fade-right" data-aos-once="true" style={{ color: "white", textTransform: "uppercase" }}>
          {headerTitle}
        </h2>
      </div>
      <AtlantaReviewInnerWrapper>
        <ReviewContent imgUrl={assets[0].url}>
          <GatsbyImage alt="review bg" className="test_bg" image={getImage(assets[0].gatsbyImageData)}/>
          <div className="review_bg_overlay"></div>
          <br></br>
          <h3>{bodyTexts[0].text}</h3>
          <br></br>
          <div className="review__reviews">
            {reviews.map((testimonial, index) => {
              
              const review_name = testimonial.review[0].text;
              const review_text = testimonial.review[1].text;
              const review_logo = testimonial.review[2].text;
              return(
                <div className="testimonial__border" key={index}>
                  <div className="testimonial">
                    <StarContainer star={assets[1].gatsbyImageData} />
                    <br></br>
                    <p>{review_text}</p>
                    <p>{review_name}</p>
                    { review_logo === "Google" ? <FcGoogle className="testimonial__logo"/> : <FaTripadvisor className="testimonial__logo" />}
                  </div>
                </div>
                
              );
            })}
          </div>
        </ReviewContent>
      </AtlantaReviewInnerWrapper>
    </AtlantaReviewsWrapper>
  );
};

export default AtlantaReviews;
