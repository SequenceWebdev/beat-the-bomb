// React
import React from "react";
// Styles
import * as styles from "../styles/footer.module.css";
import { FaInstagram, FaTiktok } from "react-icons/fa";

function AtlantaFooter() {
  return (
    <div className={styles.atlantafooter}>
      <div className={styles.atlantafooter__row1}>
        <h2 data-aos="fade-in" data-aos-once="true">Follow us on social media</h2>
        <p data-aos="fade-in" data-aos-once="true">@beatthebomb</p>
      </div>
      <div className={styles.atlantafooter__row2}>
        <div data-aos="fade-right" data-aos-once="true" className={styles.atlanta__socialContainer}>
          <div className={styles.atlanta__social}>
            <FaInstagram className={styles.atlanta__socialIcon}/>
          </div>
          <a className="button button--green button--text-black" style={{padding:"7px 50px"}} href="https://www.instagram.com/beatthebomb/"><em>Follow</em></a>
        </div>
        <div data-aos="fade-left" data-aos-once="true" className={styles.atlanta__socialContainer}>
          <div className={styles.atlanta__social}>
            <FaTiktok className={styles.atlanta__socialIcon}/>
          </div>
          <a className="button button--green button--text-black" style={{padding:"7px 50px"}} href="https://www.tiktok.com/@beatthebomb"><em>Follow</em></a>
        </div>
      </div>
    </div>
  );
}

export default AtlantaFooter;
