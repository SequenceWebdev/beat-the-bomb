//React
import React from "react";
import styled from "styled-components";

const AtlantaHiringWrapper = styled.div`
  margin-bottom: 5rem;

`

const AtlantaHiringInnerWrapper = styled.div`
  max-width: 1920px;
  padding: 0 60px;
  font-family: 'Acumin-Pro-700';
  font-style: normal;
  font-weight: 700;
  text-align: center;
  letter-spacing: 0.03em;
  text-transform: uppercase;

  .bookButton{
    padding:20px 30px 11px 30px;
    font-style: italic;
  }

  & h2{
    font-size: 96px;
    color: #fff;
    margin-bottom: 0;
  }

  & p {
    font-size: 52px;
    color: #fff;
    margin-top: 0;
  }

  & a {
    font-size: 36px;
    color: #000000;
  }

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }

  @media screen and (max-width: 768px) {
    padding: 0 30px;

    & h2 {
      font-size: 70px;
    }
    
    & p {
      font-size: 30px;
    }

    & a {
      font-size: 25px
    }
  }

  @media screen and (max-width: 500px) {
    & h2 {
      font-size: 40px;
    }

    & p {
      font-size: 19px;
    }

    & a {
      font-size: 18px
    }
  }

`

const AtlantaHiring = ({ hiring }) => {
  const { bodyTexts, otherTexts } = hiring[0]
  return (
    <AtlantaHiringWrapper>
      <AtlantaHiringInnerWrapper>
        <h2>{bodyTexts[0].text}</h2>
        <p>{bodyTexts[1].text}</p>
        <a data-aos="fade-in" data-aos-once="true" className="button button--green button--text-black bookButton" href={otherTexts[0].text}>{otherTexts[1].text}</a>
      </AtlantaHiringInnerWrapper>
    </AtlantaHiringWrapper>
  );
};

export default AtlantaHiring;