// Core
import React from "react";
// Third Party Components
import { useForm, ValidationError } from "@formspree/react";

import * as styles from "../styles/salesForm.module.css";

function SalesForm() {
  const [state, handleSubmit] = useForm("xdoywlkz");
  if (state.succeeded) {
    return <p>Thanks for joining!</p>;
  }

  return (
    <div className={styles.sales_form_wrapper} id="sales_form">
      
      <form  onSubmit={handleSubmit}>
        <p>Email</p>
        <input
          id="email"
          name="email" 
          placeholder="example@email.com"
          type="email"
        />
        <ValidationError 
          errors={state.errors} 
          field="email"
          prefix="Email"
        />
        <p>Request</p>
        <textarea
          id="message"
          name="message"
          rows="10"
          placeholder="Your message here..."
        />
        <ValidationError 
          errors={state.errors} 
          field="message"
          prefix="Message"
        />
        <button className="button button--pixel button--pink button--contact" disabled={state.submitting} type="submit">
          Submit
        </button>
      </form>
    </div>
  );
}

export default SalesForm;
