/* eslint-disable */
import React, { Component } from "react";
import { subscribe } from "klaviyo-subscribe";

import * as styles from "../styles/emailListForm.module.css";
import * as mailStyles from "../styles/mailingList.module.css";

class EmailListForm extends Component {
	constructor(props) {
		super(props);
		const curr_path = (props.pathname==="/atlanta")?"WtytM6":"YmSAXL";
		this.state = {
			email: "",
			status: "",
			LIST_ID:curr_path,
		};
		this.handleChange = this.handleChange.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);
		this.validateEmail = this.validateEmail.bind(this);
	}

	handleSubmit(evt) {
		evt.preventDefault();
		// const LIST_ID ="WtytM6";

		if (!this.validateEmail(this.state.email)) {
			this.setState({
				...this.state,
				message: "Invalid email",
				status: "error"
			});
		} else {
			this.setState({
				...this.state,
				message: "Sending...",
				status: "sending"
			});

			subscribe(this.state.LIST_ID, this.state.email, {})
				.then(response => {
					this.setState({
						email: "",
						message: "Subscribed! Check your email to confirm",
						status: "success"
					});
				}).catch(error => {
					this.setState({
						...this.state,
						message: error,
						status: "error"
					});
				});
		}

		setTimeout(() => {
			this.setState({
				...this.state,
				message: "",
				status: ""
			});
		}, 2000);
	}

	validateEmail(email) {
		const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		return re.test(String(email).toLowerCase());
	}

	handleChange(event) {
		this.setState({
			email: event.target.value,
		});
	}

	render() {
		const dictionary = {
			sending: "blue",
			error: "red",
			success: "green"
		};
		return (
			<form className={styles.form} onSubmit={this.handleSubmit}>
				<input
					className={styles.textInput}
					onChange={this.handleChange}
					type="text"
					value={this.state.email}
					placeholder="EMAIL"
				/>
				<button className={styles.submitButton} type="submit">Sign Up</button>
				{this.state.message && <div className={mailStyles.statusMessagesWrap} >
					<p className={mailStyles.statusMessage} style={{ color: dictionary[this.state.status] }}>{this.state.message}</p>
				</div>}
			</form>
		);
	}
}

export default EmailListForm;