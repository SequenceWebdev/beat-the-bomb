import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from 'styled-components'
import { documentToReactComponents } from '@contentful/rich-text-react-renderer'
import Button from '../button'

// Images
import pink_splat from '../../../assets/images/flair/pink-paint-splat.png';

const HeroImageWrapper = styled.div`
  width: 100%;
  max-width: 1920px;
  margin-left: auto;
  margin-right: auto;
  margin-top: 3rem;
  padding-left: 128px;
  padding-right: 128px;

  @media only screen and (max-width: 900px){
    padding-left: 48px;
    padding-right: 48px;
  }

  @media only screen and (max-width: 500px){
    padding-left: 10px;
    padding-right: 10px;
  }

  .content {
    /* display: flex;
    flex-direction: row;
    align-items: stretch;
    justify-content: space-between; */
    display: grid;
    grid-template-columns: 50% 50%;
    justify-content: space-between;
    column-gap: 5rem;

    @media only screen and (max-width: 1440px){
      column-gap: 3rem;
    }

    @media only screen and (max-width: 1024px){
      grid-template-columns: 1fr;
    }

    
  }

  .content-left-col {
    width: 100%;
    position: relative;

    .header-text {
      text-align: left;
      font-family: "Acumin Pro";
      font-weight: 900;
      font-style: italic;
      font-size: 80px;
      line-height: 112%;
      letter-spacing: 0px;
      color: #FFFFFF;
      text-transform: uppercase;
      opacity: 1;
      position: relative;
      z-index: 3;

      @media only screen and (max-width: 1600px){
        font-size: 60px;
      }

      @media only screen and (max-width: 1440px){
        font-size: 48px;
      }

      @media only screen and (max-width: 1024px){
        font-size: 43px;
        text-align: center;
      }
    }

    .header-text--non-event-page {
      text-align: left;
      font-family: "Acumin Pro";
      font-weight: 900;
      font-style: italic;
      font-size: 80px;
      line-height: 112%;
      letter-spacing: 0px;
      color: #FFFFFF;
      text-transform: uppercase;
      opacity: 1;
      position: relative;
      z-index: 3;

      @media only screen and (max-width: 1600px){
        font-size: 60px;
      }

      @media only screen and (max-width: 1440px){
        font-size: 48px;
      }

      @media only screen and (max-width: 1024px){
        display: none;
      }
    }

    .subheader-text {
      text-align: left;
      font-family: "Acumin Pro";
      font-weight: 300;
      font-size: 33px;
      line-height: 133%;
      letter-spacing: 0px;
      color: #FFFFFF;
      opacity: 1;
      position: relative;
      margin-bottom: 2rem;
      z-index: 3;

      @media only screen and (max-width: 1600px){
        font-size: 24px;
      }
      
      @media only screen and (max-width: 1440px){
        font-size: 20px;
      }

      @media only screen and (max-width: 1024px){
        font-size: 18px;
        text-align: center;
      }

      @media only screen and (max-width: 900px){
        font-size: 16px;
      }

      @media only screen and (max-width: 480px){
        font-size: 15px;
        line-height: 18px;
      }
    }

    .flair {
      * {
        position: absolute;
        z-index: 2;
      }
    }

    .pink-splat {
      top: -40%;
      left: 199px;
      width: 715px;

      @media only screen and (max-width: 1600px){
        top: -50%;
        left: 100px;
        width: 665px;
      }

      @media only screen and (max-width: 1440px){
        top: -60%;
        left: 60px;
        
      }

      @media only screen and (max-width: 1100px){
        left: 0px;
      }

      @media only screen and (max-width: 1024px){
        top: -300px;
        left: 180px;
      }

      @media only screen and (max-width: 480px){
        left: 0;
      }
    }
  }

  .content-right-col {
    width: 100%;
  }

  .video {
    width: 100%;
    height: auto;

    @media only screen and (max-width: 1024px){
      height: auto;
    }
  }

  .button-wrapper {
    position: relative;
    z-index: 3;

    display: grid;
    grid-template-columns: 50% 50%;

    & > div {
      margin-top: 0;
      justify-content: flex-start;

      @media only screen and (max-width: 1024px){
        justify-content: center;
      }
    }

    & > div > div,a {
      /* text-align: left; */
      font-family: "Pixel";
      text-transform: uppercase;
      font-size: 28px;
      letter-spacing: 0px;
      color: #00FF7B;
      opacity: 1;
      width: 100%;

      @media only screen and (max-width: 1600px){
        font-size: 18px;
      }

      @media only screen and (max-width: 1440px){
        font-size: 16px;
      }

      @media only screen and (max-width: 1024px){
        width: auto;
      }

      @media only screen and (max-width: 480px){
        font-size: 15px;
      }
    }

    & > div > div,a > span {
      padding: 15px 27px 12px 27px;

      @media only screen and (max-width: 480px){
        font-size: 15px;
      }
    }

    @media only screen and (max-width: 1024px){
      display: none;
    }
  }

  .button-wrapper--mobile {
    position: relative;
    z-index: 3;
    margin-bottom: 2rem;
    display: grid;
    grid-template-columns: 50% 50%;

    & > div {
      margin-top: 0;
      justify-content: flex-start;

      @media only screen and (max-width: 1024px){
        justify-content: center;
      }
    }

    & > div > div,a {
      /* text-align: left; */
      font-family: "Pixel";
      text-transform: uppercase;
      font-size: 28px;
      letter-spacing: 0px;
      color: #00FF7B;
      opacity: 1;
      width: 100%;

      @media only screen and (max-width: 1600px){
        font-size: 18px;
      }

      @media only screen and (max-width: 1440px){
        font-size: 16px;
      }

      @media only screen and (max-width: 1024px){
        width: auto;
      }

      @media only screen and (max-width: 480px){
        font-size: 15px;
      }
    }

    & > div > div,a > span {
      padding: 15px 27px 12px 27px;

      @media only screen and (max-width: 480px){
        font-size: 15px;
      }
    }

    @media only screen and (min-width: 1025px){
      display: none;
    }

    @media only screen and (max-width: 1024px){
      grid-template-columns: 1fr;
    }
  }


  .assets-container {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr 1fr;
    place-content: center;
    column-gap: 32px;
    position: relative;
    z-index: 3;
    margin-top: 2rem;

    @media only screen and (max-width: 1250px){
      column-gap: 16px;
    }

    /* @media only screen and (max-width: 1100px){
      grid-template-columns: repeat(2, 50%);
    } */

    @media only screen and (max-width: 1024px){
      grid-template-columns: 1fr 1fr 1fr 1fr;
    }

    @media only screen and (max-width: 500px){
      column-gap: 8px;
    }

    @media only screen and (max-width: 375px){
      grid-template-columns: 1fr 1fr;
    }
  }

  .asset-container {
    display: flex;
    flex-direction: column;
    justify-content: stretch;
    align-items: center;
  }

  .asset-image-container {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 16px;

    img {
      height: 75px;

      @media only screen and (max-width: 1440px){
        height: 55px;
      }

      @media only screen and (max-width: 1024px){
        height: 45px;
      }

      @media only screen and (max-width: 500px){
        height: 43px;
      }
    }
  }

  .asset-text-container p{
    flex-grow: 1;
    text-align: center;
    font-family: "Acumin Pro";
    font-size: 18px;
    letter-spacing: 0px;
    color: #FFFFFF;
    opacity: 1;

    @media only screen and (max-width: 1440px){
      font-size: 15px;
      line-height: 18px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 12px;
    }
  }
`

const EventsHero = (pageContext) => {
  const {
    header,
    subheader,
    buttons,
    video,
    placeholderImg,
    assets,
  } = pageContext.data;

  return (
    <HeroImageWrapper>
      <div className="content">
        <div className="content-left-col">
          <div className="flair">
            <img
              alt="pink paint splat"
              className="pink-splat"
              src={pink_splat}
            />
          </div>
          {pageContext.path.includes('/events') && 
          <h1 className='header-text'>{header}</h1>}
          {!pageContext.path.includes('/events') && 
          <h1 className='header-text--non-event-page'>{header}</h1>}
          <p className='subheader-text'>{subheader.subheader}</p>
          {buttons.map((button, index) => {
            return (
              <div className="button-wrapper">
                <Button
                  data={{ button }}
                  glow={{
                    "Black":"#000000",
                    "Blue": "var(--neon-blue)",
                    "Pink": "var(--neon-pink)",
                    "Yellow": "var(--neon-yellow)",
                    "Green": "var(--neon-green)",
                    "White": "#FFFFFF",
                  }[button.textColor]}
                  index={index}
                  withFlair={true}
                />
              </div>
            )
          })}
          <div className="assets-container">
            {assets.map((asset, index) =>{
              return (
              <div className="asset-container">
                <div className="asset-image-container">
                  <img alt={`asset-${index}`} src={asset.image.url}/>
                </div>
                  {JSON.parse(asset.richText.raw).content.map((json_text_section, index) => {
                  return (
                    <div className="asset-text-container" key={index}>
                      {documentToReactComponents(json_text_section)}
                    </div>
                  );
                })}
              </div>
              )
            })}
          </div>
          {buttons.map((button, index) => {
            return (
              <div className="button-wrapper--mobile">
                <Button
                  data={{ button }}
                  glow={{
                    "Black":"#000000",
                    "Blue": "var(--neon-blue)",
                    "Pink": "var(--neon-pink)",
                    "Yellow": "var(--neon-yellow)",
                    "Green": "var(--neon-green)",
                    "White": "#FFFFFF",
                  }[button.textColor]}
                  index={index}
                  withFlair={true}
                />
              </div>
            )
          })}
        </div>
        <div className="content-right-col">
          <video
              autoPlay
              className="video"
              playsInline
              loop
              muted
              src={video.url}
              poster={placeholderImg.url}
            />
        </div>
      </div>
    </HeroImageWrapper>
  )
}

export default EventsHero
