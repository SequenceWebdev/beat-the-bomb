import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React, {useEffect, useState} from 'react'
import styled from 'styled-components'
import { documentToReactComponents } from '@contentful/rich-text-react-renderer'
import Button from '../button'
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
// Images
import bombie from '../../../assets/images/flair/bombie-white.png';
import little_guy from '../../../assets/images/flair/little-guy.png';
import square from '../../../assets/images/flair/square.png';

const HeroImageWrapper = styled.div`
  width: 100%;
  .hero_container{
    margin-bottom: -10rem;
    margin-top: -2rem;
    /* padding: 4rem 128px 12rem 128px; */
    position: relative;

    @media (max-width: 900px) {
      padding: 0 0 12rem 0 !important;
    }
  }


  .background-image {
    bottom: 0;
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    z-index: 0;

    &::after {
      background: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 1));
      bottom: 0;
      content: "";
      display: block;
      height: 150px;
      left: 0;
      position: absolute;
      right: 0;
    }
  }

  .content {
    aspect-ratio: 1.77777777777778;
    display: flex;
    flex-direction: column;
    justify-content: center;
    margin: 0 auto;
    max-width: 1920px;
    padding: 0 128px;
    position: relative;
    text-align: center;
    z-index: 2;

    @media (max-width: 900px) {
      aspect-ratio: auto;
      padding: 10rem 0;
    }

    /* @media only screen and (max-width: 500px){
      padding: ${({path}) => path.includes('menu') ? '5rem 0 10rem 0': '10rem 0'};
    } */

    .text {
      color: white;
      font-family: "Acumin Pro";
      font-size: clamp(20px, 5vw, 80px);
      font-style: normal;
      font-weight: 700;
      letter-spacing: -1.5px;
      line-height: 125%;
      margin: 0 auto;
      max-width: 20ch;
      text-transform: uppercase;

      @media (max-width: 900px) {
        font-size: clamp(20px, 8vw, 80px);
      }
    }

    .buttons {
      display: flex;
      margin-top: 4rem;
      padding: 0 10px;

      @media (max-width: 900px) {
        flex-direction: column;
        margin: 0 auto;
        max-width: 300px;
        width: 100%;
      }

      .button-wrapper {
        padding: 5px 10px;
        position: relative;
        width: 100%;
        z-index: 3;
      }

      .button-wrapper > * {
        margin-top: 0;
      }

      .button-wrapper > * > a {
        width: 100%;
      }

      .button-wrapper > * > div {
        width: 100%;
      }

      &--1 {
        .button-wrapper > * > a {
          max-width: 400px;
        }

        .button-wrapper > * > div {
          max-width: 400px;
        }
      }
    }

    .mobile-media {
      display: block;
      width: 100%;
      margin-bottom: -10rem;
      margin-top:-8.5rem;

      video {
        width: 100%;
        height: 100%;
      }

      @media only screen and (min-width: 769px){
        display: none;
      }
    }

    .media {
      height: 0;
      overflow: hidden;
      padding-top: 56.25%;
      position: absolute;
      left: 0;
      right: 0;
      top: 0;
      width: 100%;
      z-index: 0;

      @media (max-width: 900px) {
        height: 100%;
        /* padding-top: 0; */
      }

      .image,
      .video {
        bottom: 0;
        height: 100%;
        position: absolute;
        left: 0;
        right: 0;
        top: 0;
        width: 100%;
        z-index: -1;

        @media (max-width: 900px) {
          object-fit: cover;
        }
      }

      .video-desktop {
        bottom: 0;
        /* height: 100%; */
        position: absolute;
        left: 0;
        right: 0;
        top: 0;
        width: 100%;
        z-index: -1;
        @media (max-width: 900px) {
          object-fit: contain;
        }
        @media (max-width: 768px) {
          display: none;
        }
      }

      .iframe_container {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 0;
      }
    }

    .flairs {
      * {
        pointer-events: none;
        position: absolute;
        z-index: 2;
      }

      .bombie {
        bottom: -125px;
        height: 290px;
        left: -75px;
        width: 194px;

        @media (max-width: 900px) {
          bottom: -60px;
          height: 194px;
          left: calc(50% - 65px);
          width: 130px;
        }

        @media (max-width: 500px) {
          bottom: 20px;
          height: 119px;
          left: calc(50% - 40px);
          width: 80px;
        }
      }

      .little-guy {
        height: 120px;
        right: -25px;
        top: 120px;
        width: 120px;

        @media (max-width: 900px) {
          display: none;
        }
      }

      .square {
        bottom: -60px;
        height: 115px;
        right: 125px;
        width: 115px;

        @media (max-width: 900px) {
          display: none;
        }
      }
    }
  }
`

const HeroImage = ({data, path}) => {
  const {
    backgroundImage,
    buttons,
    mainText,
    textCarousel,
    mobileVideo,
    video,
    placeholderImg,
  } = data;

  const settings = {
    arrows: false,
    autoplay: true,
    autoplaySpeed: 5000,
    dots: false,
    infinite: true,
    pauseOnFocus: false,
    pauseOnHover: false,
    slidesToScroll: 1,
    slidesToShow: 1,
    speed: 500,
  };

  const [isMenu, setIsMenu]  = useState();

  useEffect(() => {
    if(typeof window !== "undefined"){
      if(window.location.pathname.includes('menu')){
        setIsMenu(true);
      }else{
        setIsMenu(false);
      }
    }
  }, []);

  return (
    <HeroImageWrapper>
    <div className='hero_container' style={
      isMenu ? {padding:'4rem 0px 12rem 0px'} : {padding:'4rem 128px 12rem 128px'
      }}>
      {backgroundImage !== null && (
        <div className="background-image">
          <GatsbyImage
            alt={backgroundImage.title}
            image={getImage(backgroundImage.gatsbyImageData)}
            objectFit="cover"
            style={{
              height: "100%",
              width: "100%",
            }}
          />
        </div>
      )}

      <div className="content">
        <div className="media">
          {video !== null && (
            <video
              autoPlay
              className={[mobileVideo ? 'video-desktop' : 'video'].join('')}
              playsInline
              loop
              muted
              src={video.url}
              poster={placeholderImg?.url}
            />
          )}
        </div>
        {mobileVideo &&
        <div className="mobile-media">
          <video
              autoPlay
              className="video-mobile"
              playsInline
              loop
              muted
              src={mobileVideo.url}
            />
        </div>}

        <div className="text">
          {textCarousel === true && (
            <Slider {...settings}>
              {JSON.parse(mainText.raw).content.map((json_text_section, index) => {
                return (
                  <div key={index}>
                    {documentToReactComponents(json_text_section)}
                  </div>
                );
              })}
            </Slider>
          )}

          {textCarousel === false && mainText && documentToReactComponents(JSON.parse(mainText.raw))}
        </div>

        { buttons && <div className={`buttons buttons--${buttons.length}`}>
          {buttons.map((button, index) => {
            return (
              <div className="button-wrapper">
                <Button
                  data={{ button }}
                  glow={{
                    "Black":"#000000",
                    "Blue": "var(--neon-blue)",
                    "Pink": "var(--neon-pink)",
                    "Yellow": "var(--neon-yellow)",
                    "Green": "var(--neon-green)",
                    "White": "#FFFFFF",
                  }[button.textColor]}
                  index={index}
                  withFlair={true}
                />
              </div>
            )
          })}

          <div className="flairs">
            <img
              alt=""
              className="bombie"
              src={bombie}
            />

            <img
              alt=""
              className="little-guy"
              src={little_guy}
            />

            <img
              alt=""
              className="square"
              src={square}
            />
          </div>
        </div>}
      </div>
    </div>
    </HeroImageWrapper>
  )
}

export default HeroImage