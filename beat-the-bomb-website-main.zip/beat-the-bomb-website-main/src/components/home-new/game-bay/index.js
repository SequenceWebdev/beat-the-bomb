import React from 'react'
import styled from 'styled-components'
import { documentToReactComponents } from '@contentful/rich-text-react-renderer'
import { BLOCKS, MARKS } from '@contentful/rich-text-types'
import Button from '../button'
import LogoCarousel from '../logo-carousel'
// Images
import square_corner from '../../../assets/images/flair/square-corner.png';


const GameBayOuterWrapper = styled.div`
  width: 100%;
  position: relative;
  /* background-image: ${({bg}) => `url(${bg})`} ;
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center center; */

  .background-image {
    bottom: 0;
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    z-index: 0;

    &::after {
      background: linear-gradient( to bottom,
    rgba(0, 0, 0, 1) 0%,
    rgba(0, 0, 0, 0) 10%,
    rgba(0, 0, 0, 0) 90%,
    rgba(0, 0, 0, 1) 100%);
      bottom: 0;
      content: "";
      display: block;
      height: 100%;
      left: 0;
      position: absolute;
      right: 0;
    }
  }
  

  @media only screen and (max-width: 1024px){
    background-image: none;
  }
`

const Content = styled.div`
  width: 100%;
  position: relative;
  max-width: 1920px;
  margin: 0 auto;
  padding: 100px 128px;

  .grid-container {
    width: 100%;
    display: grid;
    grid-template-columns: 50% 50%;
    place-items: center;
    column-gap: 3rem;

    @media only screen and (max-width: 1024px){
      grid-template-columns: 1fr;
      column-gap: 0;
      row-gap: 2rem;
    }
  }

  .video {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;

    @media only screen and (max-width: 1024px){
      position: relative;
    }
  }

  .square-corner {
    height: 115px;
    right: -45px;
    pointer-events: none;
    position: absolute;
    bottom: -45px;
    transform: rotate(180deg);
    width: 115px;
    z-index: 0;

    @media only screen and (max-width: 1024px){
      width: 71px;
      height: 71px;
      bottom: -20px;
      right: -25px;
    }

    @media only screen and (max-width: 768px){
      display: none;
    }
  }

  .gb-info-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: stretch;

    p, strong {
      text-align: center;
      font-family: "Acumin Pro";
      font-weight: 300;
      font-size: 33px;
      line-height: 142%;
      letter-spacing: 0px;
      color: #FFFFFF;

      @media only screen and (max-width: 1600px){
        font-size: 24px;
      }
      
      @media only screen and (max-width: 1440px){
        font-size: 20px;
      }

      @media only screen and (max-width: 1024px){
        font-size: 18px;
      }

      @media only screen and (max-width: 900px){
        font-size: 16px;
      }

      @media only screen and (max-width: 480px){
        display: none;
      }
    }

    strong {
      font-style: italic;
      font-weight: 900;
    }
  }

  .gb-header-text {
    text-align: center;
    font-family: "Acumin Pro";
    font-style: italic;
    font-weight: 900;
    font-size: 40px;
    line-height: 56px;
    letter-spacing: 0px;
    color: #FFFFFF;
    opacity: 1;
    text-transform: uppercase;

    @media only screen and (max-width: 1440px){
      font-size: 35px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 30px;
    }

    @media only screen and (max-width: 900px){
      font-size: 25px;
    }

    @media only screen and (max-width: 480px){
      margin-bottom: 1rem;
    }
  }

  .gb-subheader-text {
    text-align: center;
    font-family: "Pixel";
    font-size: 59px;
    line-height: 118%;
    margin-bottom: 2rem;
    letter-spacing: 0px;
    color: var(--neon-blue);
    opacity: 1;

    @media only screen and (max-width: 1600px){
      font-size: 42px;
    }

    @media only screen and (max-width: 1440px){
      font-size: 35px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 30px;
    }

    @media only screen and (max-width: 900px){
      font-size: 25px;
    }

    @media only screen and (max-width: 480px){
      margin-bottom: 1rem;
    }
  }

  .gb-icon-grid-container {
    margin-top: 2rem;
    display: flex;
    flex-wrap: wrap;
    max-width: 540px;
    align-items: center;
    column-gap: 0.25rem;
    width: 100%;

    img {
      height: auto;
      width: 130px;

      @media only screen and (max-width: 1440px){
        width: 75px;
      }
    }

    @media only screen and (max-width: 1440px){
      max-width: 315px;
    }

    @media only screen and (max-width: 900px){
      display: none;
    }
  }

  .button-grid-container {
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-gap: 3rem;
    width: 100%;

    & > div:first-child > div {
      justify-content: flex-end;

      @media only screen and (max-width: 480px){
        justify-content: center;
      }
    }

    & > div:last-child > div {
      justify-content: flex-start;

      @media only screen and (max-width: 480px){
        justify-content: center;
      }
    }

    @media only screen and (max-width: 1024px){

      & > div:first-child > div {
        margin-top: 0rem;
      }

      & > div:last-child > div {
        margin-top: 0rem;
      }

      & > div:first-child {
        margin-top: 2rem;

        @media only screen and (max-width: 768px){
          margin-top: 1rem;
          margin-bottom: 1rem;
        }

        @media only screen and (max-width: 480px){
          margin-top: 0;
        }
      }

      & > div:last-child {
        margin-top: 2rem;

        @media only screen and (max-width: 768px){
          margin-top: 1rem;
          margin-bottom: 1rem;
        }

        @media only screen and (max-width: 480px){
          margin-top: 0;
        }
      }

      & > div:first-child > div > a > span {
        @media only screen and (max-width: 500px){
          font-size: 15px;
          line-height: 18px;
        }
      }

      & > div:last-child > div > a > span {
        @media only screen and (max-width: 500px){
          font-size: 15px;
          line-height: 18px;
        }
      }
    }

    @media only screen and (max-width: 480px){
      grid-gap: 1rem;
      justify-content: center;
    }
  }

  .button-wrapper {
    position: relative;
    z-index: 3;
    margin-top: -3rem;

    & > div {
      justify-content: center;

      @media only screen and (max-width: 1024px){
        justify-content: center;
      }
    }

    & > div > div,a {
      /* text-align: left; */
      font-family: "Pixel";
      text-transform: uppercase;
      font-size: 28px;
      letter-spacing: 0px;
      color: #00FF7B;
      opacity: 1;

      @media only screen and (max-width: 1600px){
        font-size: 18px;
      }

      @media only screen and (max-width: 1024px){
        font-size: 16px;
      }

      @media only screen and (max-width: 480px){
        font-size: 15px;
      }
    }

    & > div > div,a > span {
      padding: 15px 27px 12px 27px;
    }

    @media only screen and (max-width: 500px){
      margin-top: -1rem;
    }
  }

  @media only screen and (max-width: 1024px){
    padding-top: 0;
    padding-bottom: 0;
  }

  @media only screen and (max-width: 900px){
    padding-left: 20px;
    padding-right: 20px;
  }
`

const VideoContainer = styled.div`
  position: relative;
  height: 100%;
  width: 100%;
  border: 4px solid var(${({borderColor}) => `--neon-${borderColor.toLowerCase()}`});

  .border-flair {
    pointer-events: none;
    position: absolute;
  }

  .border-flair--bottom-right {
    bottom: -2px;
    right: -1px;
  }

  .border-flair--top-left {
    left: -1px;
    top: -2px;
  }

  @media only screen and (max-width: 1024px){
    display: none;
  }
`

const RICHTEXT_OPTIONS = {
  renderMark: {
    [MARKS.BOLD]: text => <strong>{text}</strong>,
  },
  renderNode: {
    [BLOCKS.PARAGRAPH]: (node, children) =>{
      return children!='' && (<p>{children}</p>)
    },
  }
}

const MobileVideoWrapper = styled.div`
  position: relative;
  width: 100%;
  height: 100%;
  margin-bottom: 1rem;

  video {
    border: 4px solid var(${({borderColor}) => `--neon-${borderColor.toLowerCase()}`});
  }

  @media only screen and (min-width: 1025px){
    display: none;
  }
`

const LogoCarouselMobileWrapper = styled.div`
  margin-top: 0rem;

  & > div {
    margin-top: 1rem;
    max-width: 650px;

    @media only screen and (max-width: 1600px){
      max-width: 500px;
    }

    @media only screen and (max-width: 1440px){
      max-width: 425px;
    }
  }

  .slide {
    height: auto;
    width: 160px;

    @media only screen and (max-width: 1440px){
      width: 130px;
    }

    @media only screen and (max-width: 1250px){
      width: 100px;
    }
  }

  @media only screen and (max-width: 1024px){
    display: none;
  }
`

const LogoCarouselMobileWrapper2 = styled.div`
  margin-top: 0rem;

  & > div {
    margin-top: 1rem;

    @media only screen and (max-width: 768px){
      margin-top: 0;
    }
  }

  .slide {
    height: 75px;
    width: auto;

    @media only screen and (max-width: 480px){
      height: 52px;
    }
  }

  @media only screen and (min-width: 1025px){
    display: none;
  }

  @media only screen and (max-width: 500px){
    margin-top: -0.5rem;
  }
`

const GameBay = ({ data }) => {
  const {header, secondHeader, description, placeholder, buttons, video, backgroundImage, carousel, gameBayIcons } = data;
  return (
    <GameBayOuterWrapper bg={backgroundImage.url}>
      <div className="background-image">
        <img
          alt={backgroundImage.title}
          src={backgroundImage.url}
          style={{
            height: "100%",
            width: "100%",
            objectFit: "cover",
          }}
        />
      </div>
      <Content>
        <div className="grid-container">
          <VideoContainer borderColor="Blue">
            <video
              autoPlay
              className="video"
              playsInline
              loop
              muted
              src={video.url}
              poster={placeholder.url}
            />
            <img
              alt="square-corner"
              className="square-corner"
              src={square_corner}
            />
            <VideoInner
              flairColor="var(--neon-blue)"
              withFlair={true}
            />
          </VideoContainer>
          <div className="gb-info-container">
            <h3 className='gb-header-text'>{header}</h3>
            <MobileVideoWrapper borderColor="Blue">
              <video
                autoPlay
                className="video"
                playsInline
                loop
                muted
                src={video.url}
                poster={placeholder.url}
              />
              <img
                alt="square-corner"
                className="square-corner"
                src={square_corner}
              />
            </MobileVideoWrapper>
            <h4 className='gb-subheader-text'>{secondHeader}</h4>
            {documentToReactComponents(JSON.parse(description.raw), RICHTEXT_OPTIONS)}
              
            <div className="button-grid-container">
              {buttons.map((button, index) => {
                return (
                  <div className="button-wrapper">
                    <Button
                      data={{ button }}
                      glow={{
                        "Black":"#000000",
                        "Blue": "var(--neon-blue)",
                        "Pink": "var(--neon-pink)",
                        "Yellow": "var(--neon-yellow)",
                        "Green": "var(--neon-green)",
                        "White": "#FFFFFF",
                      }[button.textColor]}
                      index={index}
                      withFlair={true}
                    />
                  </div>
                )
              })}
            </div>
            {/* <div className="gb-icon-grid-container">
              {gameBayIcons.map((icon, index)=>{
                return (
                  <img 
                    key={index}
                    alt={icon.title}
                    src={icon.url}
                  />
                )
              })}
            </div> */}
            <LogoCarouselMobileWrapper>
              <LogoCarousel data={carousel}/>
            </LogoCarouselMobileWrapper>
          </div>
        </div>
        <LogoCarouselMobileWrapper2>
          <LogoCarousel data={carousel}/>
        </LogoCarouselMobileWrapper2>
      </Content>
    </GameBayOuterWrapper>
  )
}

const VideoInner = ({
  flairColor,
  withFlair,
}) => {
  return (
    <span>
      {withFlair === true && (
        <BorderFlair
          color={flairColor}
          corner="top-left"
        />
      )}
      {withFlair === true && (
        <BorderFlair
          color={flairColor}
          corner="bottom-right"
        />
      )}
    </span>
  );
}

const BorderFlair = ({
  color,
  corner,
}) => {
  return (
    <svg
      class={`border-flair border-flair--${corner}`}
      fill="none"
      height="74"
      viewBox="0 0 975 976"
      xmlns="http://www.w3.org/2000/svg"
      width="71"
    >
      {corner === "bottom-right" && (
        <path
          clip-rule="evenodd"
          d="M175 975L175 975.002L0 975.002L174.984 800.018L174.984 800L800 800L800 175L975 1.07671e-05L975 175L975 975L974.984 975L974.984 975L175 975Z"
          fill={color}
          fill-rule="evenodd"
        />
      )}

      {corner === "top-left" && (
        <path
          clip-rule="evenodd"
          d="M800 0.00236591L800 -5.56264e-06L975 0L800.016 174.984L800.016 175.002L175 175.002L175 800.002L-4.94084e-05 975.002L9.53993e-06 800.002L0 0.00241806L0.015625 0.00241806V0.00241041L800 0.00236591Z"
          fill={color}
          fill-rule="evenodd"
        />
      )}
    </svg>
  );
}

export default GameBay