import React from 'react'
import styled from 'styled-components';
import LogoCarousel from '../logo-carousel';
//Images
import square_corner from '../../../assets/images/flair/square-corner.png';
import square from '../../../assets/images/flair/square.png';

const OuterWrapper = styled.div`
  width: 100%;
`

const MainWrapper = styled.div`
  width: 100%;
  max-width: 1920px;
  margin-left: auto;
  margin-right: auto;
  padding-left: 128px;
  padding-right: 128px;
  margin-bottom: 3rem;

  .as-seen-header {
    padding-top: 4rem;
    text-align: center;
    font-family: "Acumin Pro";
    font-style: italic;
    font-weight: 900;
    font-size: 45px;
    letter-spacing: 0px;
    text-transform: uppercase;
    color: #FFFFFF;
    opacity: 1;
    margin-bottom: 2rem;

    @media only screen and (max-width: 1024px){
      padding-top: 2rem;
      font-size: 20px;
    }

    @media only screen and (max-width: 768px){
      margin-bottom: 1rem;
    }

    @media only screen and (max-width: 480px){
      margin-bottom: 0.5rem;
    }
  }

  .video-container {
    position: relative;
    /* padding-bottom: 56.25%; 16:9 */
    margin-left: auto;
    margin-right: auto;
    width: 100%;
    max-width:900px; 

    @media (max-width: 900px) {
      height: 100%;
      padding-top: 0;
    }
  }
  .video {
    /* position: absolute; */
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    max-height: 500px;
    object-fit: contain;
  }

  .square-corner {
    height: 115px;
    right: -45px;
    pointer-events: none;
    position: absolute;
    top: -35px;
    transform: rotate(90deg);
    width: 135px;
    z-index: 0;

    @media only screen and (max-width: 1024px){
      width: 71px;
      height: 71px;
      top: -25px;
      right: -25px;
    }

    @media only screen and (max-width: 480px){
      display: none;
    }
  }

  .icons-container {
    margin-top: 2rem;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-evenly;

    @media only screen and (max-width: 768px){
      display: none;
    }
  }

  .icon-img {
    width: auto;
    height: 75px;

    @media only screen and (max-width: 1440px){
      height: 63px;
    }

    @media only screen and (max-width: 1024px){
      height: 44px;
    }
  }

  .flairs {
    * {
      position: absolute;
      z-index: 2;
    }

    .square {
      bottom: 50px;
      height: 115px;
      left: -100px;
      width: 115px;

      @media only screen and (max-width: 1024px){
        height: 70px;
        width: 70px;
      }

      @media only screen and (max-width: 900px){
        top: 33px;
        left: 20px;
      }

      @media only screen and (max-width: 480px){
        top: 15px;
        width: 38px;
        height: 38px;
      }
    }
  }

  @media only screen and (max-width: 900px){
    padding: 0;
  }

  @media only screen and (max-width: 768px){
    margin-bottom: 0;
  }
`

const LogoCarouselMobileWrapper = styled.div`
  display: inline-block;
  margin-top: 0rem;

  .slide {
    @media only screen and (max-width: 768px){
      height: 44px;
    }

    @media only screen and (max-width: 500px){
      height: 39px;
    }
  }

  @media only screen and (min-width: 769px){
    display: none;
  }

  @media only screen and (max-width: 500px){
    margin-top: -0.5rem;
  }
`


const AsSeenIn = ({data}) => {
  const { header, media, icons, placeholder, carousel } = data;
  return (
    <OuterWrapper>
      <MainWrapper>
        <h2 className='as-seen-header'>{header}</h2>
        <div className="video-container">
          <video
            controls
            className="video"
            src={media.url}
            poster={placeholder.url}
          />
          <img
            alt=""
            className="square-corner"
            src={square_corner}
          />

          <div className="flairs">
            <img
                alt="square-green"
                className="square"
                src={square}
              />
          </div>
        </div>
        <div className="icons-container">
          {icons.map((icon, index)=>{
            return (
              <img key={index} alt={icon.title} className="icon-img" src={icon.url}/>
            )
          })}
        </div>
        <LogoCarouselMobileWrapper>
          <LogoCarousel data={carousel}/>
        </LogoCarouselMobileWrapper>
      </MainWrapper>
    </OuterWrapper>
  )
}

export default AsSeenIn;