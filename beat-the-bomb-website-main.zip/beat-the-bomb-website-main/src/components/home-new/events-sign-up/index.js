import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from 'styled-components'
import { documentToReactComponents } from '@contentful/rich-text-react-renderer'
import { BLOCKS } from '@contentful/rich-text-types'
import { Button } from '../../home-new'


const SignUpWrapper = styled.div`
  max-width: 1920px;
  position: relative;
  left: 50%;
  transform: translateX(-50%);
  margin-top: 3rem;

  .background__container{
    position: relative;
    padding: 3rem 4rem;
    width: 100%;
    
    @media only screen and (max-width: 768px){
      padding: 3rem 12px;
    }
  }
  
  .button-wrapper {
    position: relative;
    z-index: 3;
    margin-top: -3rem;

    & > div {
      justify-content: flex-start;
    }

    & > div > div,a > span {
      /* text-align: left; */
      font-family: "Pixel";
      font-weight: 700;
      text-transform: uppercase;
      font-size: 28px;
      line-height: 142%;
      letter-spacing: 0px;
      /* color: #00FF7B; */
      opacity: 1;

      @media only screen and (max-width: 900px){
        font-size: 18px;
        line-height: 26px;
      }
    }

    & > div > a > span {
      padding: 15px 50px 12px 50px;

      /* @media only screen and (max-width: 480px){
        font-size: 15px;
      } */
    }
  }

    .bg__container {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: -1;
  }

  .bg-img {
    height: 100%;
  }
`

const TextContainer = styled.div`
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  max-width: 1000px;
  margin-left: auto;
  margin-right: auto;

  @media only screen and (max-width: 768px){
    width: 100%;
  }

  .top_text__container p{
    text-align: center;
    font-family: "Acumin Pro";
    font-weight: 900;
    font-style: italic;
    font-size: 80px;
    line-height: 112%;
    letter-spacing: 0px;
    color: #FFFFFF;
    text-transform: uppercase;
    opacity: 1;
    position: relative;
    z-index: 3;

    @media only screen and (max-width: 1600px){
      font-size: 60px;
    }

    @media only screen and (max-width: 1440px){
      font-size: 48px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 43px;
      text-align: center;
    }
  }

  .sign_up__container{
    width: 100%;
    @media only screen and (max-width: 500px){
      width: 80%;
    }
  }

  .sign_up__container button{
    background-color: var(--neon-green);
    font-family: 'Pixel';
    font-style: normal;
    font-weight: 400;
    font-size: 18px;
    line-height: 21px;
    text-align: center;
    color: #000000;
    width: 100%;
    height: 49px;
    max-width: 181px;

    @media only screen and (max-width: 500px){
      height: 30px;
      width: 35%;
    }
  }

  .sign_up__container input{
    height: 51px;
    width: 100%;
    max-width: 343px;

    @media only screen and (max-width: 500px){
      width: 65%;
      height: 30px;
    }
  }
`

const RichTextContainer = styled.div`
  width: 100%;
  margin-left: auto;
  margin-right: auto;
  margin-bottom:-1rem;

  .rich_paragraph{
    font-family: "Acumin Pro";
    font-style: normal;
    font-weight: 700;
    font-size: 33px;
    line-height: 133%;
    color: #ffffff;
    margin-bottom: 1rem;
    text-align: center;

    @media only screen and (max-width: 1600px){
      font-size: 24px;
    }
    
    @media only screen and (max-width: 1440px){
      font-size: 20px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 18px;
      text-align: center;
    }

    @media only screen and (max-width: 900px){
      font-size: 16px;
    }

    @media only screen and (max-width: 480px){
      font-size: 15px;
      line-height: 18px;
    }
  }

  @media only screen and (max-width: 500px){
    margin-bottom: 0;
    padding: 0 20px;
  }
`

const RICHTEXT_OPTIONS = {
  renderNode: {
    [BLOCKS.PARAGRAPH]: (node, children) =>{
      return children!='' && (<p className='rich_paragraph'>{children}</p>)
    },
  }
}


const EventsSignUp = ({ data, path }) => {
  const { header, richText, button, backgroundImage } = data
  const json_text = JSON.parse(richText.raw);
  return (
    <SignUpWrapper>
      <div className="background__container">
        <div className='bg__container'>
          <GatsbyImage className="bg-img" image={getImage(backgroundImage.gatsbyImageData)}/>
        </div>
 
        <TextContainer>
          <div className="top_text__container">
            <p>{header}</p>
          </div>
          <div className="mid_text__container">
            <RichTextContainer>
            {documentToReactComponents(json_text, RICHTEXT_OPTIONS)}
            </RichTextContainer>
          </div>
          <div className="button-wrapper">
            <Button
              data={{ button }}
              glow={{
                "Black":"#000000",
                "Blue": "var(--neon-blue)",
                "Pink": "var(--neon-pink)",
                "Yellow": "var(--neon-yellow)",
                "Green": "var(--neon-green)",
                "White": "#FFFFFF",
              }[button.textColor]}
              withFlair={true}
            />
          </div>
        </TextContainer>
      </div>
    </SignUpWrapper>
  )
}

export default EventsSignUp