import React from 'react'
import styled from 'styled-components';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import LogoCarousel from '../logo-carousel'
// Images
import bombie from '../../../assets/images/flair/bombie-grey.png';
import star from '../../../assets/images/reviews/star.png';

const Reviews = styled.div`
  position: relative;
  margin-bottom: 5rem;

  .wrapper {
    margin: 0 auto;
    max-width: 1440px;
    padding: 0 40px;
  }

  .as-seen-header {
    text-align: center;
    font-family: "Acumin Pro";
    font-style: italic;
    font-weight: 900;
    font-size: 45px;
    letter-spacing: 0px;
    text-transform: uppercase;
    color: #FFFFFF;
    opacity: 1;
    margin-bottom: 2rem;

    @media only screen and (max-width: 1600px){
      font-size: 40px;
    }
    
    @media only screen and (max-width: 1440px){
      font-size: 35px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 30px;
    }

    @media only screen and (max-width: 900px){
      font-size: 25px;
    }

    @media only screen and (max-width: 480px) {
      font-size: 20px; 
    }
  }

  .icons-container {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-evenly;
    margin-bottom: 2rem;

    @media only screen and (max-width: 768px){
      display: none;
    }
  }

  .icon-img {
    width: auto;
    height: 75px;

    @media only screen and (max-width: 1440px){
      height: 55px;
    }

    @media only screen and (max-width: 1024px){
      height: 45px;
    }

    @media only screen and (max-width: 500px){
      height: 43px;
    }

  }

  .stars {
    display: flex;
    justify-content: center;
    margin-bottom: 40px;

    @media only screen and (max-width: 480px){
      margin-bottom: 20px;
    }
  }

  .stars img {
    height: 56px;
    width: 56px;

    @media (max-width: 768px) {
      height: 40px;
      width: 40px;
    }
  }

  .title {
    color: white;
    font-size: 40px;
    font-family: "Acumin Pro";
    font-style: italic;
    font-weight: 700;
    margin-bottom: 3rem;
    text-align: center;
    text-transform: uppercase;

    @media (max-width: 600px) {
      font-size: 25px;
      white-space: pre-line;
    }
  }

  .slick-slider-wrapper {
    position: relative;
    margin-bottom: 2rem;

    @media only screen and (max-width: 1440px){
      margin-top: 2rem;
    }
  }

  .slick-track {
    display: flex !important;
  }

  .slick-slide {
    height: inherit !important;
  }

  .slick-slide > div {
    height: 100%;
  }

  .slick-arrow::before {
    background-position: center;
    background-size: 30px;
    content: "" !important;
    display: block !important;
    height: 20px !important;
    width: 20px !important;
  }

  .slick-next::before {
    background-image: url('data:image/svg+xml;utf8,<svg fill="none" height="24" stroke="%2300FF7B" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><polyline points="9 18 15 12 9 6" /></svg>');
  }

  .slick-prev::before {
    background-image: url('data:image/svg+xml;utf8,<svg fill="none" height="24" stroke="%2300FF7B" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><polyline points="15 18 9 12 15 6" /></svg>');
  }

  .bombie {
    height: 580px;
    pointer-events: none;
    position: absolute;
    left: 90px;
    top: 50px;
    width: 388px;
    z-index: 0;

    @media (max-width: 900px) {
      height: 412px;
      top:0;
      left: 50%;
      transform: translateX(-50%);
      width: 302px;
    }
  }

  .square-corner-1 {
    height: 100px;
    left: -25px;
    pointer-events: none;
    position: absolute;
    top: -25px;
    width: 100px;
    z-index: 0;
  }

  .square-corner-2 {
    bottom: -25px;
    height: 100px;
    right: -25px;
    pointer-events: none;
    position: absolute;
    transform: rotate(180deg);
    width: 100px;
    z-index: 0;
  }

  @media only screen and (max-width: 768px){
    margin-bottom: 1rem;
  }

  @media only screen and (max-width: 480px){
    margin-bottom: 0rem;
  }
`

const ReviewCard = styled.div`
  height: 100%;
  padding: 10px;

  .inner {
    border: solid 4px ${({color}) => `var(--neon-${color})`};
    box-shadow: 0 0 10px 0 ${({color}) => `var(--neon-${color})`}, inset 0 0 10px 0 ${({color}) => `var(--neon-${color})`};
    color: white;
    display: flex;
    flex-direction: column;
    height: 100%;
    max-width: 1000px;
    padding: 25px 40px;
    text-align: center;

    @media (max-width: 900px) {
      padding: 25px;
    }
  }

  .source {
    align-items: center;
    display: flex;
    justify-content: center;
    height: 55px;
    margin: 0 auto 25px auto;
    width: 200px;

    @media (max-width: 600px) {
      width: 150px;
    }
  }

  .author {
    color: ${({color}) => `var(--neon-${color})`};
    font-family: 'Pixel', sans-serif;
    font-size: 25px;

    @media (max-width: 600px) {
      font-size: 15px;
    }
  }

  .review {
    font-size: 25px;
    line-height: 143%;
    font-family: "Acumin Pro";
    font-weight: 700;

    @media (max-width: 900px) {
      font-size: 16px;
    }

    @media (max-width: 480px) {
      font-size: 12px;
      line-height: 16px;
    }
  }

  .review-stars {
    align-items: center;
    display: none;
    justify-content: center;
    margin-top: auto;

    @media (max-width: 600px) {
      margin-left: auto;
      margin-right: auto;
      width: 200px;
    }
  }
`

const LogoCarouselMobileWrapper = styled.div`
  display: inline-block;
  margin-top: -2rem;

  .slide {
    @media only screen and (max-width: 768px){
      height: 50px;
    }

    @media only screen and (max-width: 500px){
      height: 35px;
    }
  }

  @media only screen and (min-width: 769px){
    display: none;
  }

  @media only screen and (max-width: 500px){
    margin-top: -1rem;
  }
`

const EventsReviewCarousel = ({ data }) => {
  const settings = {
    arrows: false,
    autoplay: true,
    autoplaySpeed: 5000,
    dots: false,
    infinite: true,
    pauseOnFocus: false,
    pauseOnHover: false,
    slidesToScroll: 1,
    slidesToShow: 2,
    speed: 500,
    responsive: [
      {
        breakpoint: 900,
        settings: {
          arrows: true,
          slidesToShow: 1,
        },
      },
    ],
  };

  return (
    <Reviews>
      <div className="wrapper">
        {data.title && <h2 className="title">{data.title.title}</h2>}
        <div className="slick-slider-wrapper">
          <Slider {...settings}>
            {data.reviewTestimonials.map((card, index)=>{
              const { clientName, review, backgroundColor } = card;
              return(
                <ReviewCard key={index} color={backgroundColor}>
                  <div className="inner">
                    <p className="author">{clientName}</p>
                    <div className="stars">
                      {[1, 2, 3, 4, 5].map(index => {
                        return (
                          <img
                            alt=""
                            key={index}
                            src={star}
                          />
                        );
                      })}
                    </div>
                    <p className="review">{review.review}</p>
                  </div>
                </ReviewCard>
              )
            })}
          </Slider>
        </div>
        <h3 className='as-seen-header'>{data.asSeenInText}</h3>
        <div className="icons-container">
          {data.icons.map((icon, index)=>{
            return (
              <img key={index} alt={icon.title} className="icon-img" src={icon.url}/>
            )
          })}
        </div>
        <LogoCarouselMobileWrapper>
          <LogoCarousel data={data.carousel}/>
        </LogoCarouselMobileWrapper>
      </div>

      <img
        alt=""
        className="bombie"
        src={bombie}
      />
    </Reviews>
  );
}

export default EventsReviewCarousel
