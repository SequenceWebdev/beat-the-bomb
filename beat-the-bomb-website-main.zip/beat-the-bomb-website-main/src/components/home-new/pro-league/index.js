import React, { useEffect, useState } from 'react'
import styled from 'styled-components'
import Button from '../button'

//images
import pink_trophy from '../../../assets/images/leaderboard/pink-trophy.png';
import green_trophy from '../../../assets/images/leaderboard/green-trophy.png';
import blue_trophy from '../../../assets/images/leaderboard/blue-trophy.png';
import square_corner from '../../../assets/images/flair/square-corner.png';

const ProLeagueWrapper = styled.div`
  width: 100%;
  max-width: 1920px;
  margin-left: auto;
  margin-right: auto;
  margin-top: 3rem;
  padding-left: 128px;
  padding-right: 128px;

  .content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    column-gap: 2rem;
    justify-content: space-between;

    @media only screen and (max-width: 1024px){
      display: flex;
      flex-direction: column;
      align-items: center;
      row-gap: 2rem;
    }
  }
  
  .content-right-col {
    position: relative;

    h3 {
      text-align: center;
      font-family: "Acumin Pro";
      font-size: 40px;
      font-style: italic;
      line-height: 56px;
      font-weight: 900;
      letter-spacing: 0px;
      text-transform: uppercase;
      color: #FFFFFF;
      opacity: 1;

      @media only screen and (max-width: 1440px){
        font-size: 35px;
      }

      @media only screen and (max-width: 1024px){
        font-size: 30px;
      }

      @media only screen and (max-width: 900px){
        font-size: 25px;
      }

      @media only screen and (max-width: 480px){
        display: none;
      }
    }
  }

  .button-wrapper {
    position: relative;
    z-index: 3;
    margin-top: -3rem;

    & > div {
      justify-content: center;

      @media only screen and (max-width: 1024px){
        justify-content: center;
      }

      @media only screen and (max-width: 480px){
        margin-top: 1rem;
      }
    }

    & > div > div,a {
      /* text-align: left; */
      font-family: "Pixel";
      text-transform: uppercase;
      font-size: 28px;
      letter-spacing: 0px;
      color: #00FF7B;
      opacity: 1;

      @media only screen and (max-width: 1600px){
        font-size: 18px;
      }

      @media only screen and (max-width: 1024px){
        font-size: 16px;
      }

      @media only screen and (max-width: 480px){
        font-size: 15px;
      }
    }

    & > div > div,a > span {
      padding: 15px 27px 12px 27px;
    }

    @media only screen and (max-width: 500px){
      margin-top: -1rem;
    }
  }

  .leaderboard-content {
    margin-top: 2rem;
    margin-bottom: 3rem;
    position: relative;

    @media only screen and (max-width: 1024px){
      margin-top: 0rem;
    }

    @media only screen and (max-width: 480px){
      display: none;
    }
  }

  .leaderboard-header {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;

    .rank, .team-name, .total-score {
      text-align: center;
      font-family: "Pixel";
      font-size: 44px;
      line-height: 52px;
      letter-spacing: 0px;
      color: #FFFFFF;
      opacity: 1;

      @media only screen and (max-width: 1600px){
        font-size: 37px;
      }

      @media only screen and (max-width: 1440px){
        font-size: 28px;
      }

      @media only screen and (max-width: 1024px){
        font-size: 20px;
      }
    }
  }

  .leaderboard-row {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    border-top: 2px solid #FFFFFF;
    padding-top: 10px;
    margin-top: 6px;
  }

  .team-name, .team-score {
    text-align: center;
    font-family: "Acumin Pro";
    font-weight: 300;
    font-size: 33px;
    line-height: 142%;
    letter-spacing: 0px;
    color: #FFFFFF;

    @media only screen and (max-width: 1600px){
      font-size: 24px;
    }
    
    @media only screen and (max-width: 1440px){
      font-size: 20px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 18px;
    }

    @media only screen and (max-width: 900px){
      font-size: 16px;
    }
  }

  .trophy-img {
    width: 75px;
    height: 76px;

    @media only screen and (max-width: 1440px){
      width: 55px;
      height: 56px;
    }
  }

  .square-corner {
    height: 115px;
    right: -45px;
    pointer-events: none;
    position: absolute;
    bottom: -20px;
    transform: rotate(180deg);
    width: 115px;
    z-index: 0;

    @media only screen and (max-width: 1024px){
      width: 71px;
      height: 71px;
      bottom: -10px;
      right: -30px;
    }
  }

  .pl-img-container {
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .pl-img {
    width: 100%;
    object-fit: contain;
    position: relative;
    transform: translateX(-15px);
  }

  @media only screen and (max-width: 1024px){
    margin-top: 1rem;
  }

  @media only screen and (max-width: 900px){
    padding-left: 20px;
    padding-right: 20px;
  }
`

const ProLeague = (pageContext) => {
  const [all_scores, setAll_scores] = useState([]);

  const { image, leaderboardTitle, button } = pageContext.data;
  const mappedHeaderText = (
    <>
      <div className='rank'>RANK</div>
      <div className='team-name'>TEAM NAME</div>
      <div className='total-score'>SCORE</div>
    </>
  );

  const apiRequest = (isMounted) => {
    const time_start = pageContext.data.startDate;
    const time_end = pageContext.data.endDate;
    const url_brooklyn = `https://btbbrooklyn.ddns.net:8083/sessions/scoreboard/mission/01/type/standard/start/${time_start}/end/${time_end}/offset/0/limit/3`;
    const url_atl = `https://btbatlanta.ddns.net:8083/sessions/scoreboard/mission/01/type/standard/start/${time_start}/end/${time_end}/offset/0/limit/3`
    const url_dc = `https://btbwashington.ddns.net:8083/sessions/scoreboard/mission/01/type/standard/start/${time_start}/end/${time_end}/offset/0/limit/3`;

    if(pageContext.path.includes("atlanta")) {
      fetch(url_atl)
      .then(response => {
        return response.json()
      })
      .then(data =>{
        if(isMounted){
          setAll_scores(data);
        }
      })

    }else if(pageContext.path.includes("brooklyn")){
      fetch(url_brooklyn)
      .then(response => {
        return response.json()
      })
      .then(data =>{
        if(isMounted){
          setAll_scores(data);
        }
      })

    }else if(pageContext.path.includes('dc')){
      fetch(url_dc)
      .then(response => {
        return response.json()
      })
      .then(data =>{
        if(isMounted){
          setAll_scores(data);
        }
      })
    }
  }

  useEffect(() => {
    let mounted = true;
    apiRequest(mounted);
    return () => mounted = false;
  },[]);

  return (
    <ProLeagueWrapper>
      <div className="content">
        <div className='pl-img-container'>
          <img alt={image.title} className="pl-img" src={image.url}/>
        </div>
        <div className="content-right-col">
          <h3>{leaderboardTitle}</h3>
          <div className="leaderboard-content">
            <div className="leaderboard-header">
              {mappedHeaderText}
            </div>
            {all_scores.map(team => 
              <div className='leaderboard-row'>
                {team.rank === 1 && <img alt="1st place trophy icon" className="trophy-img" src={pink_trophy}/>}
                {team.rank === 2 && <img alt="2nd place trophy icon" className="trophy-img" src={blue_trophy}/>}
                {team.rank === 3 && <img alt="3rd place trophy icon" className="trophy-img" src={green_trophy}/>}
                <p className="team-name">{team.Team.name}</p>
                <p className="team-score">{team.total_score}</p>
              </div>
            )}
            <img
              alt="square-corner"
              className="square-corner"
              src={square_corner}
            />
          </div>
          <div className="button-wrapper">
            <Button
              data={{ button }}
              glow={{
                "Black":"#000000",
                "Blue": "var(--neon-blue)",
                "Pink": "var(--neon-pink)",
                "Yellow": "var(--neon-yellow)",
                "Green": "var(--neon-green)",
                "White": "#FFFFFF",
              }[button.textColor]}
              withFlair={true}
            />
          </div>
        </div>
      </div>
    </ProLeagueWrapper>
  )
}

export default ProLeague