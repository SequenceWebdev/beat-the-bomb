import React from 'react'
import styled from 'styled-components'

const ScrollerBody = styled.div`
  overflow: hidden;
  max-width: 1440px;
  margin-top: 3rem;
  margin-bottom: 3rem;
  z-index: 6;
  width:100%;
  /* position:relative;
  left:50%; */
  margin-left: auto;
  margin-right: auto;
  /* transform: translateX(-50%); */

  @media only screen and (max-width: 768px){
    margin-bottom: 2rem;
  }

  @media only screen and (max-width: 500px){
    margin-top: 1.5rem;
  }
  
  .slide-track{
    display:flex;
    align-items: center;
    width: min-content;
    animation: scroll 30s linear infinite;
  }

  .slider{
    display:flex;
    align-items: center;
  }

  .slide{
    width:auto;
    height:88px;
    margin: 0 1rem;
    /* padding: 1rem 2rem; */

    @media only screen and (max-width: 500px){
      height: 50px;
    }
  }
  
  @keyframes scroll {
    0% {
      transform: translateX(0);
    }
    100% {
      transform:translateX(-50%)
    }
  }
`

const LogoCarousel = ({data}) => {
  const assets = data.companyLogos
  return (
    <ScrollerBody>
        <div className="slide-track">
          <div className="slider">
            {assets.map((asset, index) => {
              const {title, url} = asset
              return(
                <img key={index} loading="lazy" alt={title} objectFit="contain" className="slide" imgClassName="slide-img" src={url}/>
              ) 
            })}
            {assets.map((asset, index) => {
              const {title, url} = asset
              return(
                <img key={index} loading="lazy" alt={title} objectFit="contain" className="slide" imgClassName="slide-img" src={url}/>
              ) 
            })}
          </div>
        </div>
    </ScrollerBody>
  )
}

export default LogoCarousel