import React from 'react'
import styled from 'styled-components'
import LocationCard from './location-card'

const LocationsWrapper = styled.div`
  max-width: 1440px;
  position: relative;
  left: 50%;
  transform: translateX(-50%);

  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 5rem;

  @media only screen and (max-width: 768px){
    margin-top: 3rem;
  }
`

const LocationCardsContainer = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  column-gap: 2rem;
  align-items: center;

  @media only screen and (max-width: 768px){
    grid-template-columns: repeat(1,1fr);
    row-gap: 3rem;
  }

  @media only screen and (max-width: 768px){
    padding: 0 2rem;
  }
`

const Locations = ({ data }) => {
  const { locationCards } = data
  return (
    <LocationsWrapper>
      <LocationCardsContainer>
        {locationCards.map((card, index)=>{
          return(
            <LocationCard card={card} key={index}/>
          )
        })}
      </LocationCardsContainer>
    </LocationsWrapper>
  )
}

export default Locations