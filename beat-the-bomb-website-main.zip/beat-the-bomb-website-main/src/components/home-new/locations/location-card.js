import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from 'styled-components'
import Button from '../button'
import { Link } from 'gatsby'

const CardWrapper = styled.div`
  max-width: 370px;
  max-height: 440px;
  position: relative;
  transition: transform 500ms ease;

  &:hover{
    transform: scale(1.05);
  }
  

  .location_text__container{
    position: absolute;
    top: 60%;
    left: 50%;
    transform: translate(-50%,-50%);
    z-index: 5;
  }

  .location_text{
    font-family: 'Acumin Pro';
    font-style: normal;
    font-weight: 700;
    font-size: 60px;
    line-height: 115%;
    text-align: center;
    letter-spacing: 0.015em;
    text-transform: uppercase;
    color: #000000;

    @media only screen and (max-width: 1250px){
      font-size: 55px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 50px;
    }

    @media only screen and (max-width: 768px){
      font-size: 40px;
    }
  }

  .button__container{
    position: absolute;
    left: 0;
    z-index:5;
    width: 100%;
    bottom: 10%;
    /* filter: drop-shadow(0 50px 5rem var(--neon-green)); */

    & div{
      margin-top: 0;
    }

    & div a{
      width: 90%;
      font-size: 36px;
    }

    & div a span{
      width: 100%;
    }
  }

  .card_image{
    max-height: 600px;
    max-width: 720px;
    width: 100%;
    height: 100%;
  }

  .card_image__container{
    width: 100%;
    height: 100%;
    position: relative;
    z-index: -1;
  }
`

const Overlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 0;
  background-image: linear-gradient(to bottom, transparent 60%, var(${({overlayGradientColor}) => `--neon-${overlayGradientColor.toLowerCase()}`}));
  opacity: 0.5;
`

const LocationCard = ({ card }) => {
  const { image, locationText, overlayGradientColor } = card
  return (
    <CardWrapper>
      <Link to={`/${locationText.toLowerCase()}`}>
      <div className="card_image__container">
        <GatsbyImage alt={image.title} className="card_image" image={getImage(image.gatsbyImageData)}/>
      </div>
      
      <div className="button__container">
        <Button data={card} />
      </div>
      {overlayGradientColor &&
        <Overlay overlayGradientColor={overlayGradientColor}/>
      }
      </Link>
      
      
      
    </CardWrapper>
  )
}

export default LocationCard