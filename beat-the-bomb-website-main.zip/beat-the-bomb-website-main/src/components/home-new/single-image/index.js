import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from 'styled-components'
import Button from '../button'

const SingleImageWrapper = styled.div`
  max-width: 1920px;
  display:flex;
  flex-direction: column;
  align-items: center;

  position: relative;
  left:50%;
  transform: translateX(-50%);
  margin-top: 5rem;

  .video__container{
    width: 100%;
    max-width: 1000px;
    padding: 0 1rem;
  }

  .video__container video{
    width: 100%;
  }

  @media only screen and (max-width: 768px){
    margin-top: 2.5rem;
  }

  @media only screen and (max-width: 500px){
    margin-top: 1.5rem;
  }

  .single_image{
    max-width: 1920px;
    position: relative;
    z-index: -1;
  }

  .button__container1{
    position: absolute;
    left: 50%;
    bottom: 15%;
    transform: translateX(-50%);
    z-index:2;
  }

  .button__container2{
    margin-bottom: 2rem;
    margin-top: 1rem;
    z-index: 2;
    position: relative;
  }

  .button__container2 > div{
    margin-top: 0;
  }
`

const Overlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: ${({buttonLocation}) => buttonLocation==='Below Image' ? '100%':'104%'};
  z-index: 0;
  background-image: linear-gradient(to bottom, #000000 5%, transparent 33%, var(${({overlayGradientColor}) => `--neon-${overlayGradientColor.toLowerCase()}`}) 93%, #000000);
  opacity: 0.7;
`

const SingleImage = ({ data }) => {
  const { buttonLocation, overlayGradientColor, image, video } = data
  return (
    <SingleImageWrapper>
      {video===null && 
      <div className="image__container">
        <GatsbyImage alt={image.title} className='single_image' image={getImage(image.gatsbyImageData)}/>
      </div>}
      {video &&
      <div className="video__container">
        <video autoPlay playsInline loop muted>
          <source src={video.url} type="video/mp4" />
        </video>   
      </div>
      }
      {buttonLocation==='On Image' &&
        <div className="button__container1">
          <Button data={data}/>
        </div>
      }
      {buttonLocation==='Below Image' &&
        <div className="button__container2">
          <Button data={data}/>
        </div>
      }
      {overlayGradientColor &&
        <Overlay overlayGradientColor={overlayGradientColor} buttonLocation={buttonLocation}/>
      }
    </SingleImageWrapper>
  )
}

export default SingleImage