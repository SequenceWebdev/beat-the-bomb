import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from 'styled-components'
import EmailSignUp from './emailSignUp'
import square from '../../../assets/images/flair/square.png';
import { documentToReactComponents } from '@contentful/rich-text-react-renderer'
import { BLOCKS } from '@contentful/rich-text-types'


// const SignUpWrapper = styled.div`
//   max-width: 1440px;
//   position: relative;
//   left: 50%;
//   transform: translateX(-50%);
//   margin-top: 3rem;

//   .background__container{
//     position: relative;
//   }
// `

// const TextContainer = styled.div`
//   position: absolute;
//   top: 0;
//   left: 50%;
//   transform: translateX(-50%);
//   width: 70%;
//   height: 100%;
//   display: flex;
//   flex-direction: column;
//   align-items: center;
//   justify-content: space-evenly;
//   z-index: 5;

//   @media only screen and (max-width: 768px){
//     width: 100%;
//   }

//   .top_text__container p{
//     font-family: 'Acumin Pro';
//     font-style: normal;
//     font-weight: 700;
//     font-size: 70px;
//     line-height: 114%;
//     text-align: center;
//     letter-spacing: 0;
//     text-transform: uppercase;
//     color: #FFFFFF;

//     @media only screen and (max-width: 900px){
//       font-size: 50px;
//     }

//     @media only screen and (max-width: 768px){
//       font-size: 40px;
//     }

//     @media only screen and (max-width: 500px){
//       font-size: 20px;
//       margin:0;
//     }
//   }

//   .mid_text__container p{
//     font-family: 'Acumin Pro';
//     font-style: normal;
//     font-weight: 700;
//     font-size: 30px;
//     line-height: 126%;
//     letter-spacing: 0;
//     color: #FFFFFF;
//     text-align: center;

//     @media only screen and (max-width: 900px){
//       font-size: 25px;
//     }

//     @media only screen and (max-width: 768px){
//       font-size: 18px;
//     }

//     @media only screen and (max-width: 500px){
//       font-size: 15px;
//       margin:0;
//     }
//   }

//   .sign_up__container{
//     width: 100%;
//     @media only screen and (max-width: 500px){
//       width: 80%;
//     }
//   }

//   .sign_up__container button{
//     background-color: var(--neon-green);
//     font-family: 'Pixel';
//     font-style: normal;
//     font-weight: 400;
//     font-size: 18px;
//     line-height: 21px;
//     text-align: center;
//     color: #000000;
//     width: 100%;
//     height: 49px;
//     max-width: 181px;

//     @media only screen and (max-width: 500px){
//       height: 30px;
//       width: 35%;
//     }
//   }

//   .sign_up__container input{
//     height: 51px;
//     width: 100%;
//     max-width: 343px;

//     @media only screen and (max-width: 500px){
//       width: 65%;
//       height: 30px;
//     }
//   }
// `

// const Overlay = styled.div`
//   position: absolute;
//   top: 0;
//   left: 0;
//   width: 100%;
//   height: 100%;
//   z-index: 0;
//   background-image: linear-gradient(to bottom, #000000, transparent);
// `

const SignUpOuterWrapper = styled.div`
  width: 100%;
  height: 664px;
  margin-top: 3rem;
  position: relative;

  @media only screen and (max-width: 480px){
    margin-top: 0;
  }
`
const Content = styled.div`
  width: 100%;
  height: 100%;
  max-width: 1920px;
  margin: 0 auto;
  padding: 0 128px;
  position: relative;
  background-image: ${({bg}) => `url(${bg})`} ;
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center center;

  .flairs {
    * {
      pointer-events: none;
      position: absolute;
      z-index: 2;
    }
  }

  .square {
    width: 115px;
    height: 115px;
    top: 0px;
    left: 50px;

    @media only screen and (max-width: 1024px){
      width: 71px;
      height: 71px;
      top: 50px;
    }

    @media only screen and (max-width: 480px){
      display: none;
    }
  }

  .grid-container {
    width: 100%;
    display: grid;
    grid-template-columns: 60% 40%;
    place-items: center;
    column-gap: 1rem;
    position: relative;
    top: 50%;
    transform: translateY(-50%);
    z-index: 2;

    @media only screen and (max-width: 1024px){
      grid-template-columns: 1fr;
      column-gap: 0;
    }
  }

  .bg {
    height: 664px;
    pointer-events: none;
    position: absolute;
    left: 0;
    top: 0;
    width: 1920px;
    z-index: -1;
  }

  .bg-gradient {
    transform: rotate(-3deg);
    position: absolute;
    pointer-events: none;
    left: 50%;
    top: 0;
    width: 100%;
    transform: translateX(-50%);
    height: 100%;
    z-index: 0;
    background-image: linear-gradient(to left, black, transparent, black) !important;
  }

  .grid-left-side {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: stretch;
  }

  h3 {
    text-align: center;
    font-family: "Pixel";
    font-size: 70px;
    line-height: 117%;
    letter-spacing: 0px;
    color: #FFFFFF;
    text-shadow: 0px 3px 6px #000000B3;
    opacity: 1;

    @media only screen and (max-width: 1600px){
      font-size: 55px;
    }

    @media only screen and (max-width: 1440px){
      font-size: 48px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 35px;
    }

    @media only screen and (max-width: 480px){
      font-size: 20px;
    }
  }

  p {
    text-align: center;
    font-family: "Acumin Pro";
    font-size: 33px;
    font-weight: 300;
    line-height: 142%;
    letter-spacing: 0px;
    color: #FFFFFF;
    text-shadow: 0px 5px 6px #000000;
    opacity: 1;

    @media only screen and (max-width: 1600px){
      font-size: 24px;
    }
    
    @media only screen and (max-width: 1440px){
      font-size: 20px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 18px;
    }

    @media only screen and (max-width: 900px){
      font-size: 16px;
    }
  }

  @media only screen and (max-width: 900px){
    padding-left: 20px;
    padding-right: 20px;
  }
`

const RICHTEXT_OPTIONS = {
  renderNode: {
    [BLOCKS.PARAGRAPH]: (node, children) =>{
      return children!='' && (<p>{children}</p>)
    },
  }
}

const SignUp = ({ data, path }) => {
  const { topText, bottomText, richText, backgroundImage } = data;
  return (
      <SignUpOuterWrapper>
        <Content bg={backgroundImage.url}>
          <div className="grid-container">
            <div className="grid-left-side">
              <h3>{topText}</h3>
              {richText && documentToReactComponents(JSON.parse(richText.raw), RICHTEXT_OPTIONS)}
              <EmailSignUp pathname={path}/>
            </div>
            <div></div>
          </div>
          <div className='bg-gradient'></div>

          <div className="flairs">
            <img
            alt="green-square"
            className="square"
            src={square}
          />
          </div>
        </Content>
      </SignUpOuterWrapper>
    )
}

export default SignUp