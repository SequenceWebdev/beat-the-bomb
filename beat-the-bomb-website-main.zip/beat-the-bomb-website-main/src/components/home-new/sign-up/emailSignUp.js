/* eslint-disable */
import React, { Component } from "react";
import { subscribe } from "klaviyo-subscribe";

import * as styles from "../../styles/emailListForm.module.css";
import * as mailStyles from "../../styles/mailingList.module.css";
import styled from "styled-components";

const EmailFormWrapper = styled.div`
	width: 80%;
	position: relative;
	
	form {
		width: 100%;
		display: flex;
		flex-direction: row;
		align-items: center;
	}

	input {
		width: 60%;
		border: 4px solid var(--neon-green);
		padding: 7px 19px;
		font-family: "Acumin Pro";
		font-size: 30px;
		line-height: 140%;
		letter-spacing: 0px;
		color: #000000;
		font-weight: 600;

		@media only screen and (max-width: 1024px){
			font-size: 24px;
		}

		@media only screen and (max-width: 768px){
			font-size: 20px;
		}

		@media only screen and (max-width: 480px){
			font-size: 15px;
		}
	}

	.submit-button {
		width: 40%;
		position: relative;
		border: 4px solid var(--neon-green);
		color: var(--neon-green);
		background-color: #000000;
		max-width: 295px;
		padding: 16px 0;

		&:hover {
			background-color: var(--neon-green);
			color: #000000;
		}

		span {
			font-family: 'Pixel';
			font-style: normal;
			font-weight: 400;
			font-size: 18px;
			line-height: 21px;
			text-align: center;

			@media only screen and (max-width: 480px){
				font-size: 15px;
          		line-height: 18px;
			}
		}

		@media only screen and (max-width: 1024px){
			padding: 12px 0;
		}

		@media only screen and (max-width: 768px){
			padding: 10px 0;
		}

		@media only screen and (max-width: 480px){
			padding: 6px 0;
		}
	}

	.border-flair {
    pointer-events: none;
    position: absolute;
  }

  .border-flair--bottom-right {
    bottom: -7px;
    right: -2px;
  }

  .border-flair--top-left {
    left: -2px;
    top: -7px;
  }
`

class EmailSignUp extends Component {
	constructor(props) {
		super(props);
		const curr_path = () => {
			if(props.pathname.includes("/atlanta")){
				return "WtytM6";
			}else if(props.pathname.includes("/dc")){
				return "WcTcX8";
			}else if (props.pathname.includes("/brooklyn")){
				return "S6UqgT";
			}else if (props.pathname === "/"){
				return "Uv9nAK";
			}
		}
		// const curr_path = (props.pathname==="/atlanta")?"WtytM6":"YmSAXL";
		this.state = {
			email: "",
			status: "",
			LIST_ID: curr_path(),
		};
		this.handleChange = this.handleChange.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);
		this.validateEmail = this.validateEmail.bind(this);
	}

	handleSubmit(evt) {
		evt.preventDefault();
		// const LIST_ID ="WtytM6";

		if (!this.validateEmail(this.state.email)) {
			this.setState({
				...this.state,
				message: "Invalid email",
				status: "error"
			});
		} else {
			this.setState({
				...this.state,
				message: "Sending...",
				status: "sending"
			});

			subscribe(this.state.LIST_ID, this.state.email, {})
				.then(response => {
					this.setState({
						email: "",
						message: "Subscribed! Check your email to confirm",
						status: "success"
					});
				}).catch(error => {
					this.setState({
						...this.state,
						message: error,
						status: "error"
					});
				});
		}

		setTimeout(() => {
			this.setState({
				...this.state,
				message: "",
				status: ""
			});
		}, 2000);
	}

	validateEmail(email) {
		const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		return re.test(String(email).toLowerCase());
	}

	handleChange(event) {
		this.setState({
			email: event.target.value,
		});
	}

	render() {
		const dictionary = {
			sending: "blue",
			error: "red",
			success: "var(--neon-green)"
		};

		const colors ={
			"Black":"#000000",
			"Blue": "var(--neon-blue)",
			"Pink": "var(--neon-pink)",
			"Yellow": "var(--neon-yellow)",
			"Green": "var(--neon-green)",
			"White": "#FFFFFF",
		}

		return (
			<EmailFormWrapper>
				<form className="" onSubmit={this.handleSubmit}>
			 		<input
						className=""
						onChange={this.handleChange}
						type="text"
						value={this.state.email}
						placeholder="EMAIL"
					/>
					<button className="submit-button" type="submit">
						<ButtonInner
              flairColor={colors["Green"]}
              label="Sign Up"
            />
					</button>
				</form>
			</EmailFormWrapper>
		)
	}
}

const ButtonInner = ({
	label,
	flairColor,
}) => {
  return (
    <span>   
        <BorderFlair
          color={flairColor}
          corner="top-left"
        />
				{label}
        <BorderFlair
          color={flairColor}
          corner="bottom-right"
        />
      
    </span>
  );
}

const BorderFlair = ({
  color,
  corner,
}) => {
  return (
    <svg
      class={`border-flair border-flair--${corner}`}
      fill="none"
      height="38"
      viewBox="0 0 975 976"
      xmlns="http://www.w3.org/2000/svg"
      width="30"
    >
      {corner === "bottom-right" && (
        <path
          clip-rule="evenodd"
          d="M175 975L175 975.002L0 975.002L174.984 800.018L174.984 800L800 800L800 175L975 1.07671e-05L975 175L975 975L974.984 975L974.984 975L175 975Z"
          fill={color}
          fill-rule="evenodd"
        />
      )}

      {corner === "top-left" && (
        <path
          clip-rule="evenodd"
          d="M800 0.00236591L800 -5.56264e-06L975 0L800.016 174.984L800.016 175.002L175 175.002L175 800.002L-4.94084e-05 975.002L9.53993e-06 800.002L0 0.00241806L0.015625 0.00241806V0.00241041L800 0.00236591Z"
          fill={color}
          fill-rule="evenodd"
        />
      )}
    </svg>
  );
}

export default EmailSignUp;