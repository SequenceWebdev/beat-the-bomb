import React from 'react'
import styled from 'styled-components'
import { documentToReactComponents } from '@contentful/rich-text-react-renderer'
import { BLOCKS } from '@contentful/rich-text-types'
import Button from '../button'
import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import LogoCarousel from '../logo-carousel'

//images
import pink_splat_2 from '../../../assets/images/flair/pink-paint-splat-2.png';
import green_splat from '../../../assets/images/flair/green-paint-splat.png';
import blue_splat from '../../../assets/images/flair/blue-paint-splat.png';

//Accordion
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import ExpandMore from '@mui/icons-material/ExpandMore';

const SectionWrapper = styled.div`
  max-width: 1920px;
  position: relative;
  margin-left: auto;
  margin-right: auto;
  padding-left: 128px;
  padding-right: 128px;
  margin-bottom: 5rem;

  @media only screen and (max-width: 1024px){
    margin-top: 0rem;
  }

  @media only screen and (max-width: 900px){
    padding-left: 48px;
    padding-right: 48px;
  }

  @media only screen and (max-width: 500px){
    padding-left: 10px;
    padding-right: 10px;
  }

  .content {
    display: grid;
    grid-template-columns: 50% 50%;
    justify-content: space-between;
    column-gap: 3rem;
    position: relative;
    
    .content-left-col {
      width: 100%;
      position: relative;
      z-index: 3;
      display: flex;
      flex-direction: column;
      align-items: flex-start;

      @media only screen and (max-width: 1024px){
        text-align: center;
        align-items: center;
      }
    }

    .content-right-col {
      width: 100%;
      position: relative;
    }

    .header-text {
      width: 100%;
      text-align: left;
      font-style: italic;
      font-size: 80px;
      font-family: "Acumin Pro";
      font-weight: 900;
      letter-spacing: 0px;
      color: #FFFFFF;
      text-transform: uppercase;
      opacity: 1;
      @media only screen and (max-width: 1600px){
        font-size: 60px;
      }
      
      @media only screen and (max-width: 1440px){
        font-size: 48px;
      }

      @media only screen and (max-width: 1024px){
        font-size: 43px;
        text-align: center;
        margin-top: 1rem;
      }
    }

    .flair {
      * {
        position: absolute;
        z-index: 2;
      }
    }

    .pink-splat-2-right {
      top: -50%;
      right: -450px;
      width: 715px;

      @media only screen and (max-width: 500px){
        top: -70%;
        right: -400px;
        width: 515px;
      }
    }
    .pink-splat-2-left {
      top: -50%;
      left: -450px;
      width: 715px;

      @media only screen and (max-width: 500px){
        top: -70%;
        left: -400px;
        width: 515px;
      }
    }

    .blue-splat-right {
      top: -30%;
      right: -400px;
      width: 715px;

      @media only screen and (max-width: 1024px){
        top: -15%;
        right: -350px;
        width: 615px;
      }

      @media only screen and (max-width: 500px){
        top: -40%;
        right: -350px;
        width: 515px;
      }
    }

    .blue-splat-left {
      top: 200px;
      left: -400px;
      width: 715px;

      @media only screen and (max-width: 1600px){
        top:-5%;
        width: 665px;
        left: -375px
      }

      @media only screen and (max-width: 1024px){
        top: -15%;
        left: -350px;
        width: 615px;
      }

      @media only screen and (max-width: 500px){
        top: -40%;
        left: -350px;
        width: 515px;
      }
    }

    .green-splat-left {
      top: 200px;
      left: -400px;
      width: 715px;

      @media only screen and (max-width: 1600px){
        top: 50px;
        left: -400px;
        width: 615px;
      }

      @media only screen and (max-width: 1440px){
        top: -50px;
      }

      @media only screen and (max-width: 1024px){
        top: 0px;
        left: -350px;
        width: 615px;
      }

      @media only screen and (max-width: 500px){
        top: -150px;
        left: -350px;
        width: 515px;
      }
    }

    .green-splat-right {
      top: 200px;
      right: -400px;
      width: 715px;

      @media only screen and (max-width: 1024px){
        top: 0px;
        right: -350px;
        width: 615px;
      }

      @media only screen and (max-width: 500px){
        top: -150px;
        right: -350px;
        width: 515px;
      }
    }

    @media only screen and (max-width: 1024px){
      display: flex;
      flex-direction: column;
      align-items: center;
      row-gap: 1rem;

      & > div:first-child {
        order: ${({imageLocation}) => `${imageLocation}` === "Left" ? 1 : 2} !important;
      }

      & > div:last-child {
        order: ${({imageLocation}) => `${imageLocation}` === "Left" ? 2 : 1} !important;
      }
    }
  }

  .button-grid-container {
    display: grid;
    grid-template-columns: 1fr;
    grid-gap: 1rem;
    justify-items: flex-start;
    width: 100%;

    @media only screen and (max-width: 1024px){
      display: flex;
      flex-direction: column;
      align-items: center;

      & > div:first-child > div {
        margin-top: 0rem;
      }

      & > div:first-child {
        margin-top: 2rem;

        @media only screen and (max-width: 500px){
          margin-top: 1rem;
          margin-bottom: 2rem;
        }
      }

      /* & > div:last-child {
        margin-top: -5rem;
      } */
    }

    @media only screen and (max-width: 500px){
      /* & > div:last-child {
        margin-top: -3rem;
        margin-bottom: 2rem;
      } */
    }
  }

  .button-wrapper {
    position: relative;
    z-index: 3;

    & > div {
      margin-top: 0rem;
      justify-content: flex-start;
    }

    & > div > div,a {
      /* text-align: left; */
      font-family: "Pixel";
      text-transform: uppercase;
      font-size: 28px;
      letter-spacing: 0px;
      color: #00FF7B;
      opacity: 1;
      width: 100%;

      @media only screen and (max-width: 1600px){
        font-size: 18px;
      }

      @media only screen and (max-width: 1440px){
        font-size: 16px;
      }

      @media only screen and (max-width: 1024px){
        width: auto;
      }

      @media only screen and (max-width: 500px){
        font-size: 15px;
      }
    }

    & > div > div,a > span {
      padding: 15px 27px 12px 27px;

      @media only screen and (max-width: 500px){
        font-size: 15px;
      }
    }

    @media only screen and (max-width: 1024px){
      width: 100%;

      & > div {
        justify-content: center;
      }

      & > div > div,a {
        width: 100%;
        max-width: 260px;
      }
    }
  }
  
  .bp-container {
    margin-top: 2rem;
    margin-bottom: 1rem;
    display: grid;
    column-gap: 1rem;
    /* row-gap: 12px; */
    width: 120%;
    padding-left: 1rem;
    

    li {
      font-family: "Acumin Pro";
      font-style: normal;
      font-weight: 700;
      font-size: 24px;
      line-height: 90%;
      color: #ffffff;
      margin-bottom: 1rem;
      text-align: left;

      @media only screen and (max-width: 1600px){
        font-size: 20px;
      }
      
      @media only screen and (max-width: 1440px){
        font-size: 16px;
      }

      @media only screen and (max-width: 1024px){
        text-align: center;
      }
    }

    @media only screen and (max-width: 1024px){
      display: inline-block;
      text-align: left;
      width: auto;
    }

    @media only screen and (max-width: 500px){
      display: none;
    }
  }

  .bp-container--mobile {
    margin-top: 0rem;
    display: inline-block;
    text-align: left;

    li {
      text-align: left;
      font-family: "Acumin Pro";
      font-weight: 700;
      font-size: 15px;
      letter-spacing: 0px;
      color: #FFFFFF;
      opacity: 1;
    }

    @media only screen and (min-width: 501px){
      display: none;
    }  
  }

  @media only screen and (max-width: 1024px){
    margin-bottom: 2rem;
  }

  @media only screen and (max-width: 768px){
    padding: 0 1rem;
  }

  @media only screen and (max-width: 600px){
    grid-template-columns: repeat(1, 1fr);
  }
`

const AccordionWrapper = styled.div`
  width: 100%;

  .accordion_container {
    background-color: rgba(255, 255, 255, 0.1);
  }

  .accordionSummary_container{
    color: var(--neon-green);
    background-color: black;

    & > div:first-child {
      flex-grow: 0;
    }
  }

  .accordionDetails_container {
    p > p {
      font-family: "Acumin Pro";
      font-style: normal;
      font-weight: 300;
      color: #FFFFFF;
      margin-bottom: 0rem;
      text-align: left;
      font-size: 15px;
      line-height: 18px;
    }
  }

  .css-ahj2mt-MuiTypography-root {
    strong {
      font-family: "Acumin Pro";
      font-weight: 900;
      font-size: 15px;
      letter-spacing: 0px;
      opacity: 1;
    }
  }

  .css-yw020d-MuiAccordionSummary-expandIconWrapper {
    transform: rotate(-90deg);
  }

  .MuiAccordionSummary-expandIconWrapper.Mui-expanded {
    transform: rotate(0deg);
  }

  @media only screen and (min-width: 501px){
    display: none;
  }
`

const RichTextContainer = styled.div`
  width: 100%;
  margin-left: auto;
  margin-right: auto;
  margin-bottom: 2rem;

  .rich_paragraph{
    font-family: "Acumin Pro";
    font-style: normal;
    font-weight: 300;
    font-size: 33px;
    line-height: 133%;
    color: #FFFFFF !important;
    margin-bottom: 0rem;
    text-align: left;

    @media only screen and (max-width: 1600px){
      font-size: 24px;
    }
    
    @media only screen and (max-width: 1440px){
      font-size: 20px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 18px;
      text-align: center;
    }

    @media only screen and (max-width: 900px){
      font-size: 16px;
    }

    @media only screen and (max-width: 480px){
      font-size: 15px;
      line-height: 18px;
    }
  }

  @media only screen and (max-width: 500px){
    display: none;
  }  
`

const LogoCarouselDesktopWrapper = styled.div`
  margin-top: 1rem; 

  & > div {
    margin-top: 0;
    margin-bottom: 0rem;
    max-width: none;
  }

  img {
    width: auto !important;
    height: 75px !important;

    @media only screen and (max-width: 1440px){
      height: 55px !important;
    }
  }

  @media only screen and (max-width: 1024px){
    display: none;
  }
`
const LogoCarouselMobileWrapper = styled.div`
  display: inline-block;
  margin-top: -2rem;

  img {
    @media only screen and (max-width: 1024px){
      height: 45px !important;
    }

    @media only screen and (max-width: 500px){
      height: 43px !important;
    }
  }

  .slide {
    @media only screen and (max-width: 768px){
      height: 50px;
    }

    @media only screen and (max-width: 500px){
      height: 35px;
    }
  }

  @media only screen and (min-width: 1025px){
    display: none;
  }

  @media only screen and (max-width: 500px){
    margin-top: -1rem;
  }
`

const RICHTEXT_OPTIONS = {
  renderNode: {
    [BLOCKS.PARAGRAPH]: (node, children) =>{
      return children!='' && (<p className='rich_paragraph'>{children}</p>)
    },
  }
}

const EventsImageTextButton = ({ data }) => {
  const { 
    bulletPoints,
    buttons, 
    header,
    imageLocation, 
    paintSplatColor, 
    richText, 
    mediaAsset,
    eventsCarousel,
  } = data

  const json_text = JSON.parse(richText.raw);
  return (
    <SectionWrapper>
      <div className="content">
        <div style={{"order":`${imageLocation}`=== "Left" ? 2: 1 }} className="content-left-col">
          <h2 className="header-text">{header}</h2>
          {eventsCarousel &&
            <LogoCarouselMobileWrapper>
              <LogoCarousel data={eventsCarousel}/>
            </LogoCarouselMobileWrapper>
          }
          <ul className="bp-container--mobile">
              {bulletPoints.map((bp)=>{  
              return (
                <li>{bp}</li>
              )
            })}
          </ul>
          <RichTextContainer>
            {documentToReactComponents(json_text, RICHTEXT_OPTIONS)}
          </RichTextContainer>
          <AccordionWrapper>
            <Accordion
              className="accordion_container">
              <AccordionSummary
                expandIcon={<ExpandMore style={{"color": "var(--neon-green)"}}/>}
                aria-controls="panel1a-content"
                className="accordionSummary_container"
              >
                <Typography style={{"fontFamily":"Acumin Pro", "fontWeight": "900"}}>SEE FULL DESCRIPTION</Typography>
              </AccordionSummary>
              <AccordionDetails 
                className="accordionDetails_container">
                <Typography>
                  {documentToReactComponents(json_text, RICHTEXT_OPTIONS)}
                </Typography>
              </AccordionDetails>
            </Accordion>
          </AccordionWrapper>
          <div className="button-grid-container">
          {buttons.map((button, index) => {
            return (
              <div className="button-wrapper">
                <Button
                  data={{ button }}
                  glow={{
                    "Black":"#000000",
                    "Blue": "var(--neon-blue)",
                    "Pink": "var(--neon-pink)",
                    "Yellow": "var(--neon-yellow)",
                    "Green": "var(--neon-green)",
                    "White": "#FFFFFF",
                  }[button.textColor]}
                  index={index}
                  withFlair={true}
                />
              </div>
            )
          })}
          </div>
          <ul style={{"grid-template-columns": `${bulletPoints.length}` > 3 ? `${bulletPoints.length}`==="4"? "1fr": "1fr 1fr" : "1fr",
            "grid-template-rows": `${bulletPoints.length}` < 5 ? `repeat(${bulletPoints.length}, 1fr)` : "1fr 1fr 1fr"
          }} className="bp-container">
              {bulletPoints.map((bp, index)=>{
                var denominator = `${bulletPoints.length}` === "4" ? 4 : 3;
                var row_counter = (index%denominator)+1;
                var col_counter = Math.floor(index/denominator)+1;    
              return (
                <li style={{
                  "grid-column-start":`${col_counter}`,
                  "grid-column-end":`${col_counter+1}`,
                  "grid-row-start":`${row_counter}`,
                  "grid-row-end":`${row_counter+1}`,
              }}>{bp}</li>
              )
            })}
          </ul>
        </div>
        <div style={{"order":`${imageLocation}`==="Left" ? 1: 2}} className="content-right-col">
          { imageLocation === "Right" &&
            <div className="flair">
              {paintSplatColor === "Pink" &&
              <img
                alt="pink paint splat 2"
                className="pink-splat-2-right"
                src={pink_splat_2}
              />}
              {paintSplatColor === "Blue" &&
              <img
                alt="blue paint splat"
                className="blue-splat-right"
                src={blue_splat}
              />}
              {paintSplatColor === "Green" &&
              <img
                alt="green paint splat"
                className="green-splat-right"
                src={green_splat}
              />}
            </div>
          }
          { imageLocation === "Left" &&
            <div className="flair">
              {paintSplatColor === "Pink" &&
              <img
                alt="pink paint splat 2"
                className="pink-splat-2-left"
                src={pink_splat_2}
              />}
              {paintSplatColor === "Blue" &&
              <img
                alt="blue paint splat"
                className="blue-splat-left"
                src={blue_splat}
              />}
              {paintSplatColor === "Green" &&
              <img
                alt="green paint splat"
                className="green-splat-left"
                src={green_splat}
              />}
            </div>
          }
          <GatsbyImage alt={mediaAsset.title} image={getImage(mediaAsset.gatsbyImageData)}/>
        </div>
      </div>
      {eventsCarousel &&
        <LogoCarouselDesktopWrapper>
          <LogoCarousel data={eventsCarousel}/>
        </LogoCarouselDesktopWrapper>
      }
    </SectionWrapper>
  )
}

export default EventsImageTextButton