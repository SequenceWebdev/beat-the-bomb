import React from 'react'
import styled from 'styled-components'
import Slider from "react-slick";
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";

const TextSliderWrapper = styled.div`
  max-width: 1440px;
  position: relative;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 7rem;

  @media only screen and (max-width: 1024px){
    margin-top: 5rem;
  }

  @media only screen and (max-width: 768px){
    margin-top: 3rem;
  }
`

const TextContainer = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;

  .slider__container{
    width: 100%;
  }

  p{
    font-family: ${({font}) => font};
    font-style: normal;
    font-weight: 700;
    font-size: ${({fontSize}) => `${fontSize}px`};
    text-align: center;
    letter-spacing: 0.045em;
    text-transform: uppercase;
    color: #FFFFFF;
    margin: 0;

    @media only screen and (max-width: 1250px){
      font-size: 50px;
    }

    @media only screen and (max-width: 900px){
      font-size: 40px;
    }

    @media only screen and (max-width: 500px){
      font-size: 30px;
    }
  }
`

const TextSlider = ({ data }) => {
  const {firstHalfOfSentence, font, fontSize, rotatingWords, secondHalfOfSentence} = data
   const settings = {
    arrows: false,
    autoplay: true,
    dots: false,
    infinite: true,
    pauseOnFocus: false,
    pauseOnHover: false,
    slidesToScroll: 1,
    slidesToShow: 1,
    speed: 500,
    autoplaySpeed: 1750,
  };

  return (
    <TextSliderWrapper>
      <TextContainer font={font} fontSize={fontSize}>
        <p>{firstHalfOfSentence}&nbsp;</p> 
          <div className="slider__container">
            <Slider {...settings}>
              {rotatingWords.map((text, index) =>{ 
                return (
                  <p key={index}>{text}</p>    
                )
              })}
            </Slider>
          </div>
        <p>&nbsp;{secondHalfOfSentence}</p>
      </TextContainer>

    </TextSliderWrapper>
  )
}

export default TextSlider