import { graphql, useStaticQuery } from "gatsby";
import React, {useState} from 'react'
import styled from 'styled-components'
import Locations from '../locations';

import 'react-responsive-modal/styles.css';
import '../../styles/modal.css'
import { Modal } from 'react-responsive-modal';
import * as navigationStyles from "../../styles/navigation.module.css";

import {AiOutlineClose} from 'react-icons/ai'
import { GatsbyImage, getImage } from 'gatsby-plugin-image';
import { AnchorLink } from "gatsby-plugin-anchor-links";

const ButtonWrapper = styled.div`
  max-width: 1440px;
  position: relative;
  left: 50%;
  transform: translateX(-50%);

  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  margin-top: 5rem;

  span:hover{
    background-color: ${({textColor}) => `${textColor}`};
    color: ${({buttonColor}) => `${buttonColor}`};
    border-color:  ${({textColor}) => `${textColor}`};
  }

  span{
    display: block;
    background-color: ${({buttonColor}) => `${buttonColor}`};
    color: ${({textColor}) => `${textColor}`};
    border-color: ${({borderColor}) => `${borderColor}`};
    /* width: 27%; */
    /* width: 100%; */
    border: solid;
    padding: 0.5rem;
    position: relative;
    /* min-width: 391px; */
    min-width: auto;

    /* @media only screen and (max-width: 900px){
      width: 100%;
      min-width: 325px;
      max-width: 325px;
    }

    @media only screen and (max-width: 768px){
      min-width: 300px;
      max-width: 300px;
    } */

    @media only screen and (max-width: 500px){
      /* min-width: 240px; */
      font-size: 24px;
      padding: 0.5rem 1rem;
      /* max-width: 240px; */
    }

    @media only screen and (max-width: 375px){
      /* min-width: 240px; */
      font-size: 18px;
      /* max-width: 240px; */
    }
  }

  button{
    padding: 0;
    margin: 0;
    border: none;
  }

  a, button, .pop_up_button, .xola-custom{
    font-family: 'Pixel';
    font-style: normal;
    font-weight: 400;
    font-size: 48px;
    line-height: 117%;
    text-align: center;
    /* width: 27%;
    min-width: 391px; */

    @media only screen and (max-width: 1250px){
      font-size: 40px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 35px;

    }

    @media only screen and (max-width: 900px){
      /* width: 100%; */
      font-size: 30px;
      /* min-width: 325px;
      max-width: 325px; */
    }

    @media only screen and (max-width: 768px){
      /* min-width: 300px;
      max-width: 300px; */

      font-size: 24px;
    }

    @media only screen and (max-width: 500px){
      /* min-width: 240px; */
      font-size: 18px;
      /* max-width: 240px; */
    }
  }

  @media only screen and (max-width: 500px){
    margin-top: 3rem;
  }

  .border-flair {
    pointer-events: none;
    position: absolute;
  }

  .border-flair--bottom-right {
    bottom: 0;
    right: 0;
  }

  .border-flair--top-left {
    left: 0;
    top: 0;
  }
`

const Button = (pageContext) => {
  const { data, withFlair } = pageContext;
  const { borderColor, buttonColor, buttonText, textColor, type, buttonLink, locations } = data.button
  const colors ={
    "Black":"#000000",
    "Blue": "var(--neon-blue)",
    "Pink": "var(--neon-pink)",
    "Yellow": "var(--neon-yellow)",
    "Green": "var(--neon-green)",
    "White": "#FFFFFF",
    "Purple": "var(--neon-purple)",
  }
  // console.log(colors[borderColor]);

  const [open, setOpen] = useState(false);

  const onOpenModal = () => setOpen(true);
  const onCloseModal = () => setOpen(false);

  const closeIcon = (<AiOutlineClose className="close_icon" color='white'/>);
  const { allContentfulAsset } = useStaticQuery(graphql`
    query {
      allContentfulAsset(filter: {title: {regex: "/^ATL Menu/"}}) {
        nodes {
          gatsbyImageData
        }
      }
    }
  `);
  const menuAssets = allContentfulAsset.nodes;

  return (
    <ButtonWrapper borderColor={colors[borderColor]} buttonColor={colors[buttonColor]} textColor={colors[textColor]}>
      {type.toLowerCase()==='xola' &&
        <div 
          className="xola-checkout xola-custom"
          data-button-id={buttonLink}
        >
          <ButtonInner
            flairColor={colors[borderColor]}
            label={buttonText}
            withFlair={withFlair}
            className={[navigationStyles.bookNowButtonMobile, navigationStyles.bookNowButtonMobileAtlanta].join(" ")}
          />
        </div>
      }
      
      {type.toLowerCase()==='hyperlink' &&
        <a href={`${buttonLink}`}>
          <ButtonInner
            flairColor={colors[borderColor]}
            label={buttonText}
            withFlair={withFlair}
          />
        </a>
      }

      {type.toLowerCase()==='link' &&
        <AnchorLink to={`/${buttonLink}`} stripHash={true}>
          <ButtonInner
            flairColor={colors[borderColor]}
            label={buttonText}
            withFlair={withFlair}
          />
        </AnchorLink>
      }

      {(type.toLowerCase()==='tripleseat' && pageContext.path === '/atlanta') &&
        <a target="_blank" rel="noreferrer" href="https://beatthebomb.tripleseat.com/party_request/25975">
          <ButtonInner
            flairColor={colors[borderColor]}
            label={buttonText}
            withFlair={withFlair}
          />
        </a>
      }

      {(type.toLowerCase()==='tripleseat' && pageContext.path === '/brooklyn') &&
        <a target="_blank" rel="noreferrer" href="https://beatthebomb.tripleseat.com/party_request/25974">
          <ButtonInner
            flairColor={colors[borderColor]}
            label={buttonText}
            withFlair={withFlair}
          />
        </a>
      }

      {(type.toLowerCase()==='tripleseat' && pageContext.path === '/dc') &&
        <a target="_blank" rel="noreferrer" href="https://beatthebomb.tripleseat.com/party_request/27864">
          <ButtonInner
            flairColor={colors[borderColor]}
            label={buttonText}
            withFlair={withFlair}
          />
        </a>
      }

      {type.toLowerCase().includes('pop-up') &&
        <>
          <button
            class='pop_up_button'
            onClick={(e)=>{
              e.preventDefault()
              onOpenModal()
            }}
          >
            <ButtonInner
              flairColor={colors[borderColor]}
              label={buttonText}
              withFlair={withFlair}
            />
          </button>

          <Modal
            open={open}
            onClose={onCloseModal}
            center
            showCloseIcon
            classNames={{
              overlay: 'customOverlay',
              modal: 'customModal',
            }}
            closeIcon={closeIcon}
          >
            {type.toLowerCase()==='pop-up-locations' && <div className="locations_modal">
              <Locations data={locations}/>
            </div>}

            {type.toLowerCase()==='pop-up-menu' && <div className="menu_modal">
              {/* <h2>Something delicious coming soon...</h2> */}
              <div className="food_menu__container">
                <GatsbyImage className="menu_img" alt='menu_1' image={getImage(menuAssets[0].gatsbyImageData)}/>
              </div>
              <div className="drink_menu__container">
                <GatsbyImage className="menu_img" alt='menu_2' image={getImage(menuAssets[1].gatsbyImageData)}/>
              </div>
            </div>}
          </Modal>
        </>
      }
    </ButtonWrapper>
  )
}

const ButtonInner = ({
  flairColor,
  label,
  withFlair,
}) => {
  return (
    <span>
      {withFlair === true && (
        <BorderFlair
          color={flairColor}
          corner="top-left"
        />
      )}

      {label}

      {withFlair === true && (
        <BorderFlair
          color={flairColor}
          corner="bottom-right"
        />
      )}
    </span>
  );
}

const BorderFlair = ({
  color,
  corner,
}) => {
  return (
    <svg
      class={`border-flair border-flair--${corner}`}
      fill="none"
      height="35"
      viewBox="0 0 975 976"
      xmlns="http://www.w3.org/2000/svg"
      width="35"
    >
      {corner === "bottom-right" && (
        <path
          clip-rule="evenodd"
          d="M175 975L175 975.002L0 975.002L174.984 800.018L174.984 800L800 800L800 175L975 1.07671e-05L975 175L975 975L974.984 975L974.984 975L175 975Z"
          fill={color}
          fill-rule="evenodd"
        />
      )}

      {corner === "top-left" && (
        <path
          clip-rule="evenodd"
          d="M800 0.00236591L800 -5.56264e-06L975 0L800.016 174.984L800.016 175.002L175 175.002L175 800.002L-4.94084e-05 975.002L9.53993e-06 800.002L0 0.00241806L0.015625 0.00241806V0.00241041L800 0.00236591Z"
          fill={color}
          fill-rule="evenodd"
        />
      )}
    </svg>
  );
}

export default Button
