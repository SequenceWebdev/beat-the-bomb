import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from 'styled-components'

const TicketWrapper = styled.div`
  max-width: 1440px;
  position: relative;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 2rem;
`

const TicketCardWrapper = styled.div`
  max-width:1286px;
  max-height: 571px;
  width: 100%;
  display: grid;
  grid-template-columns: 1fr 1fr;
  align-items: center;
  position: relative;

  @media only screen and (max-width: 500px){
    grid-template-columns: 1fr;
    max-height: none;
  }

  .left_column{
    position: relative;
  }

  .ticket_image{
    /* padding: 1rem 0 4rem 0; */
    width: 100%;
    position: relative;
    z-index: -1;
  }

  .image_text__container{
    position: absolute;
    top:0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .image_text__container p{
    font-family: 'Acumin Pro';
    font-style: normal;
    font-weight: 750;
    font-size: 48px;
    line-height: 121%;
    display: flex;
    align-items: center;
    text-align: center;
    letter-spacing: 0;
    text-transform: uppercase;
    color: #FFFFFF;

    @media only screen and (max-width: 768px){
      font-size: 30px
    }
  }

  .right_column{
    display: flex;
    flex-direction: column;
    align-items: center;
    height: 100%;
    justify-content: space-evenly;
    position: relative;
    z-index: 5;
  }
`

const TextContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 0 20px;
  margin-left: auto;
  margin-right: auto;
  max-width: 425px;

  .detail_text{
    font-family: 'Acumin Pro';
    font-style: normal;
    font-weight: 400;
    font-size: 24px;
    line-height: 125%;
    text-align: center;
    color: #FFFFFF;
    /* padding: 0 5rem; */

    @media only screen and (max-width: 768px){
      font-size: 16px;
    }

    @media only screen and (max-width: 500px){
      margin-top: 1rem;
    }
  }

  .pricing_text, .session_text{
    font-family: 'Acumin Pro';
    font-style: normal;
    font-weight: 700;
    font-size: 32px;
    line-height: 110%;
    text-align: center;
    color: #FFFFFF;

    @media only screen and (max-width: 768px){
      font-size: 24px;
    }
  }

  .occupancy_limit_text, .request_text{
    font-family: 'Acumin Pro';
    font-style: normal;
    font-weight: 700;
    font-size: 20px;
    line-height: 65%;
    text-align: center;
    color: #FFFFFF;

    @media only screen and (max-width: 768px){
      font-size: 15px;
      line-height: 18px;
    }
  }

  .request_text{
    font-weight: 400;
  }

  .request_text a{
    color: var(--neon-blue);
    text-decoration: underline;
  }

  .request_text a:hover{
    color: #FFFFFF;
  }
`

const ButtonContainer = styled.div`
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;

  a {
    font-family: 'Pixel';
    font-style: normal;
    font-weight: 400;
    font-size: 40px;
    line-height: 117%;
    text-align: center;

    @media only screen and (max-width: 1024px){
      font-size: 35px;
    }

    @media only screen and (max-width: 900px){
      font-size: 30px;
    }

    @media only screen and (max-width: 768px){
      font-size: 25px;
    }

    @media only screen and (max-width: 500px){
      font-size: 22px;
    }
  }

  button{
    /* background-color: var(${({buttonColor}) => `--neon-${buttonColor.toLowerCase()}`});
    color: ${({textColor}) => `${textColor.toLowerCase()}`};
    border-color: var(${({borderColor}) => `--neon-${borderColor.toLowerCase()}`});
    font-family: 'Pixel';
    font-style: normal;
    font-weight: 400;
    font-size: 40px;
    line-height: 47px;
    text-align: center;
    width: 62%; */

    background-color: ${({buttonColor}) => `${buttonColor}`};
    color: ${({textColor}) => `${textColor}`};
    border-color: ${({borderColor}) => `${borderColor}`};
    width: 62%;
    min-width: 391px;

    @media only screen and (max-width: 900px){
      width: 100%;
      min-width: 325px;
      max-width: 325px;
    }

    @media only screen and (max-width: 768px){
      min-width: 225px;
      max-width: 225px;
      margin-bottom: 1rem;
    }

    @media only screen and (max-width: 500px){
      min-width: 250px;
      max-width: 250px;
    }
  }

  button:hover{
    background-color: ${({textColor}) => `${textColor}`};
    color: ${({buttonColor}) => `${buttonColor}`};
    border-color: ${({buttonColor}) => `${buttonColor}`};
  }
`

const Overlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 0;
  background-image: linear-gradient(to bottom, transparent, var(${({overlayGradientColor}) => `--neon-${overlayGradientColor.toLowerCase()}`}));
  opacity: 0.5;
`

const Ticket = (pageContext) => {
  const data = pageContext.data
  const { button, details, image, session, maxPeople, minimumPeople, overlayGradientColor, pricing } = data
  const { borderColor, buttonColor, buttonText, textColor, buttonLink } = button

  const colors ={
    "Black":"#000000",
    "Blue": "var(--neon-blue)",
    "Pink": "var(--neon-pink)",
    "Yellow": "var(--neon-yellow)",
    "Green": "var(--neon-green)",
    "White": "#FFFFFF",
    "Purple": "var(--neon-purple)"
  }
  return (
    <TicketWrapper>
      <TicketCardWrapper>
        <Overlay overlayGradientColor={overlayGradientColor}/>
        <div className="left_column">
          <GatsbyImage alt={image.title} className="ticket_image" image={getImage(image.gatsbyImageData)} />
        </div>

        <div className="right_column">
          <TextContainer>
            <p className='detail_text'>{details}</p>
            <p className='pricing_text'>{pricing}</p>
            <p className='session_text'>{session}</p>
            <p className='occupancy_limit_text'>minimum {minimumPeople} | maximum {maxPeople}</p>
            <p className='request_text'>larger groups on&nbsp; 
            {(pageContext.path === '/atlanta') && <a target="_blank" rel="noreferrer" href="https://beatthebomb.tripleseat.com/party_request/25975">request</a> 
            }
            {
              (pageContext.path === '/brooklyn') &&
              <a target="_blank" rel="noreferrer" href="https://beatthebomb.tripleseat.com/party_request/25974">request</a>
            }
            {
              (pageContext.path === '/dc') &&
              <a target="_blank" rel="noreferrer" href="https://beatthebomb.tripleseat.com/party_request/27864">request</a>
            }
            </p>
          </TextContainer>
          <ButtonContainer borderColor={colors[borderColor]} buttonColor={colors[buttonColor]} textColor={colors[textColor]}>
            <a href={`${buttonLink}`}><button>{buttonText}</button></a>
          </ButtonContainer>
        </div>
      </TicketCardWrapper>
    </TicketWrapper>
  )
}

export default Ticket