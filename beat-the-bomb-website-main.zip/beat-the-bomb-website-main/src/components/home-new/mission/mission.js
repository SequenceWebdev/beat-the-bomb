import React from 'react'
import styled from 'styled-components'
import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import Button from '../button'
import { documentToReactComponents } from '@contentful/rich-text-react-renderer'
import { BLOCKS, MARKS } from '@contentful/rich-text-types'

const MissionWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;

  @media only screen and (max-width: 768px){
    margin-top: 7rem;
  }

  @media only screen and (max-width: 500px){
    margin-top: 5rem;
  }

  @media only screen and (max-width: 320px){
    margin-top: 3rem;
  }
`

const MissionCard = styled.div`
  max-width: 800px;
  height:1000px;
  width: 100%;
  border: 2px solid #ffffff;
  align-items: center;
  /* display: grid;
  grid-template-columns: repeat(1, 1fr); */
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
  padding: 1.5rem;
  position: relative;
  padding-top:5rem;

  @media only screen and (min-width: 1025px) and (max-width: 1250px){
    padding-top:3rem;
    height: 825px;
  }

  @media only screen and (min-width: 769px) and (max-width: 1024px){
    padding-top:3rem;
    height: 700px;
    padding-bottom: 0;
  }

  @media only screen and (max-width: 768px){
    height: auto;
    padding-top: 6rem;
  }

  @media only screen and (max-width: 600px){
    padding-top: 5rem;
  }

  @media only screen and (max-width: 500px){
    padding: 1rem;
    padding-top: 4rem;
  }

  @media only screen and (max-width: 425px){
    padding-top: 3rem;
  }

  div{
    margin-top:0;
  }

  .card_frame{
    position: absolute;
    top:0;
    left:0;
    width: 74%;
    transform: translate(-0.5%,-50%);

    @media only screen and (max-width: 768px){
      transform: translate(-0.8%,-50%);
    }

    @media only screen and (max-width: 500px){
      transform: translate(-0.9%,-50%);
    }

    @media only screen and (max-width: 425px){
      transform: translate(-1%,-50%);
    }

    @media only screen and (max-width: 375px){
      transform: translate(-1.4%,-50%);
    }
  }

  .video__container{
    margin-top: 1rem;
    margin-bottom: 1rem;
    width: 100%;

    @media only screen and (max-width: 768px){
      margin-top: 2rem;
      margin-bottom: 2rem;
    }
  }

  .video__container video{
    width: 100%;
    /* max-height: 282px;

    @media only screen and (max-width: 1250px){
      max-height: 220px;
    }

    @media only screen and (max-width: 768px){
      max-height: none;
    } */
  }

  .description__container{
    width: 100%;
    padding: 0 2rem;
    margin-left: auto;
    margin-right: auto;
    min-height: 130px;

    @media only screen and (max-width: 1250px){
      padding-top: 2rem;
      min-height: 155px;
    }

    @media only screen and (min-width: 769px) and (max-width: 1024px){
      min-height: 105px;
      padding: 0 0.5rem;
      padding-top: 1rem;
    }

    @media only screen and (max-width: 768px){
      width: 100%;
      min-height: auto;
      padding: 0;
    }
  }

  .colored_text{
    font-family: 'Pixel';
    font-style: normal;
    color: ${({color}) => `${color}`};
  }

  .description__container p{
    font-family: 'Acumin Pro';
    font-style: normal;
    font-weight: 400;
    font-size: 25px;
    line-height: 125%;
    color: #ffffff;
    margin: 0;
    
    @media only screen and (min-width: 1601px){
      padding-top: 1rem;
    }

    @media only screen and (min-width: 1025px) and (max-width: 1250px){
      font-size: 22px;
    }

    @media only screen and (min-width: 769px) and (max-width: 1024px){
      font-size: 18px;
    }

    @media only screen and (max-width: 768px){
      font-size: 25px;
      text-align: center;
    }

    @media only screen and (max-width: 500px){
      font-size: 18px;
    }
  }
`

const RICHTEXT_OPTIONS = {
  renderMark: {
    [MARKS.BOLD]: text => <strong className='colored_text'>{text}</strong>,
  },
  renderNode: {
    [BLOCKS.PARAGRAPH]: (node, children) =>{
      return children!='' && (<p>{children}</p>)
    },
  }
}


const Mission = ({ card }) => {
  const { cardImage, gamesImage, missionDescription, video, paintWordColor } = card
  const json_text = JSON.parse(missionDescription.raw)
  
  const colors ={
    "Black":"#000000",
    "Blue": "var(--neon-blue)",
    "Pink": "var(--neon-pink)",
    "Yellow": "var(--neon-yellow)",
    "Green": "var(--neon-green)",
    "White": "#FFFFFF",
  }

  return (
    <MissionWrapper>
      <MissionCard color={colors[paintWordColor]}>
        <GatsbyImage alt={cardImage.title} className="card_frame" image={getImage(cardImage.gatsbyImageData)}/>
        <div className="description__container">
          {documentToReactComponents(json_text, RICHTEXT_OPTIONS)}
          {/* <p>{missionDescription.missionDescription}</p> */}
        </div>
        {video && <div className="video__container">
          <video autoPlay playsInline loop muted>
            <source src={video.url} type="video/mp4" />
          </video> 
        </div>}
        <GatsbyImage alt={gamesImage.title} image={getImage(gamesImage.gatsbyImageData)}/>
        <Button data={card}/>
      </MissionCard>
      {/* <Button data={card}/> */}
    </MissionWrapper>

  )
}

export default Mission