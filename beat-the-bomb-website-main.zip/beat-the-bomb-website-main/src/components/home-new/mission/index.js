import React from 'react'
import styled from 'styled-components'
import Mission from './mission'

import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import Button from '../button'
import { documentToReactComponents } from '@contentful/rich-text-react-renderer'
import { BLOCKS, MARKS } from '@contentful/rich-text-types'
import ReactMarkdown from "react-markdown";
import rehypeRaw from 'rehype-raw'

const MissionOuterWrapper = styled.div`
  max-width: 1920px;
  /* position: relative; */
  display: flex;
  align-items: center;
  justify-content: center;
  margin-left: auto;
  margin-right: auto;
  /* left: 50%;
  transform: translateX(-50%); */
  margin-top: 6rem;
  /* padding: 0 3rem; */
  padding-left: 128px;
  padding-right: 128px;

  @media only screen and (max-width: 900px){
    margin-top: 2rem;
    padding-left: 20px;
    padding-right: 20px;
  }

  @media only screen and (max-width: 768px){
    margin-top: 1rem;
  }

  @media only screen and (max-width: 500px){
    padding: 0 1rem;
  }
`

const MissionsContainer = styled.div`
  display:grid;
  grid-template-columns: repeat(2, 1fr);
  align-items: center;
  column-gap: 3rem;

  @media only screen and (max-width: 768px){
    grid-template-columns: repeat(1, 1fr);
  }
`

const MissionContainer = styled.div`
  display:flex;
  align-items: center;
  justify-content: center;

`

const SingleMissionWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;

  @media only screen and (max-width: 768px){
    margin-top: 7rem;
  }

  @media only screen and (max-width: 500px){
    margin-top: 5rem;
  }

  @media only screen and (max-width: 320px){
    margin-top: 3rem;
  }
`

const SingleMissionCard = styled.div`
  max-width: 800px;
  width: 100%;
  border: 2px solid #ffffff;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-evenly;
  padding: 3rem;
  position: relative;
  padding-top:6rem;

  @media only screen and (max-width: 768px){
    padding-top: 4rem;
  }

  @media only screen and (max-width: 500px){
    padding: 1.5rem;
    padding-top: 3rem;
  }

  div{
    margin-top:0;
  }

  .card_frame{
    position: absolute;
    top:0;
    left:0;
    width: 74%;
    transform: translate(-0.5%,-50%);

    @media only screen and (max-width: 768px){
      transform: translate(-0.8%,-50%);
    }

    @media only screen and (max-width: 500px){
      transform: translate(-0.9%,-50%);
    }

    @media only screen and (max-width: 425px){
      transform: translate(-1%,-50%);
    }

    @media only screen and (max-width: 375px){
      transform: translate(-1.4%,-50%);
    }
  }

  .video__container{
    margin-top: 2rem;
    margin-bottom: 2rem;
    width: 100%;
  }

  .video__container video{
    width: 100%;
  }

  .description__container{
    width: 90%;

    @media only screen and (max-width: 768px){
      width: 100%;
    }
  }

  .colored_text{
    font-family: 'Pixel';
    font-style: normal;
    color: ${({color}) => `${color}`};
  }

  .description__container p{
    font-family: 'Acumin Pro';
    font-style: normal;
    font-weight: 400;
    font-size: 30px;
    line-height: 125%;
    color: #ffffff;
    margin: 0;

    @media only screen and (min-width: 1025px) and (max-width: 1250px){
      font-size: 24px;
    }

    @media only screen and (min-width: 769px) and (max-width: 1024px){
      font-size: 22px;
    }

    @media only screen and (max-width: 768px){
      font-size: 25px;
      text-align: center;
    }

    @media only screen and (max-width: 500px){
      font-size: 18px;
    }
  }
`

const RICHTEXT_OPTIONS = {
  renderMark: {
    [MARKS.BOLD]: text => <strong className='colored_text'>{text}</strong>,
  },
  renderNode: {
    [BLOCKS.PARAGRAPH]: (node, children) =>{
      return children!='' && (<p>{children}</p>)
    },
  }
}

const ExperiencesWrapper = styled.div`
  width: 100%;
  display: grid;
  grid-template-columns: 50% 50%;
  place-items: flex-start;
  column-gap: 3rem;

  & > div:first-child {
    /* border-right: 2px solid #FFFFFF;
    padding-right: 3rem; */

    @media only screen and (max-width: 1024px){
      border-right: none;
      padding-right: 0;
    }
  }

  & > div:last-child > .gif-container {
    @media only screen and (max-width: 1024px){
      margin-bottom: -1rem;
    }
  }

  .description-card {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;

    @media only screen and (max-width: 1024px){
      align-items: center;
    }
  }

  .gif-container {
    width: 100%;
    margin-bottom: 1rem;
    display: flex;
    justify-content: center;
    align-items: center;

    & video{
      width: 100%;
      max-width: 542px;
      height: 100%;
      max-height: 542px;
      margin-left: auto;
      margin-right: auto;

      /* @media only screen and (max-width: 900px){
        width: 100%;
        max-width: 233px;
        height: 100%;
        object-fit: cover;
      }

      @media only screen and (max-width: 600px){
        object-fit: contain;
      } */
    }
  }

  .text-container {
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: flex-start;

    h2 {
      text-align: left;
      font-family: "Acumin Pro";
      font-style: italic;
      font-weight: 900;
      font-size: 40px;
      line-height: 56px;
      letter-spacing: 0px;
      color: #FFFFFF;
      opacity: 1;
      text-transform: uppercase;
      flex-grow: 1;
      flex-basis: 121px;

      @media only screen and (max-width: 1440px){
        font-size: 32px;
      }

      @media only screen and (max-width: 1024px){
        font-size: 25px;
        text-align: center;
        flex-basis: auto;
      }

      @media only screen and (max-width: 900px){
        font-size: 18px;
      }
    }

    p {
      text-align: left;
      font-family: "Acumin Pro";
      font-weight: 300;
      font-size: 23px;
      line-height: 33px;
      font-style: normal;
      letter-spacing: 0px;
      color: #FFFFFF;

      strong {
        text-align: left;
        font-family: "Acumin Pro";
        font-weight: 900;
        font-size: 23px;
        line-height: 33px;
        font-style: italic;
        letter-spacing: 0px;
        color: #FFFFFF;

        @media only screen and (max-width: 1440px){
          font-size: 20px;
        }

        @media only screen and (max-width: 1024px){
          font-size: 18px;
        }

        @media only screen and (max-width: 900px){
          font-size: 16px;
        }

        @media only screen and (max-width: 480px){
          font-size: 15px;
          line-height: 18px;
        }       
      }

      @media only screen and (max-width: 1440px){
        font-size: 20px;
      }

      @media only screen and (max-width: 1024px){
        font-size: 18px;
        text-align: center;
      }

      @media only screen and (max-width: 900px){
        font-size: 16px;
      }

      @media only screen and (max-width: 480px){
        font-size: 15px;
        line-height: 18px;
      }
    }

    @media only screen and (max-width: 1024px){
      align-items: center;
    }
  }

  @media only screen and (max-width: 1024px){
    grid-template-columns: 1fr;
    column-gap: 0;
    row-gap: 2rem;
    place-items: center;
  }
`

const Missions = ({ data }) => {
  const { mission, missionDescriptionCard } = data
  
  const colors ={
    "Black":"#000000",
    "Blue": "var(--neon-blue)",
    "Pink": "var(--neon-pink)",
    "Yellow": "var(--neon-yellow)",
    "Green": "var(--neon-green)",
    "White": "#FFFFFF",
  }

  return (
    <MissionOuterWrapper>
      {mission?.length>1 && <MissionsContainer>
        {mission.map((card, index)=>{
          return(<Mission index={index} card={card}/>)
        })}
      </MissionsContainer>}
      {mission?.length===1 && 
      <MissionContainer>
        <SingleMissionWrapper>
          <SingleMissionCard color={colors[mission[0].paintWordColor]}>          
            <GatsbyImage alt={mission[0].cardImage.title} className="card_frame" image={getImage(mission[0].cardImage.gatsbyImageData)}/>
            <div className="description__container">
              {documentToReactComponents(JSON.parse(mission[0].missionDescription.raw), RICHTEXT_OPTIONS)}
            </div>
            {mission[0].video && <div className="video__container">
              <video autoPlay playsInline loop muted>
                <source src={mission[0].video.url} type="video/mp4" />
              </video> 
            </div>}
            <GatsbyImage alt={mission[0].gamesImage.title} image={getImage(mission[0].gamesImage.gatsbyImageData)}/>
            <Button data={mission[0]}/>
          </SingleMissionCard>
        </SingleMissionWrapper>  
      </MissionContainer>}
      {missionDescriptionCard &&
      <>
      
      <ExperiencesWrapper>
        {missionDescriptionCard.map((card, index)=>{
          return (
            <div className="description-card">
              <div className="gif-container">
                <video alt={missionDescriptionCard[index].gameMissionImageAssets[0].title} autoPlay playsInline loop muted>
                  <source src={missionDescriptionCard[index].gameMissionImageAssets[0].url} type="video/mp4" />
                </video> 
              </div>
              <div className="text-container">
                <ReactMarkdown rehypePlugins={[rehypeRaw]} children={missionDescriptionCard[index].gameDescription.gameDescription} />
              </div>
            </div>
          )
        })}
        
      </ExperiencesWrapper>
        
      </>}
    </MissionOuterWrapper>
  )
}

export default Missions