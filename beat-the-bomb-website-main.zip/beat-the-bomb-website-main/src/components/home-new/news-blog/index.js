import React, { useState, useRef } from "react";
import styled from "styled-components";
import BlogCardModal from "../blog-card-modal";

// image/gif
import nb_gif from "../../../assets/images/newsBlog/news-blast.gif";
import bg_image from "../../../assets/images/newsBlog/black-grid.png";

const NewsBlogWrapper = styled.div`
  position: relative;

  .flairs {
      * {
        pointer-events: none;
        position: absolute;
        z-index: -1;
      }

      .bg {
        top: -10%;
        left: -35%;
        width: 100%;
        transform: rotate(-25deg);
        z-index: -1;

        @media only screen and (max-width: 1600px){
          top: 0;
          left: -450px;
        }

        @media only screen and (max-width: 1440px){
          left: -300px;
        }

        @media only screen and (max-width: 1024px){
          top: 0;
          left: -325px;
          width: 1000px;
          transform: rotate(-10deg);
        }

        @media only screen and (max-width: 768px){
          left: -275px;
          width: 800px;
          transform: rotate(-15deg);
        }

        @media only screen and (max-width: 500px){
          left: -200px;
          top:0;
          width: 600px;
        }
      }
  }

  .border-flair {
    pointer-events: none;
    position: absolute;
  }

  .border-flair--bottom-right {
    bottom: 0;
    right: 0;
  }

  .border-flair--top-left {
    left: 0;
    top: 0;
  }
 
  .App {
    text-align: center;
    width: 100%;
    max-width: 1920px;
    margin-left: auto;
    margin-right: auto;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0 128px;
    position: relative;

    @media only screen and (max-width: 900px){
      padding-left: 48px;
      padding-right: 48px;
    }

    @media only screen and (max-width: 500px){
      padding-left: 10px;
      padding-right: 10px;
    }
  }

  .container {
    width: 100%;
    max-width: 1920px;
    margin: 0 auto;
    padding: 0 128px;
    /* display: flex;
    align-items: center;
    justify-content: center; */
    position: relative;
    margin-top: 5.5rem;
    margin-bottom: 5.5rem;

    @media only screen and (max-width: 900px){
      padding-left: 48px;
      padding-right: 48px;
      margin-top: 2.5rem;
      margin-bottom: 2.5rem;
    }

    @media only screen and (max-width: 500px){
      padding-left: 10px;
      padding-right: 10px;
      margin-bottom: 0;
    }
  }

  .newsBlog_banner {
    width: 100%;
    margin-bottom: 0rem;
    max-width: 1135px;
    background: #000000;

    img {
      width: 100%;
      
      object-fit: contain;
    }
  }

  .horizontal-slider{
    /* padding-left: 10rem; */
    list-style: none;
    /* max-width: 100%; */
    width: 100%;
    scroll-behavior: smooth;
    display: flex;
    flex-wrap: nowrap;
    padding-left: 0;
    overflow: auto;

    &::-webkit-scrollbar {
      background: transparent; 
      -webkit-appearance: none;
      width: 0;
      height: 0;
    }
    li{
      margin: 0 200px 0 0;
      /* white-space: nowrap; */
      flex: none;
      width: 500px;

      @media only screen and (max-width: 1600px){
        margin: 0 50px 0 0;
      }

      @media only screen and (max-width: 1536px){
        width: 472px;
      }

      @media only screen and (max-width: 1366px){
        width: 425px;
      }

      @media only screen and (max-width: 1280px){
        width: 400px;
      }

      @media only screen and (max-width: 1024px){
        width: 252px;
      }

     @media only screen and (max-width: 900px){
        margin-right: 75px;
      }

      @media only screen and (max-width: 500px){
        width: 225px;
      }

      @media only screen and (max-width: 375px){
        margin-right: 25px;
      }

    }

    @media only screen and (max-width: 1024px){
      padding-left: 0rem;
    }
  }

  .next, .prev {
    background: transparent;
    border: none;
  }
`

const NewsBlog = ({data}) => {
  return (
    <NewsBlogWrapper>
      <div className="flairs">
        <img src={bg_image} alt="bg image" className="bg"/>
      </div>
      <div className="container">
        <div className="newsBlog_banner">
          <img src={nb_gif} alt="news blog gif"/>
        </div>
      </div>

    <div className="App">
      <ul className="horizontal-slider">
        {data.newsBlogs.map((blog)=>{
            return (
              <BlogCardModal blog={blog}/>
            )
          })}
      </ul>
    </div>
    </NewsBlogWrapper>
  );
}

export default NewsBlog;