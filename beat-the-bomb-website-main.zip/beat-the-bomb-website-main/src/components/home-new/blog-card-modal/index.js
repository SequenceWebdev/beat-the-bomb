import React, {useState} from 'react';
import styled from "styled-components";
import Modal from '../modal';

const BlogCard = styled.li`
  width: 100%;
  max-width: 628px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  
  cursor: pointer;

  .image-container {
    width: 100%;
    position: relative;
    margin-bottom: 2rem;
    flex-grow: 1;

    img {
      object-fit: contain;
      width: 100%;
      height: 100%;
    }

    &::after {
    background: linear-gradient( to bottom,
    rgba(0, 0, 0, 0) 90%,
    rgba(0, 0, 0, 1) 100%);
      bottom: 0;
      content: "";
      display: block;
      height: 100%;
      left: 0;
      position: absolute;
      right: 0;
    }

    @media only screen and (max-width: 500px){
      margin-bottom: 1rem;
    }
  }

  .text-container {
    width:100%;
    
    display: flex;
    flex-direction: column;
  }

  .date {
    text-align: left;
    font-family: "Acumin Pro";
    font-weight: 600;
    font-style: normal;
    font-size: 20px;
    line-height: 140%;
    letter-spacing: 0px;
    flex-grow: 2;
    color: var(--neon-blue);

    span {
      color: #FFFFFF;
    }

    @media only screen and (max-width: 1366px){
      font-size: 18px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 15px;
    }

    @media only screen and (max-width: 500px){
      margin-bottom: 0.5rem;
    }
  }

  .event-title {
    text-align: left;
    font-style: italic;
    font-weight: 900;
    font-size: 20px;
    text-transform: uppercase;
    line-height: 157%;
    font-family: "Acumin Pro";
    letter-spacing: 2.8px;
    color: #FFFFFF;
    opacity: 1;
    flex-grow: 2;
    

    @media only screen and (max-width: 1440px){
      letter-spacing: 2px;
    }
    @media only screen and (max-width: 1366px){
      font-size: 18px;
    }
    @media only screen and (max-width: 1280px){
      letter-spacing: 2px;
    }

    @media only screen and (max-width: 768px){
      
    }

    @media only screen and (max-width: 500px){
      font-size: 16px;
      line-height: 115%;
    }
  }

  .event-description {
    text-align: left;
    font-weight: 300;
    font-style: normal;
    font-size: 16px;
    line-height: 144%;
    font-family: "Acumin Pro";
    letter-spacing: 0px;
    color: #FFFFFF;
    opacity: 1;
    flex-grow: 2;
    

    @media only screen and (max-width: 1366px){
      font-size: 15px;
      line-height: 18px;
    }
  }

`

const BlogCardModal = ({blog}) => {

  const [openModal, setOpenModal] = useState(false);

  return (
    <>
    <BlogCard 
    onClick={()=>{
      setOpenModal(!openModal);
    }}>
      <div className="image-container">
        <BorderFlair
          color={"var(--neon-green)"}
          corner="top-left"
        />
        <img src={blog.image.url} alt={blog.image.title}/>
      </div>
      {/* <div className="text-container"> */}
        {blog.dateExtraText && blog.date &&
        <p className="date"><span>{blog.date} |</span> {blog.dateExtraText}</p>
        }
        {blog.dateExtraText && !blog.date &&
        <p className="date">{blog.dateExtraText}</p>}
        <h6 className="event-title">{blog.title}</h6>
        <p className="event-description">{blog.description.description}</p>
      {/* </div> */}
    </BlogCard>
    <Modal data={blog} onClose={()=>setOpenModal(false)} open={openModal}/>
    </>
  )
}

export default BlogCardModal;

const BorderFlair = ({
  color,
  corner,
}) => {
  return (
    <svg
      className={`border-flair border-flair--${corner}`}
      fill="none"
      height="35"
      viewBox="0 0 975 976"
      xmlns="http://www.w3.org/2000/svg"
      width="35"
    >
      {corner === "bottom-right" && (
        <path
          clip-rule="evenodd"
          d="M175 975L175 975.002L0 975.002L174.984 800.018L174.984 800L800 800L800 175L975 1.07671e-05L975 175L975 975L974.984 975L974.984 975L175 975Z"
          fill={color}
          fill-rule="evenodd"
        />
      )}

      {corner === "top-left" && (
        <path
          clip-rule="evenodd"
          d="M800 0.00236591L800 -5.56264e-06L975 0L800.016 174.984L800.016 175.002L175 175.002L175 800.002L-4.94084e-05 975.002L9.53993e-06 800.002L0 0.00241806L0.015625 0.00241806V0.00241041L800 0.00236591Z"
          fill={color}
          fill-rule="evenodd"
        />
      )}
    </svg>
  );
}