import React from 'react';
import styled from "styled-components";
import { documentToReactComponents } from '@contentful/rich-text-react-renderer';
import { BLOCKS, MARKS } from '@contentful/rich-text-types';

import bg_image from "../../../assets/images/newsBlog/black-grid.png";


const ModalOverlay = styled.div`
  width: 100%;
  background-color: rgba(0,0,0,0.8);
  position: fixed;
  width: 100%;
  height: 100%;
  top:0;
  left:0;
  right:0;
  bottom:0;
  z-index: 9999;

  .modal-container{
    max-width: 1500px;
    width: 90vw;
    position: fixed;
    top: 40%;
    left: 50%;
    transform: translate(-50%,-50%);
    display: flex;
    background-color: #000000;
    box-shadow: 0 0 18px 0 rbga(0,0,0,0.75);
    border: 2px solid var(--neon-green);

    @media only screen and (max-width: 1024px){
      flex-direction: column;
      top: 50%;
    }
  }

  .left-side {
    width: 45%;
    position: relative;

    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    @media only screen and (max-width: 1024px){
      width: 100%;
    }
  }

  .right-side {
    width: 55%;
    position: relative;
    display: flex;
    align-items: center;
    flex-direction: column;
    justify-content: center;
    padding: 2rem 0;
    
    .bg-image {
      position: absolute;
      z-index: -1;
      width: 100%;
      height: 100%;
      top:0;
      left:0;
      transform: translateX(-22%);

      @media only screen and (max-width: 1024px){
        transform: translateX(0);
      }
    }

    @media only screen and (max-width: 1024px){
      width: 100%;
    }
  }

  .close-button{
    position: fixed;
    top: 1%;
    right: 1%;
    cursor: pointer;
    color: var(--neon-green);
    font-family: "Acumin Pro";
    font-weight: 600;

    @media only screen and (max-width: 1024px){
      background-color: #000000;
      margin: 0;
      padding: 0.25rem 0.5rem;
      border-radius: 9999px;
    }
  }

  .content {
    max-width: 73%;
    width: 100%;
    white-space: normal;
    max-height: 320px;
    overflow-y: scroll;
    
    &::-webkit-scrollbar {
      -webkit-appearance: none;
      width: 7px;
    }
    &::-webkit-scrollbar-thumb {
      border-radius: 4px;
      background-color: rgba(255, 255, 255, 1);
      box-shadow: 0 0 1px rgba(255, 255, 255, 1);
    }

    h2 {
      text-align: left;
      font-family: "Acumin Pro";
      font-weight: 900;
      font-style: italic;
      font-size: 40px;
      line-height: 140%;
      letter-spacing: 4px;
      color: #FFFFFF;
      opacity: 1;
      text-transform: uppercase;

      @media only screen and (max-width: 1024px){
        font-size: 32px;
        text-align: center;
      }

      @media only screen and (max-width: 900px){
        font-size: 25px;
      }

      @media only screen and (max-width: 500px){
        font-size: 20px;
        letter-spacing: 2px;
      }
    }

    p, ul {
      text-align: left;
      font-family: "Acumin Pro";
      font-size: 23px;
      line-height: 121%;
      letter-spacing: 0;
      font-style: normal;
      font-weight: 300;
      letter-spacing: 0px;
      color: #FFFFFF;

      &> strong {
        font-weight: 900;
      }


      @media only screen and (max-width: 1024px){
        text-align: center;
      }

      @media only screen and (max-width: 900px){
        font-size: 18px;
      }

      @media only screen and (max-width: 500px){
        font-size: 13px;
        line-height: 138%;
      }

      
    }

    ul {
      padding-left: 0;
      width: 100%;
      /* display: grid;
      grid-template-columns: repeat(3, 200px);
      gap: 1rem;

      @media only screen and (max-width: 768px){
        grid-template-columns: repeat(2, 1fr 1fr);
      }
      @media only screen and (max-width: 500px){
        grid-template-columns: repeat(1, 1fr);
      } */
    }

    .modal-listing {
      /* display: contents; */
      width: 100%;
    }

    .underlined{
      color: var(--neon-blue) !important;
    }

    strong {
      font-weight: 900;
    }

    @media only screen and (max-width: 1024px){
      max-width: 90%;
    }
  }

  .button-container {
    max-width: 73%;
    width: 100%;
    text-align: left;

    & > div {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
    }
  }

  .buttons-container {
    max-width: 73%;
    width: 100%;
    text-align: left;
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-top: 2rem;

    & > div {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;

      @media only screen and (max-width: 1024px){
        max-width: 200px;
      }

      @media only screen and (max-width: 768px){
        width: 100%;
      }
    }

    @media only screen and (max-width: 1024px){
      max-width: none;
    }

    @media only screen and (max-width: 1024px){
      display: flex;
      flex-direction: column;
      justify-items: center;
      row-gap: 1rem;
    }

  }

`

const RICHTEXT_OPTIONS = {
  renderMark: {
    [MARKS.BOLD]: text => <strong>{text}</strong>,
    [MARKS.UNDERLINE]: text=> <span className="underlined">{text}</span>,
  },
  renderNode: {
    [BLOCKS.PARAGRAPH]: (node, children) =>{
      return children!='' && (<p>{children}</p>)
    },
    [BLOCKS.HEADING_2]: (node, children) =>{
      return children!='' && (<h2>{children}</h2>)
    },
    [BLOCKS.UL_LIST]: (node, children) =>{
      return children!='' && (<ul>{children}</ul>)
    },
    [BLOCKS.LIST_ITEM]: (node, children) =>{
      return children!='' && (<li className='modal-listing'>{children}</li>)
    },
  }
}

const ModalInnerButton = styled.a`
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: "Pixel";
  text-transform: uppercase;
  font-size: 20px;
  letter-spacing: 0px;
  color: #00FF7B;
  opacity: 1;

  @media only screen and (max-width: 1600px){
    font-size: 18px;
  }

  @media only screen and (max-width: 1024px){
    font-size: 15px;
    width: 100%;
    max-width: 190px;
  }

  @media only screen and (max-width: 900px){
    // width: 235px;
  }

  @media only screen and (max-width: 480px){
    font-size: 15px;
  }

  span:hover{
    background-color: ${({textColor}) => `${textColor}`};
    color: ${({buttonColor}) => `${buttonColor}`};
    border-color:  ${({borderColor}) => `${borderColor}`};
  }

  span{
    display: block;
    background-color: ${({buttonColor}) => `${buttonColor}`};
    color: ${({textColor}) => `${textColor}`};
    border: ${({borderColor}) => `2px solid ${borderColor}`};
    padding: 0.5rem;
    position: relative;
    min-width: auto;
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;

    @media only screen and (max-width: 500px){
      font-size: 24px;
      padding: 0.5rem;
    }

    @media only screen and (max-width: 375px){
      font-size: 18px;
    }
  }
    
`
const colors ={
    "Black":"#000000",
    "Blue": "var(--neon-blue)",
    "Pink": "var(--neon-pink)",
    "Yellow": "var(--neon-yellow)",
    "Green": "var(--neon-green)",
    "White": "#FFFFFF",
    "Purple": "var(--neon-purple)",
  }

const Modal = ({open, onClose, data}) => {
  if(!open) return null;
  return (
    <ModalOverlay>
      <div className="modal-container">
        <div className="left-side">
          <BorderFlair
            color={"var(--neon-green)"}
            corner="top-left"
          />
          <img alt="" src={data.image.url} className=''/>
        </div>
        <div className="right-side">
          <BorderFlair
            color={"var(--neon-green)"}
            corner="bottom-right"
          />
          <img alt="" src={bg_image} className='bg-image'/>
          <p onClick={onClose} className="close-button">X</p>
          <div className="content">
            {documentToReactComponents(JSON.parse(data.modalDescription.raw), RICHTEXT_OPTIONS)}
          </div>
          {/* {data.button &&
          <div className="button-container">
            <div>
              <ModalInnerButton href={data.button.buttonLink} borderColor={colors[data.button.borderColor]} buttonColor={colors[data.button.buttonColor]} textColor={colors[data.button.textColor]}>
              <span>
                <BorderFlair
                  color={"var(--neon-green)"}
                  corner="top-left"
                />
                {data.button.buttonText}
                <BorderFlair
                  color={"var(--neon-green)"}
                  corner="bottom-right"
                />
              </span>
            </ModalInnerButton>
            </div>
          </div>} */}

          {data.buttons &&
          <div className='buttons-container'>
          {data.buttons.map((button)=>{
            return(<div>
              <ModalInnerButton href={button.buttonLink} borderColor={colors[button.borderColor]} buttonColor={colors[button.buttonColor]} textColor={colors[button.textColor]}>
              <span>
                <BorderFlair
                  color={"var(--neon-green)"}
                  corner="top-left"
                />
                {button.buttonText}
                <BorderFlair
                  color={"var(--neon-green)"}
                  corner="bottom-right"
                />
              </span>
            </ModalInnerButton>
            </div>)
          })}
          </div>}
        </div>
      </div>
    </ModalOverlay>
  )
}

export default Modal

const BorderFlair = ({
  color,
  corner,
}) => {
  return (
    <svg
      className={`border-flair border-flair--${corner}`}
      fill="none"
      height="35"
      viewBox="0 0 975 976"
      xmlns="http://www.w3.org/2000/svg"
      width="35"
    >
      {corner === "bottom-right" && (
        <path
          clip-rule="evenodd"
          d="M175 975L175 975.002L0 975.002L174.984 800.018L174.984 800L800 800L800 175L975 1.07671e-05L975 175L975 975L974.984 975L974.984 975L175 975Z"
          fill={color}
          fill-rule="evenodd"
        />
      )}

      {corner === "top-left" && (
        <path
          clip-rule="evenodd"
          d="M800 0.00236591L800 -5.56264e-06L975 0L800.016 174.984L800.016 175.002L175 175.002L175 800.002L-4.94084e-05 975.002L9.53993e-06 800.002L0 0.00241806L0.015625 0.00241806V0.00241041L800 0.00236591Z"
          fill={color}
          fill-rule="evenodd"
        />
      )}
    </svg>
  );
}