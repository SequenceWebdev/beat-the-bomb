import React, {useState} from 'react'
import styled from 'styled-components'
import { documentToReactComponents } from '@contentful/rich-text-react-renderer'
import { BLOCKS, MARKS } from '@contentful/rich-text-types'
import Button from '../button'

//Images
import square_corner from '../../../assets/images/flair/square-corner.png';
import pink_splat from '../../../assets/images/flair/pink-paint-splat.png';
import pink_bomb from '../../../assets/images/flair/bomb-pink.png';
import green_bomb from '../../../assets/images/flair/bomb-green.png';

const ChooseMissionOuterWrapper = styled.div`
  width: 100%;
  margin-top: 7rem;
  margin-bottom: 5rem;

  @media only screen and (max-width: 1024px){
    margin-top: 3rem;
    margin-bottom: 2rem;
  }
`
const Content = styled.div`
  width: 100%;
  max-width: 1920px;
  margin-left: auto;
  margin-right: auto;
  padding-left: 128px;
  padding-right: 128px;
  position: relative;

  .button-img {
    width:100%;
    height: 100%;
    object-fit: contain;
    position: relative;
    z-index: 1;
  }

  .button-img-hover {
    position: absolute;
    left: 0;
    top:0;
    width: 100%;
    height: 100%;
    opacity: 0;

    &:hover {
      opacity: 1;
    }
  }

  .grid-container {
    width: 100%;
    display: grid;
    grid-template-columns: 50% 50%;
    place-items: center;
    column-gap: 3rem;

    @media only screen and (max-width: 1024px){
      column-gap: 0;
      grid-template-columns: 1fr;
      row-gap: 3rem;
    }
  }

  .video {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;

    @media only screen and (max-width: 1024px){
      position: relative;
    }
  }

  .square-corner {
    height: 115px;
    left: -45px;
    pointer-events: none;
    position: absolute;
    bottom: -45px;
    transform: rotate(-90deg);
    width: 115px;
    z-index: 0;
  }

  .mission-info-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: stretch;
  }

  .mission-info-text {
    text-align: center;
    font-family: "Acumin Pro";
    font-style: italic;
    font-weight: 900;
    font-size: 40px;
    line-height: 56px;
    letter-spacing: 0px;
    color: #FFFFFF;
    opacity: 1;
    text-transform: uppercase;

    @media only screen and (max-width: 1440px){
      font-size: 35px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 30px;
    }

    @media only screen and (max-width: 900px){
      font-size: 25px;
      line-height: 30px;
    }
  }

  .card-mid-row {

    p, strong {
      padding: 0 20px;
      text-align: center;
      font-family: "Acumin Pro";
      font-weight: 300;
      font-size: 33px;
      line-height: 142%;
      letter-spacing: 0px;
      color: #FFFFFF;

      @media only screen and (max-width: 1600px){
        font-size: 24px;
      }
      
      @media only screen and (max-width: 1440px){
        font-size: 20px;
      }

      @media only screen and (max-width: 1024px){
        font-size: 18px;
        line-height: 142%;
      }

      @media only screen and (max-width: 900px){
        font-size: 16px;
      }

      @media only screen and (max-width: 480px){
        display: none;
      }
    }

    strong {
      padding: 0;
      font-style: italic;
      font-weight: 900;
    }

    p {
      @media only screen and (max-width: 500px){
        display: none;
      }
    }
  }

  .button-grid-container {
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-gap: 3rem;
    width: 100%;

    & > div:first-child > div {
      justify-content: flex-end;

      @media only screen and (max-width: 480px){
        justify-content: center;
      }
    }

    & > div:last-child > div {
      justify-content: flex-start;

      @media only screen and (max-width: 480px){
        justify-content: center;
      }
    }

    @media only screen and (max-width: 1024px){

      & > div:first-child > div {
        margin-top: 0rem;
      }

      & > div:last-child > div {
        margin-top: 0rem;
      }

      & > div:first-child {
        margin-top: 2rem;

        @media only screen and (max-width: 768px){
          margin-top: 1rem;
          margin-bottom: 1rem;
        }

        @media only screen and (max-width: 480px){
          margin-top: 0;
        }
      }

      & > div:last-child {
        margin-top: 2rem;

        @media only screen and (max-width: 768px){
          margin-top: 1rem;
          margin-bottom: 1rem;
        }

        @media only screen and (max-width: 480px){
          margin-top: 0;
        }
      }

      & > div:first-child > div > a > span {
        @media only screen and (max-width: 500px){
          font-size: 15px;
          line-height: 18px;
        }
      }

      & > div:last-child > div > a > span {
        @media only screen and (max-width: 500px){
          font-size: 15px;
          line-height: 18px;
        }
      }
    }

    @media only screen and (max-width: 480px){
      grid-gap: 1rem;
      justify-content: center;
    }
  }

  .button-wrapper {
    position: relative;
    z-index: 3;
    margin-top: -3rem;

    & > div {
      justify-content: center;

      @media only screen and (max-width: 1024px){
        justify-content: center;
      }
    }

    & > div > div,a {
      /* text-align: left; */
      font-family: "Pixel";
      text-transform: uppercase;
      font-size: 28px;
      letter-spacing: 0px;
      color: #00FF7B;
      opacity: 1;

      @media only screen and (max-width: 1600px){
        font-size: 18px;
      }

      @media only screen and (max-width: 1024px){
        font-size: 16px;
      }

      @media only screen and (max-width: 480px){
        font-size: 15px;
      }
    }

    & > div > a > span {
      padding: 15px 27px 12px 27px;
    }

    & > div > div > span {
      padding: 15px 27px 12px 27px;
    }

    @media only screen and (max-width: 500px){
      margin-top: -1rem;
    }
  }

  .pp-1 {
    height: 1001px;
    width: 955px;
    left: -600px;
    top: -300px;
    pointer-events: none;
    position: absolute;
    z-index: -1;
  }

  .pp-2 {
    height: 1001px;
    width: 955px;
    right: -400px;
    top: -100px;
    pointer-events: none;
    position: absolute;
    z-index: -1;
  }

  @media only screen and (max-width: 900px){
    padding: 0 20px;
  }

`

const VideoContainer = styled.div`

  position: relative;
  /* padding-bottom: 56.25%; 16:9 */
  /* height: 0; */
  width: 100%;
  height: 100%;
  border: 4px solid var(${({borderColor}) => `--neon-${borderColor.toLowerCase()}`});

  .border-flair {
    pointer-events: none;
    position: absolute;
  }

  .border-flair--bottom-right {
    bottom: -2px;
    right: 0;
  }

  .border-flair--top-left {
    left: 0px;
    top: -2px;
  }

  @media only screen and (max-width: 1024px){
    display: none;
  }
`

const Mission1Card = styled.div`
  position: relative;
  width: 100%;
  padding: ${({isSelected}) => `${isSelected}` === "mission1" ? "0px 0px 40px 0px":"0px"};
  background-color: #000000;
  border: 4px solid var(${({borderColor}) => `--neon-${borderColor.toLowerCase()}`});
  z-index: 1;

  .mission1-checkbox {
    width: 95px;
    height: 95px;
    top: -1px;
    left: -1px;
    /* position: absolute;
    z-index: 2; */
    border: 4px solid var(${({borderColor}) => `--neon-${borderColor.toLowerCase()}`});
  }

  .mission1-select {
    width: 100%;
    height: 100%;
    padding: 0;
    background-color: transparent;
    position: relative;
    z-index: 5;
    border: none;
  }

  .card-top-row {
    display: flex;
    flex-direction: row;
    align-items: center;
    
    h4 {
      width: 100%;
      margin: 0;
      text-align: center;
      font-family: "Pixel";
      font-size: 45px;
      line-height: 113%;
      letter-spacing: 0px;
      color: var(${({borderColor}) => `--neon-${borderColor.toLowerCase()}`});
      opacity: 1;

      @media only screen and (max-width: 1600px){
        font-size: 35px;
      }

      @media only screen and (max-width: 1440px){
        font-size: 27px;
      }

      @media only screen and (max-width: 480px){
        font-size: 23px;
      }
    }

    margin-bottom: ${({isSelected}) => `${isSelected}` === "mission1" ? "2rem":"0rem"};

    @media only screen and (max-width: 1024px){
      margin-bottom: 0;
    }
  }

  .card-top-row--secondCard {
    h4{
      color: var(${({borderColor}) => `--neon-${borderColor.toLowerCase()}`});
    }
  }

  @media only screen and (max-width: 500px){
    padding-bottom: 0;
  }
`

const Mission2Card = styled.div`
  margin-top: 2rem;
  position: relative;
  width: 100%;
  padding: ${({isSelected}) => `${isSelected}` === "mission2" ? "0px 0px 40px 0px":"0px"};
  background-color: #000000;
  border: 4px solid var(${({borderColor}) => `--neon-${borderColor.toLowerCase()}`});
  z-index: 1;

  .card-top-row {
    display: flex;
    flex-direction: row;
    align-items: center;

    h4 {
      width: 100%;
      margin: 0;
      text-align: center;
      font-family: "Pixel";
      font-size: 45px;
      line-height: 113%;
      letter-spacing: 0px;
      color: var(${({borderColor}) => `--neon-${borderColor.toLowerCase()}`});
      opacity: 1;

      @media only screen and (max-width: 1600px){
        font-size: 35px;
      }

      @media only screen and (max-width: 1440px){
        font-size: 27px;
      }

      @media only screen and (max-width: 480px){
        font-size: 23px;
      }
    }

    margin-bottom: ${({isSelected}) => `${isSelected}` === "mission2" ? "2rem":"0rem"};

    @media only screen and (max-width: 1024px){
      margin-bottom: 0;
    }
  }

  .card-top-row--secondCard {
    h4{
      color: var(${({borderColor}) => `--neon-${borderColor.toLowerCase()}`});
    }
  }

  .mission2-checkbox {
    width: 95px;
    height: 95px;
    top: -1px;
    left: -1px;
    /* position: absolute;
    z-index: 2; */
    border: 4px solid var(${({borderColor}) => `--neon-${borderColor.toLowerCase()}`});
  }

  .mission2-select {
    width: 100%;
    height: 100%;
    padding: 0;
    background-color: transparent;
    position: relative;
    z-index: 5;
    border: none;
  }

  @media only screen and (max-width: 500px){
    padding-bottom: 0;
  }
`

const RICHTEXT_OPTIONS = {
  renderMark: {
    [MARKS.BOLD]: text => <strong>{text}</strong>,
  },
  renderNode: {
    [BLOCKS.PARAGRAPH]: (node, children) =>{
      return children!='' && (<p>{children}</p>)
    },
  }
}

const MobileVideoWrapper = styled.div`
  position: relative;
  width: 100%;
  height: 100%;
  margin-bottom: 1rem;

  video {
    border: 4px solid var(${({borderColor}) => `--neon-${borderColor.toLowerCase()}`});
  }

  @media only screen and (min-width: 1025px){
    display: none;
  }
`

const ChooseMission = ({ data }) => {
  const { header, missions } = data;
  const mission1 = missions[0];
  const mission2 = missions[1];
  const [selected, setSelected] = useState("mission1");
  

  const colors ={
    "Black":"#000000",
    "Blue": "var(--neon-blue)",
    "Pink": "var(--neon-pink)",
    "Yellow": "var(--neon-yellow)",
    "Green": "var(--neon-green)",
    "White": "#FFFFFF",
  }

  return (
    <ChooseMissionOuterWrapper>
      <Content>
        {selected === "mission1" && 
        <>
        <div className="grid-container">
          <VideoContainer borderColor={mission1.paintWordColor}>
            <video
              autoPlay
              className="video"
              playsInline
              loop
              muted
              src={mission1.video.url}
              poster={mission1.cardImage.url}
            />
            <img
              alt="square-corner"
              className="square-corner"
              src={square_corner}
            />
            <VideoInner
              flairColor={colors[mission1.paintWordColor]}
              withFlair={true}
            />
          </VideoContainer>
          <div className="mission-info-container">
            <h3 className='mission-info-text'>{header}</h3>
            <Mission1Card borderColor={mission1.paintWordColor} isSelected={selected}>
              <div className="card-top-row">
                <div className="mission1-checkbox">
                  <button className="mission1-select" onClick={(e)=>{
                    setSelected("mission1");
                  }}>
                    <img alt="pink bomb icon" className='button-img' src={pink_bomb}/>
                  </button>
                </div>
                <h4>{mission1.missionName}</h4>
              </div>
              <div className="card-mid-row">
                <MobileVideoWrapper borderColor={mission1.paintWordColor}>
                  <video
                    autoPlay
                    className="video"
                    playsInline
                    loop
                    muted
                    src={mission1.video.url}
                    poster={mission1.cardImage.url}
                  />
                </MobileVideoWrapper>
                {documentToReactComponents(JSON.parse(mission1.missionDescription.raw), RICHTEXT_OPTIONS)}
              </div>
              <div className="button-grid-container">
              {mission1.buttons.map((button, index) => {
                return (
                  <div className="button-wrapper">
                    <Button
                      data={{ button }}
                      glow={{
                        "Black":"#000000",
                        "Blue": "var(--neon-blue)",
                        "Pink": "var(--neon-pink)",
                        "Yellow": "var(--neon-yellow)",
                        "Green": "var(--neon-green)",
                        "White": "#FFFFFF",
                      }[button.textColor]}
                      index={index}
                      withFlair={true}
                    />
                  </div>
                )
              })}
              </div>
              {/* <div className="mission1-checkbox">
                <button className="mission1-select" onClick={(e)=>{
                  setSelected("mission1");
                }}>
                  <img alt="pink bomb icon" className='button-img' src={pink_bomb}/>
                </button>
              </div> */}
            </Mission1Card>
            <Mission2Card borderColor={mission2.paintWordColor} isSelected={selected}>
              <div className="card-top-row card-top-row--secondCard" 
              onClick={()=>{setSelected("mission2");}} 
              onMouseEnter={(e)=>{
                e.target.style.cursor = "pointer";
                let green_bomb_icon = document.getElementById("mission2-bomb-hover-icon");
                green_bomb_icon.style.opacity = "1";
              }}
              onMouseLeave={()=>{let green_bomb_icon = document.getElementById("mission2-bomb-hover-icon");
                green_bomb_icon.style.opacity = "0";}}
              >
                <div className="mission2-checkbox">
                  <button className="mission2-select" onClick={(e)=>{
                    setSelected("mission2");
                  }}>
                    <img alt="green bomb icon" id="mission2-bomb-hover-icon" className='button-img-hover' src={green_bomb}/>
                  </button>
                </div>
                <h4>{mission2.missionName}</h4>
              </div>
              
            </Mission2Card>
          </div>
        </div>

       <img
          alt="pink-paint-1-img"
          className="pp-1"
          src={pink_splat}
        />
        <img
          alt="pink-paint-2-img"
          className="pp-2"
          src={pink_splat}
        />
        </>}
        {selected === "mission2" && 
        <>
        <div className="grid-container">
          <VideoContainer borderColor={mission2.paintWordColor}>
            <video
              autoPlay
              className="video"
              playsInline
              loop
              muted
              src={mission2.video.url}
              poster={mission2.cardImage.url}
            />
            <img
              alt="square-corner"
              className="square-corner"
              src={square_corner}
            />
            <VideoInner
              flairColor={colors[mission2.paintWordColor]}
              withFlair={true}
            />
          </VideoContainer>
          <div className="mission-info-container">
            <h3 className='mission-info-text'>{header}</h3>
            <Mission1Card borderColor={mission1.paintWordColor} isSelected={selected}>
              <div className="card-top-row" 
              onClick={()=>{setSelected("mission1");}} 
              onMouseEnter={(e)=>{
                e.target.style.cursor = "pointer";
                let pink_bomb_icon = document.getElementById("mission1-bomb-hover-icon");
                pink_bomb_icon.style.opacity = "1";
              }}
              onMouseLeave={()=>{let pink_bomb_icon = document.getElementById("mission1-bomb-hover-icon");
                pink_bomb_icon.style.opacity = "0";}}
              >
                <div className="mission1-checkbox">
                  <button className="mission1-select" onClick={(e)=>{
                    setSelected("mission1");
                  }}>
                    <img alt="pink bomb icon" id="mission1-bomb-hover-icon" className='button-img-hover' src={pink_bomb}/>
                  </button>
                </div>
                <h4>{mission1.missionName}</h4>
              </div>
              {/* <div className="mission1-checkbox">
                <button className="mission1-select" onClick={(e)=>{
                  setSelected("mission1");
                }}/>
              </div> */}
            </Mission1Card>
            <Mission2Card borderColor={mission2.paintWordColor} isSelected={selected}>
              <div className="card-top-row card-top-row--secondCard">
                <div className="mission2-checkbox">
                  <button className="mission2-select" onClick={(e)=>{
                    setSelected("mission2");
                  }}>
                    <img alt="green bomb icon" className='button-img' src={green_bomb}/>
                  </button>
                </div>
                <h4>{mission2.missionName}</h4>
              </div>
              <div className="card-mid-row">
                <MobileVideoWrapper borderColor={mission2.paintWordColor}>
                  <video
                    autoPlay
                    className="video"
                    playsInline
                    loop
                    muted
                    src={mission2.video.url}
                    poster={mission2.cardImage.url}
                  />
                </MobileVideoWrapper>
                {documentToReactComponents(JSON.parse(mission2.missionDescription.raw), RICHTEXT_OPTIONS)}
              </div>
              <div className="button-grid-container">
              {mission2.buttons.map((button, index) => {
                return (
                  <div className="button-wrapper">
                    <Button
                      data={{ button }}
                      glow={{
                        "Black":"#000000",
                        "Blue": "var(--neon-blue)",
                        "Pink": "var(--neon-pink)",
                        "Yellow": "var(--neon-yellow)",
                        "Green": "var(--neon-green)",
                        "White": "#FFFFFF",
                      }[button.textColor]}
                      index={index}
                      withFlair={true}
                    />
                  </div>
                )
              })}
              </div>
            </Mission2Card>
          </div>
        </div>

       <img
          alt="pink-paint-1-img"
          className="pp-1"
          src={pink_splat}
        />
        <img
          alt="pink-paint-2-img"
          className="pp-2"
          src={pink_splat}
        />
        </>}
      </Content>
    </ChooseMissionOuterWrapper>
  )
}

const VideoInner = ({
  flairColor,
  withFlair,
}) => {
  return (
    <span>
      {withFlair === true && (
        <BorderFlair
          color={flairColor}
          corner="top-left"
        />
      )}
      {withFlair === true && (
        <BorderFlair
          color={flairColor}
          corner="bottom-right"
        />
      )}
    </span>
  );
}

const BorderFlair = ({
  color,
  corner,
}) => {
  return (
    <svg
      class={`border-flair border-flair--${corner}`}
      fill="none"
      height="74"
      viewBox="0 0 975 976"
      xmlns="http://www.w3.org/2000/svg"
      width="71"
    >
      {corner === "bottom-right" && (
        <path
          clip-rule="evenodd"
          d="M175 975L175 975.002L0 975.002L174.984 800.018L174.984 800L800 800L800 175L975 1.07671e-05L975 175L975 975L974.984 975L974.984 975L175 975Z"
          fill={color}
          fill-rule="evenodd"
        />
      )}

      {corner === "top-left" && (
        <path
          clip-rule="evenodd"
          d="M800 0.00236591L800 -5.56264e-06L975 0L800.016 174.984L800.016 175.002L175 175.002L175 800.002L-4.94084e-05 975.002L9.53993e-06 800.002L0 0.00241806L0.015625 0.00241806V0.00241041L800 0.00236591Z"
          fill={color}
          fill-rule="evenodd"
        />
      )}
    </svg>
  );
}

export default ChooseMission