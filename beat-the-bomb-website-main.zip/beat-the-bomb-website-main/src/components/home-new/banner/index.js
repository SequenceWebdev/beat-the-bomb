import React from 'react'
import styled from 'styled-components'
import ReactMarkdown from "react-markdown";
import rehypeRaw from 'rehype-raw'

const fadeDirection={
  None: '',
  Upright: 'fade-right',
  Upleft: 'fade-left',
}

const tiltDirection = {
  None: '',
  Upright: 'banner--angle-1',
  Upleft: 'banner--angle-2',
}

const bannerType = {
  None: 'banner--normal',
  Upright: 'banner--tilt',
  Upleft: 'banner--tilt',
}

const BannerWrapper = styled.div`
  p{
    font-family: "Acumin Pro";
    font-weight: 700;
    margin:0;
  }

  a{
    text-decoration: underline;
    color: var(--neon-blue);
  }

  a:hover{
    color: #ffffff;
  }

  .banner--normal{
    @media only screen and (max-width: 500px){
      padding: 15px 30px 15px 20px;
    }
  }

  .banner h2{
    font-size: ${({fontSize}) => `${fontSize}px`};

    @media only screen and (max-width: 900px){
      font-size: 24px;
    }
    
    @media only screen and (max-width: 768px){
      font-size: 20px;
    }

    @media only screen and (max-width: 500px){
      font-size: 10px;
      /* padding: 0 15px 0 5px; */
    }

    /* @media only screen and (max-width: 375px){
      padding: 0 10px 0 5px;
    } */
  }

  .banner--tilt h2{
    font-size: ${({fontSize}) => `${fontSize}px`};

    @media only screen and (max-width: 900px){
      font-size: 40px;
    }

    @media only screen and (max-width: 768px){
      font-size: 30px;
    }

    @media only screen and (max-width: 500px){
      font-size: 22px;
    }

  }
`

const Banner = ({ data }) => {
  const { color, tiltAlignment, text, fontSize } = data
  const fadeEffDirection = fadeDirection[tiltAlignment]
  const angle = tiltDirection[tiltAlignment]
  const type = bannerType[tiltAlignment]
  return (
    <BannerWrapper fontSize={fontSize}>
      <div 
        className={`banner ${type} ${angle} banner--${color.toLowerCase() || "blue"}`}
        id={`${text.text.toLowerCase()}`}
      >
        <h2
          data-aos={`${fadeEffDirection}`} 
          data-aos-once="true"
        >
          {/* {text} */}
          <ReactMarkdown rehypePlugins={[rehypeRaw]} children={text.text} />
        </h2>
      </div>
    </BannerWrapper>
    
  )
}

export default Banner