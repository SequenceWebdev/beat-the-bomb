import React from 'react'
import styled from 'styled-components'
import { documentToReactComponents } from '@contentful/rich-text-react-renderer'
import { BLOCKS } from '@contentful/rich-text-types'
import Button from '../button'
import { GatsbyImage, getImage } from 'gatsby-plugin-image'

const SectionWrapper = styled.div`
  max-width: 1440px;
  position: relative;
  left: 50%;
  transform: translateX(-50%);
  display: grid; 
  grid-template-columns: repeat(2, 1fr);
  column-gap: 3rem;
  margin-top: 2rem;
  padding: 0 3rem;

  .left_side{
    display: flex;
    flex-direction: column;
    align-items: center;
    height: 100%;
    justify-content: center;
  }

  .right_side{
    width: 100%;
    .video__container{
      width: 100%;
    }

    .video__container video{
      width: 100%;
    }

    @media only screen and (max-width: 768px){
      margin-top: 2.5rem;
    }

    @media only screen and (max-width: 500px){
      margin-top: 1.5rem;
    }
  }

  @media only screen and (max-width: 768px){
    padding: 0 1rem;
  }

  @media only screen and (max-width: 600px){
    grid-template-columns: repeat(1, 1fr);
  }
`

const RichTextContainer = styled.div`
  width: 100%;
  margin-left: auto;
  margin-right: auto;
  margin-bottom:-1rem;

  .rich_paragraph{
    font-family: "Acumin Pro";
    font-style: normal;
    font-weight: 400;
    font-size: 36px;
    line-height: 125%;
    color: #ffffff;
    margin-bottom: 0rem;
    text-align: center;

    @media only screen and (max-width: 1250px){
      font-size: 28px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 22px;
    }

    @media only screen and (max-width: 768px){
      font-size: 25px;

    }

    @media only screen and (max-width: 500px){
      font-size: 18px;
    }
  }

  @media only screen and (max-width: 500px){
    margin-bottom: 0;
    padding: 0 20px;
  }
`

const RICHTEXT_OPTIONS = {
  renderNode: {
    [BLOCKS.PARAGRAPH]: (node, children) =>{
      return children!='' && (<p className='rich_paragraph'>{children}</p>)
    },
  }
}

const ImageTextButton = ({ data }) => {
  const { richText, mediaAsset } = data
  const json_text = JSON.parse(richText.raw)
  return (
    <SectionWrapper>
      <div className="left_side">
        <RichTextContainer>
          {documentToReactComponents(json_text, RICHTEXT_OPTIONS)}
        </RichTextContainer>
        <Button data={data}/>
      </div>
      <div className="right_side">
        {mediaAsset.gatsbyImageData!==null && 
          <div className="image__container">
            <GatsbyImage alt={mediaAsset.title} className='single_image' image={getImage(mediaAsset.gatsbyImageData)}/>
          </div>
        }
        {mediaAsset.gatsbyImageData===null &&
          <div className="video__container">
            <video autoPlay playsInline loop muted>
              <source src={mediaAsset.url} type="video/mp4" />
            </video>   
          </div>
        }
      </div>
    </SectionWrapper>
  )
}

export default ImageTextButton