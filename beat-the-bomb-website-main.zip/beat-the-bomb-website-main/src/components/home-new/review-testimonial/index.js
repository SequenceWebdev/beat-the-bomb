import React from 'react'
import styled from 'styled-components'
import { GatsbyImage, getImage } from 'gatsby-plugin-image'

const ReviewCardWrapper = styled.div`
  max-width: 1440px;
  position: relative;
  left: 50%;
  transform: translateX(-50%);
  padding: 0 3rem;
  display: flex;
  justify-content: ${({alignment}) => (`${alignment}`.toLowerCase()==='left') ? 'flex-start':'flex-end'};
  margin-bottom: 100px;

  @media only screen and (max-width: 500px){
    padding: 0 1rem;
    margin-bottom: 75px;
  }
`

const ReviewCard = styled.div`
  margin-top: 2rem;
  padding: 1rem 3rem;
  display: flex;
  flex-direction: column;
  background-color: ${({color}) => `var(--neon-${color})`};
  height: 100%;
  justify-content: space-between;
  width: 75%;

  .text__container p, .client p, .date p{
    font-family: 'Acumin Pro';
    font-style: normal;
    font-weight: 400;
    font-size: 28px;
    line-height: 121%;
    color: #000000;
    margin: 0;

    @media only screen and (max-width: 1024px){
      font-size: 22px;
    }

    @media only screen and (max-width: 900px){
      font-size: 18px;
    }

    @media only screen and (max-width: 500px){
      font-size: 16px;
    }
  }
  
  .text__container p{
    margin-top: 1rem;
    margin-bottom: 1rem;

    @media only screen and (max-width: 500px){
      margin-top: 0.5rem;
      margin-bottom: 0.25rem;
    }
  }

  .stars_image__container{
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .stars_image{
    @media only screen and (max-width: 500px){
      width: 40%;
    }
  }

  .source{

    @media only screen and (min-width: 769px){
      margin-left: 2rem;
    }

    @media only screen and (max-width: 500px){
      display: flex;
      align-items: center;
      justify-content: center;
    }
  }

  .source_image{
    @media only screen and (max-width: 500px){
      width: 50%;
    }
  }

  .client__container{
    display: flex;
    justify-content: flex-start;
    align-items: center;
    margin-bottom: 1rem;

    @media only screen and (max-width: 768px){
      flex-direction: column;
    }

    @media only screen and (max-width: 500px){
      margin-bottom: 0;
    }
  }

  .client_date{
    display: flex;
    justify-content: center;
    align-items: center;

    @media only screen and (max-width: 768px){
      margin-bottom: 1rem;
    }

    @media only screen and (max-width: 500px){
      margin-bottom: 0.25rem;
    }
  }

  @media only screen and (max-width: 768px){
    width: 100%;
  }

  @media only screen and (max-width: 500px){
    padding: 1rem;
  }
`
const RightReviewCardTail = styled.div`
  width: 0;
  height: 0;
  border-top: 100px solid ${({color}) => `var(--neon-${color})`};
  border-left: 100px solid transparent;
  position: absolute;
  bottom: 0%;
  transform: translateY(99%);
  right: 15%;

  @media only screen and (max-width: 500px){
    border-top: 60px solid ${({color}) => `var(--neon-${color})`};
    border-left: 60px solid transparent;
  }
`

const LeftReviewCardTail = styled.div`
  width: 0;
  height: 0;
  border-top: 100px solid ${({color}) => `var(--neon-${color})`};
  border-right: 100px solid transparent;
  position: absolute;
  bottom: 0%;
  transform: translateY(99%);
  left: 15%;

  @media only screen and (max-width: 500px){
    border-top: 60px solid ${({color}) => `var(--neon-${color})`};
    border-right: 60px solid transparent;
  }
`

const ReviewTestimonial = ({ data }) => {
  const { alignment, clientName, postedDate, review, sourceImage, starImage, backgroundColor } = data
  return (
    <ReviewCardWrapper alignment={alignment}>
      <ReviewCard color={backgroundColor}>
        <div className="stars_image__container">
          <GatsbyImage alt={starImage.title} className="stars_image" image={getImage(starImage.gatsbyImageData)}/>
        </div>
        <div className="text__container">
          <p>{review.review}</p>
        </div>
        <div className="client__container">
          <div className="client_date">
            <div className="client">
              <p><b>{clientName}</b>,&nbsp;</p>
            </div>
            <div className="date">
              <p>{postedDate}</p>
            </div>
          </div>
          
          <div className="source">
            <GatsbyImage alt={sourceImage.title} className="source_image" image={getImage(sourceImage.gatsbyImageData)}/>
          </div>
        </div>
      </ReviewCard>
      {alignment==='Right' && 
      <RightReviewCardTail color={backgroundColor}>
      </RightReviewCardTail>}
      {alignment==='Left' && 
      <LeftReviewCardTail color={backgroundColor}>
      </LeftReviewCardTail>}
    </ReviewCardWrapper>
  )
}

export default ReviewTestimonial