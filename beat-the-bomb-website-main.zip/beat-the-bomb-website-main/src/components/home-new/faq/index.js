import React from 'react'
import styled from 'styled-components'
import FaqQa from '../../question-faq'

const FaqWrapper = styled.div`
  max-width: 1440px;
  position: relative;
  left: 50%;
  transform: translateX(-50%);
  margin-top: 5rem;

  @media only screen and (max-width: 768px){
    margin-top: 3rem;
  }

`

const FAQ = ({ data }) => {
  return (
    <FaqWrapper>
      {data.qa.map((set, index)=>{
        return(
          <FaqQa index={index} q={set.question.question} a={set.answer.answer}/>
        )
      })}
    </FaqWrapper>
  )
}

export default FAQ