import React, {useState, useEffect} from 'react';
import styled from 'styled-components';
import Button from '../button'

//react icon
import { IoMdDownload } from "react-icons/io";
import { IoMdCloseCircle } from "react-icons/io";

//images
import blue_splat from "../../../assets/images/flair/blue-paint-splat.png";
import square from '../../../assets/images/flair/square.png';
import bombie from '../../../assets/images/flair/bombie-white.png';

const FDWrapper = styled.div`
  width: 100%;

  @media only screen and (min-width: 374px){
    padding-top: 0rem;
  }

  @media only screen and (min-width: 424px){
    padding-top: 1rem;
  }

  @media only screen and (min-width: 499px){
    padding-top: 3rem;
  }

  @media only screen and (min-width: 768px){
    padding-top: 6rem;
  }

  @media only screen and (min-width: 901px){
    padding-top: 0rem;
  }

  .container {
    max-width: 1920px;
    margin-left: auto;
    margin-right: auto;
    padding: 0 128px;
    position: relative;

    @media only screen and (max-width: 900px){
      padding-left: 48px;
      padding-right: 48px;
    }

    @media only screen and (max-width: 500px){
      padding-left: 32px;
      padding-right: 32px;
    }

    .flairs {
      * {
        pointer-events: none;
        position: absolute;
        z-index: 2;
      }

      .bombie {
        top: 50%;
        height: 290px;
        left: 20%;
        width: 194px;
        transform: rotate(-25deg);
        opacity: 0.25;
        z-index: -1;

        @media only screen and (max-width: 500px){
          height: 222px;
          width: 148px;
          transform: rotate(-15deg);
          left: 5%;
          top: 32%;
        }
      }

      .blue-splat {
        top:-150px;
        right: -400px;
        z-index: -1;

        @media only screen and (max-width: 900px){
          display: none;
        }
      }

      .square {
        top: -25px;
        height: 115px;
        right: 125px;
        width: 115px;

        @media (max-width: 900px) {
          display: none;
        }
      }
    }
  }

  .active-accordion {
    background-color: black;
  }

  .fb-navbar {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: row;
    margin-bottom: 3rem;

    button {
      background: transparent;
      border: none;
      padding: 0;
    }

    span {
      width: 100%;
      margin: 0 1rem;
      font-family: "Acumin Pro";
      font-weight: 900;
      font-size: 55px;
      letter-spacing: 5.5px;
      color: #FFFFFF;
      line-height: 140%;
      opacity: 0.5;

      @media only screen and (max-width: 1440px){
        font-size: 45px;
      }

      @media only screen and (max-width: 1024px){
        font-size: 40px;
      }

      @media only screen and (max-width: 768px){
        font-size: 30px;
      }

      @media only screen and (max-width: 500px){
        font-size: 25px;
        letter-spacing: 2.5px;
      }

    }

    .active-tab {
      span{
        opacity: 1;
        border-bottom: 2px solid #FFFFFF;
      }
    }
    
    .nonactive-tab {
      span{
        color: white; /* Unfortunately you can't use transparent here … */
        text-shadow:
        -1px -1px 0 #FFF,  
        1px -1px 0 #FFF,
        -1px 1px 0 #FFF,
        1px 1px 0 #FFF;

        @supports((text-stroke: 2px white) or (-webkit-text-stroke: 2px white)) {
        
          color: transparent;
          -webkit-text-stroke: 2px white;
          text-stroke: 2px white;
          text-shadow: none;
        
        }
      }
    }
  }
  
  .menus-container{
    margin-top: 8rem;
    max-width: 1282px;
    width: 100%;
    margin-left: auto;
    margin-right: auto;

    @media only screen and (max-width: 900px){
      margin-top: 5rem;
    }

    @media only screen and (max-width: 500px){
      margin-top: 3rem;
    }
  }

  .extra-note{
    width: 100%;
    text-align: left;
    font-family: "Acumin Pro";
    font-style: italic;
    font-size: 20px;
    line-height: 140%;
    letter-spacing: 0;
    font-weight: 400;
    letter-spacing: 0px;
    color: #FFFFFF;
    opacity: 1;

    @media only screen and (max-width: 900px){
      font-size: 18px;
    }

    @media only screen and (max-width: 500px){
      font-size: 15px;
      line-height: 18px;
    }
  }

  .white-line-divider {
    border: 1px solid rgba(255,255,255,0.5);
    width: 100%;
    height: 1px;
    margin-bottom: 2rem;
  }

  .submenu-section {
    margin-bottom: 5rem;

    h6 {
      margin: 0 0 1rem 0;
      /* padding-bottom: 1rem; */
      /* border-bottom: 1px solid rgba(255,255,255,0.5); */
      color: #FFFFFF;
      text-align: left;
      font-size: 37px;
      letter-spacing: 3.7px;
      font-style: italic;
      font-weight: 900;
      font-family: "Acumin Pro";
      text-transform: uppercase;
      line-height: 137%;

      @media only screen and (max-width: 900px){
        font-size: 30px;
      }

      @media only screen and (max-width: 500px){
        font-size: 22px;
        letter-spacing: 2.2px;
        margin-bottom: 1.5rem;
      }
    }

    @media only screen and (max-width: 500px){
      margin-bottom: 2rem;
    }
  }

  .buttons-container {
    display: flex;
    justify-content: space-evenly;
    align-items: center;
    width: 100%;
    max-width: 900px;
    margin: 0 auto;

    @media only screen and (max-width: 900px){
      flex-direction: column;
      row-gap: 2rem;
    }

    @media only screen and (max-width: 500px){
      margin-top: 50px;
    }
  }

  .border-flair {
    pointer-events: none;
    position: absolute;
  }

  .border-flair--bottom-right {
    bottom: 0;
    right: 0;
  }

  .border-flair--top-left {
    left: 0;
    top: 0;
  }

  .active-border {
    display: none;
  }
`
const Accordion = styled.div`
  margin-bottom: 5rem;
  position: relative;

  @media only screen and (max-width: 900px){
    margin-bottom: 3rem;
  }

  @media only screen and (max-width: 500px){
    margin-bottom: 1rem;
  }

  .close-icon-container {
    position: absolute;
    left: 50%;
    bottom: 0;
    transform: translate(-50%, 50%);
    z-index: 2;
    background-color: #000000;
  }

  .close-icon-container--active {
    display: none;
  }

  .accordion {
    position: relative;
    background: transparent;
    color: ${({wordColor}) => `${wordColor}`};
    cursor: pointer;
    padding: 18px;
    width: 100%;
    border: none;
    text-align: left;
    outline: none;
    font-size: 15px;
    transition: 0.4s;
    text-align: center;
    
    span {
      position: absolute;
      top: 0;
      left: 50%;
      line-height: 154%;
      letter-spacing: 5.5px;
      transform: translate(-50%, -50%);
      font-family: "Acumin Pro";
      font-style: italic;
      font-weight: 900;
      font-size: 55px;
      /* background: #000000; */
      padding-left: 40px;
      padding-right: 40px;
      text-transform: uppercase;
      width: 100%;

      @media only screen and (max-width: 1440px){
        font-size: 48px;
      }

      @media only screen and (max-width: 1024px){
        font-size: 43px;
      }

      @media only screen and (max-width: 768px){
        font-size: 32px;
      }

      @media only screen and (max-width: 500px){
        font-size: 24px;
        line-height: 125%;
        letter-spacing: 2.4px;
        padding-left: 12px;
        padding-right: 12px;
      }
    }

    .active-span {
      background: #000000;
      width: auto;
    }
  }

  /* .active, .accordion:hover {
    background-color: #ccc;
  } */

  .active {
    border-top: 2px solid ${({wordColor}) => `${wordColor}`};
    border-right: 2px solid ${({wordColor}) => `${wordColor}`};
    border-left: 2px solid ${({wordColor}) => `${wordColor}`};
  }

  .active-panel {
    margin-bottom: 8rem;
    padding: 2rem 70px;
    border-bottom: 2px solid ${({wordColor}) => `${wordColor}`};
    border-right: 2px solid ${({wordColor}) => `${wordColor}`};
    border-left: 2px solid ${({wordColor}) => `${wordColor}`};

    @media only screen and (max-width: 1024px){
      padding: 2rem 28px;
    }

    @media only screen and (max-width: 900px){
      margin-bottom: 6rem;
    }

    @media only screen and (max-width: 500px){
      margin-bottom: 4rem;
    }
  }

  .panel {
    position: relative;
    background: transparent;
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.2s ease-out;
  }
`
const MenuRow = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  column-gap: 2rem;
  row-gap: 2rem;
  align-items: center;

  @media only screen and (max-width: 1024px){
    grid-template-columns: 1fr;
  }
`
const MenuItem = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 100%;
  padding-bottom: 2rem;
  border-bottom: 2px solid rgba(255,255,255,0.5);


  .item-text {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;

    p {
      text-align: left;
      font-family: "Acumin Pro";
      font-size: 22px;
      line-height: 136%;
      font-style: normal;
      font-weight: 600;
      letter-spacing: 0px;
      color: #FFFFFF;
      text-transform: uppercase;
      opacity: 1;

      @media only screen and (max-width: 900px){
        font-size: 20px;
      }

      @media only screen and (max-width: 500px){
        font-size: 15px;
      }

    }
  }

  .item-description{
    width: 100%;
    text-align: left;
    font-family: "Acumin Pro";
    font-size: 20px;
    line-height: 140%;
    letter-spacing: 0;
    font-style: normal;
    font-weight: 400;
    letter-spacing: 0px;
    color: #BABABA;
    opacity: 1;
    flex-grow: 1;

    @media only screen and (max-width: 900px){
      font-size: 18px;
    }

    @media only screen and (max-width: 500px){
      font-size: 15px;
      line-height: 18px;
    }
  }

  .item-image-container {
    width: 100%;
    position: relative;
    
    height: 288px;
    max-width: 358px;
    flex-shrink: 1;

    @media only screen and (max-width: 1366px){
      height: 258px;
    }

    @media only screen and (max-width: 1280px){
      height: 238px;
    }

    /* @media only screen and (max-width: 1024px){
      height: 100%;
      max-height: 288px;
    } */
  }

  .item-image-blur{
    position: absolute;
    width: 100%;
    height: 100%;
    box-shadow: 0 0 16px 16px #000000 inset;
  }

  .menu-item-img{
    width: 100%;
    max-width: 480px;
    height: 100%;
    max-height: 288px;
    object-fit: cover;
    object-position: center center;

    @media only screen and (max-width: 1024px){
      max-width: none;
    }
  }
`
const MenuButton = styled.a`
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: "Acumin Pro";
  font-weight: 900;
  text-transform: uppercase;
  font-size: 23px;
  font-style: italic;
  letter-spacing: 2.3px;
  line-height: 144%;
  color: #FFFFFF;
  opacity: 1;


  @media only screen and (max-width: 1024px){
    font-size: 18px;
    letter-spacing: 1.8px;
  }

  @media only screen and (max-width: 900px){
    width: 215px;
  }

  span:hover{
    background-color: ${({textColor}) => `${textColor}`};
    color: ${({buttonColor}) => `${buttonColor}`};
    border-color:  ${({borderColor}) => `${borderColor}`};
  }

  span{
    display: block;
    background-color: ${({buttonColor}) => `${buttonColor}`};
    color: ${({textColor}) => `${textColor}`};
    border: ${({borderColor}) => `2px solid ${borderColor}`};
    padding: 1rem 3rem;
    position: relative;
    min-width: auto;
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;

    @media only screen and (max-width: 500px){
      font-size: 18px;
      padding: 0.5rem 1rem;
    }
  }
    
`

const FoodAndDrinks = ({data}) => {
  const [selected, setSelected] = useState("Food");

  function accordionClick(){
    var acc = document.getElementsByClassName("accordion");
    var ci = document.getElementsByClassName("close-icon-container");

    var i;
    for (i = 0; i < acc.length; i++) {
      acc[i].addEventListener("click", function() {
        var tl_flair = this.firstChild;
        var span_title = tl_flair.nextElementSibling;
        var close_icon = this.previousElementSibling;
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        var br_flair = panel.lastChild;
        close_icon.classList.toggle("close-icon-container--active")
        span_title.classList.toggle("active-span");
        panel.classList.toggle("active-panel");
        tl_flair.classList.toggle("active-border");
        br_flair.classList.toggle("active-border");
        if (panel.style.maxHeight) {
          panel.style.maxHeight = null;
        } else {
          panel.style.maxHeight = panel.scrollHeight + "px";
        } 
      });
      ci[i].addEventListener("click", function() {
        var tl_flair = this.nextElementSibling.firstChild;
        var span_title = tl_flair.nextElementSibling;
        this.classList.toggle("close-icon-container--active")
        var acc = this.nextElementSibling;
        acc.classList.toggle("active");
        var panel = this.nextElementSibling.nextElementSibling;
        panel.classList.toggle("active-panel");
        var br_flair = panel.lastChild;
        span_title.classList.toggle("active-span");
        tl_flair.classList.toggle("active-border");
        br_flair.classList.toggle("active-border");

        if (panel.style.maxHeight) {
          panel.style.maxHeight = null;
        } else {
          panel.style.maxHeight = panel.scrollHeight + "px";
        } 
      });

    }
  }

  const colors ={
    "Black":"#000000",
    "Blue": "var(--neon-blue)",
    "Pink": "var(--neon-pink)",
    "Yellow": "var(--neon-yellow)",
    "Green": "var(--neon-green)",
    "White": "#FFFFFF",
    "Purple": "var(--neon-purple)",
  }

  useEffect(()=>{
    accordionClick();
  }, [selected]);

  return (
    <FDWrapper>
      <div className="container">
        <div className="flairs">
          <img src={square} alt="" className='square'/>
          <img src={blue_splat} alt="" className='blue-splat'/>

          <img src={bombie} alt="" className='bombie'/>
        </div>
        {/* Food & Bev Nav Bar */}
        <div className='fb-navbar'>
          <button 
          className={[
            selected === 'Food' ? 'active-tab' : 'nonactive-tab'
          ].join(' ')}
          value={"Food"}
          onClick={(e)=>{
            e.preventDefault();
            setSelected(e.currentTarget.value);
          }}
          >
            <span>Food</span>
          </button>
          <button 
          className={[
            selected === 'Drinks' ? 'active-tab' : 'nonactive-tab'
          ].join(' ')}
          value={"Drinks"}
          onClick={(e)=>{
            e.preventDefault();
            setSelected(e.currentTarget.value);
          }}
          >
            <span>Drinks</span>
          </button>
        </div>

        <div className='menus-container'>
          {/* Food */}
          {selected === "Food" && data.food &&
          data.food.map((category)=>{
            return (
              <Accordion wordColor={colors[category.color]} onClick={(e)=>{
                e.preventDefault();
                if(!e.currentTarget.classList.contains('active-accordion')){
                  e.currentTarget.classList.add('active-accordion');
                }else{
                  e.currentTarget.classList.remove('active-accordion');
                }
              }}>
              <div className="close-icon-container close-icon-container--active">
                <IoMdCloseCircle style={{cursor:"pointer"}} color={colors[category.color]} fontSize="5rem" onClick={(e)=>{
                  e.preventDefault();

                }}/>
              </div>
              
              <button className="accordion">
                <BorderFlair
                  color={colors[category.color]}
                  corner="top-left"
                />
                <span>{category.name}</span>
              </button>
              <div className="panel">
                {category.subMenuItems.map((subMenu)=>{
                  return(
                    <div className='submenu-section'>
                      {subMenu.name &&
                      <h6>{subMenu.name}</h6>}
                      {subMenu.extraNote &&
                      <p className='extra-note'>{subMenu.extraNote}</p>}
                      <div className="white-line-divider"></div>
                      <MenuRow>
                        {subMenu.menuItems &&
                        subMenu?.menuItems.map((item)=>{
                          return (
                            <MenuItem>
                              <div className='item-text'>
                                <p>{item.name}</p>
                                <p>{item.price}</p>
                              </div>
                             {item.description && <div className='item-description'>
                                <p>{item.description.description}</p>
                              </div>}
                              {item.image &&
                              <div className='item-image-container'>
                                <div className='item-image-blur'></div>
                                {item.image &&
                                <img alt={item.image.title} className="menu-item-img" src={item.image.url}/>}
                              </div>}
                            </MenuItem>
                          )
                        })}
                      </MenuRow>
                    </div>
                  )
                })}
                <BorderFlair
                  color={colors[category.color]}
                  corner="bottom-right"
                />
              </div>
              </Accordion>
            )
          })}

          {/* Drinks */}
          {selected === "Drinks" && data.drinks &&
          data.drinks.map((category)=>{
            return (
              <Accordion wordColor={colors[category.color]} onClick={(e)=>{
                e.preventDefault();
                if(!e.currentTarget.classList.contains('active-accordion')){
                  e.currentTarget.classList.add('active-accordion');
                }else{
                  e.currentTarget.classList.remove('active-accordion');
                }
              }}>
              <div className="close-icon-container close-icon-container--active">
                <IoMdCloseCircle color={colors[category.color]} style={{cursor:"pointer"}} fontSize="5rem" onClick={(e)=>{
                  e.preventDefault();
                }}/>
              </div>
              <button className="accordion">
                <BorderFlair
                  color={colors[category.color]}
                  corner="top-left"
                />
                <span>{category.name}</span>
              </button>
              <div className="panel">
                {category.subMenuItems.map((subMenu)=>{
                  return(
                    <div className='submenu-section'>
                      {subMenu.name &&
                      <h6>{subMenu.name}</h6>}
                      {subMenu.extraNote &&
                      <p className='extra-note'>{subMenu.extraNote}</p>}
                      <div className="white-line-divider"></div>
                      <MenuRow>
                        {subMenu.menuItems &&
                        subMenu.menuItems.map((item)=>{
                          return (
                            <MenuItem>
                              <div className='item-text'>
                                <p>{item.name}</p>
                                <p>{item.price}</p>
                              </div>
                              {item.description && <div className='item-description'>
                                <p>{item.description.description}</p>
                              </div>}
                              {item.image &&
                              <div className='item-image-container'>
                                <div className='item-image-blur'></div>
                                {item.image &&
                                <img alt={item.image.title} className="menu-item-img" src={item.image.url}/>}
                              </div>}
                            </MenuItem>
                          )
                        })}
                      </MenuRow>
                    </div>
                  )
                })}
                <BorderFlair
                  color={colors[category.color]}
                  corner="bottom-right"
                />
              </div>
              </Accordion>
            )
          })}

          {/* Buttons */}
          <div className='buttons-container'>
          {data.buttons.map((button)=>{
            return(
              <MenuButton href={button.image.url} target="_blank" download borderColor={colors[button.borderColor]} buttonColor={colors[button.buttonColor]} textColor={colors[button.textColor]}>
                <span>
                  <ButtonFlair
                    color={colors[button.borderColor]}
                    corner="top-left"
                  />
                  {button.buttonText}
                  <ButtonFlair
                    color={colors[button.borderColor]}
                    corner="bottom-right"
                  />
                  <IoMdDownload/>
                </span>
                {/* <a href={button.buttonLink}>{button.buttonText}</a> */}
              </MenuButton>
            )
          })}
          </div>
        </div>
      </div>

  
    </FDWrapper>
  )
}

const BorderFlair = ({
  color,
  corner,
}) => {
  return (
    <svg
      className={`border-flair border-flair--${corner} active-border`}
      fill="none"
      height="35"
      viewBox="0 0 975 976"
      xmlns="http://www.w3.org/2000/svg"
      width="35"
    >
      {corner === "bottom-right" && (
        <path
          clip-rule="evenodd"
          d="M175 975L175 975.002L0 975.002L174.984 800.018L174.984 800L800 800L800 175L975 1.07671e-05L975 175L975 975L974.984 975L974.984 975L175 975Z"
          fill={color}
          fill-rule="evenodd"
        />
      )}

      {corner === "top-left" && (
        <path
          clip-rule="evenodd"
          d="M800 0.00236591L800 -5.56264e-06L975 0L800.016 174.984L800.016 175.002L175 175.002L175 800.002L-4.94084e-05 975.002L9.53993e-06 800.002L0 0.00241806L0.015625 0.00241806V0.00241041L800 0.00236591Z"
          fill={color}
          fill-rule="evenodd"
        />
      )}
    </svg>
  );
}

const ButtonFlair = ({
  color,
  corner,
}) => {
  return (
    <svg
      className={`border-flair border-flair--${corner}`}
      fill="none"
      height="35"
      viewBox="0 0 975 976"
      xmlns="http://www.w3.org/2000/svg"
      width="35"
    >
      {corner === "bottom-right" && (
        <path
          clip-rule="evenodd"
          d="M175 975L175 975.002L0 975.002L174.984 800.018L174.984 800L800 800L800 175L975 1.07671e-05L975 175L975 975L974.984 975L974.984 975L175 975Z"
          fill={color}
          fill-rule="evenodd"
        />
      )}

      {corner === "top-left" && (
        <path
          clip-rule="evenodd"
          d="M800 0.00236591L800 -5.56264e-06L975 0L800.016 174.984L800.016 175.002L175 175.002L175 800.002L-4.94084e-05 975.002L9.53993e-06 800.002L0 0.00241806L0.015625 0.00241806V0.00241041L800 0.00236591Z"
          fill={color}
          fill-rule="evenodd"
        />
      )}
    </svg>
  );
}

export default FoodAndDrinks