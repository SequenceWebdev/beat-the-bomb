import React from 'react'
import styled from 'styled-components';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { GatsbyImage, getImage } from 'gatsby-plugin-image';
// Images
import bombie from '../../../assets/images/flair/bombie-grey.png';
import square_corner from '../../../assets/images/flair/square-corner.png';
import star from '../../../assets/images/reviews/star.png';
import square from '../../../assets/images/flair/square.png';

const Reviews = styled.div`
  position: relative;

  .wrapper {
    margin: 0 auto;
    max-width: 1440px;
    padding: 50px 40px;
    position: relative;

    @media only screen and (max-width: 480px){
      padding:0
    }
  }

  .stars {
    display: flex;
    justify-content: center;
    margin-bottom: 40px;
  }

  .stars img {
    height: 56px;
    width: 56px;

    @media (max-width: 600px) {
      height: 40px;
      width: 40px;
    }
  }

  .title {
    color: white;
    font-family: "Acumin Pro";
    font-size: 40px;
    font-style: italic;
    font-weight: 900;
    margin-bottom: 3rem;
    text-align: center;
    text-transform: uppercase;

    @media (max-width: 600px) {
      font-size: 25px;
      white-space: pre-line;
    }
  }

  .slick-slider-wrapper {
    position: relative;
  }

  .slick-track {
    display: flex !important;
  }

  .slick-slide {
    height: inherit !important;
  }

  .slick-slide > div {
    height: 100%;
  }

  .slick-arrow::before {
    background-position: center;
    background-size: 30px;
    content: "" !important;
    display: block !important;
    height: 20px !important;
    width: 20px !important;
  }

  .slick-next::before {
    background-image: url('data:image/svg+xml;utf8,<svg fill="none" height="24" stroke="%2300FF7B" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><polyline points="9 18 15 12 9 6" /></svg>');
  }

  .slick-prev::before {
    background-image: url('data:image/svg+xml;utf8,<svg fill="none" height="24" stroke="%2300FF7B" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><polyline points="15 18 9 12 15 6" /></svg>');
  }

  .bombie {
    height: 685px;
    pointer-events: none;
    position: absolute;
    right: 150px;
    top: 100px;
    width: 503px;
    z-index: 0;

    @media (max-width: 900px) {
      height: 412px;
      right: -150px;
      top: 300px;
      width: 302px;
    }

    @media (max-width: 600px){
      right: -100px;
      top: 275px;
    }
  }

  .square-corner-1 {
    height: 115px;
    left: -30px;
    pointer-events: none;
    position: absolute;
    top: -30px;
    width: 115px;
    z-index: 0;

    @media only screen and (max-width: 1024px){
      height: 71px;
      width: 71px;
      top:-15px;
      left: -15px;
    }

    @media only screen and (max-width: 480px){
      top:-15px;
      left: -15px;
    }
  }

  .flairs {
    * {
      position: absolute;
      z-index: 2;
    }

    .square {
      bottom: 50px;
      height: 157px;
      left: -60px;
      width: 157px;
    }
  }

  .square-1 {
    height: 115px;
    width: 115px;
    pointer-events: none;
    position: absolute;
    z-index: 0;
    left: -150px;
    bottom: 75px;

    @media only screen and (max-width: 1024px){
      width: 71px;
      height: 71px;
    }

    @media only screen and (max-width: 480px){
      display: none;
    }
  }

  .square-2 {
    height: 115px;
    width: 115px;
    pointer-events: none;
    position: absolute;
    z-index: 0;
    right: -125px;
    bottom: 35px;

    @media only screen and (max-width: 1024px){
      width: 71px;
      height: 71px;
    }

    @media only screen and (max-width: 480px){
      display: none;
    }
  }

  @media only screen and (max-width: 480px){
    padding: 0 20px;
  }
`

const ReviewCard = styled.div`
  height: 100%;
  padding: 10px;

  .inner {
    border: solid 4px ${({color}) => `var(--neon-${color})`};
    box-shadow: 0 0 10px 0 ${({color}) => `var(--neon-${color})`}, inset 0 0 10px 0 ${({color}) => `var(--neon-${color})`};
    color: white;
    display: flex;
    flex-direction: column;
    height: 100%;
    max-width: 1000px;
    padding: 25px 40px;
    text-align: center;

    @media (max-width: 900px) {
      padding: 25px;
    }

    @media only screen and (max-width: 480px){
      padding-bottom: 0;
      padding-top: 12px;
    }
  }

  .source {
    align-items: center;
    display: flex;
    justify-content: center;
    height: 55px;
    margin: 0 auto 25px auto;
    width: 200px;

    @media (max-width: 600px) {
      width: 150px;
      margin-bottom: 12px;
    }

  }

  .author {
    color: ${({color}) => `var(--neon-${color})`};
    font-family: 'Pixel', sans-serif;
    font-size: 25px;

    @media (max-width: 600px) {
      font-size: 15px;
    }
  }

  .review {
    font-family: "Acumin Pro";
    font-size: 20px;
    font-weight: 300;

    @media (max-width: 900px) {
      font-size: 15px;
      line-height: 18px;
    }
  }

  .review-stars {
    align-items: center;
    display: none;
    justify-content: center;
    margin-top: auto;

    @media (max-width: 600px) {
      margin-left: auto;
      margin-right: auto;
      width: 200px;
    }
  }
`

const ReviewCarousel = ({ data }) => {
  const settings = {
    arrows: false,
    autoplay: true,
    autoplaySpeed: 5000,
    dots: false,
    infinite: true,
    pauseOnFocus: false,
    pauseOnHover: false,
    slidesToScroll: 1,
    slidesToShow: 3,
    speed: 500,
    responsive: [
      {
        breakpoint: 1200,
        settings: {
          arrows: true,
          slidesToShow: 2,
        },
      },
      {
        breakpoint: 900,
        settings: {
          arrows: true,
          slidesToShow: 1,
        },
      },
    ],
  };

  return (
    <Reviews>
      <div className="wrapper">
        <div className="stars">
          {[1, 2, 3, 4, 5].map(index => {
            return (
              <img
                alt=""
                key={index}
                src={star}
              />
            );
          })}
        </div>

        {data.title && <h2 className="title">{data.title.title}</h2>}

        <div className="slick-slider-wrapper">
          <Slider {...settings}>
            {data.cards.map((card, index)=>{
              const { clientName, postedDate, review, sourceImage, starImage, backgroundColor } = card;
              return(
                <ReviewCard color={backgroundColor}>
                  <div className="inner">
                    <div className="source">
                      <GatsbyImage
                        alt={sourceImage.title}
                        image={getImage(sourceImage.gatsbyImageData)}
                        objectFit="contain"
                        style={{
                          height: "100%",
                          width: "100%",
                        }}
                      />
                    </div>

                    <p className="author">{clientName}</p>

                    <p className="review">{review.review}</p>

                    <div className="review-stars">
                      <GatsbyImage alt={starImage.title} image={getImage(starImage.gatsbyImageData)}/>
                    </div>
                  </div>
                </ReviewCard>
              )
            })}
          </Slider>

          <img
            alt=""
            className="square-corner-1"
            src={square_corner}
          />
        </div>
        <div className="flairs">
          <img
            alt="square-1-img"
            className="square-1"
            src={square}
          />
          <img
            alt="square-2-img"
            className="square-2"
            src={square}
          />
        </div>
      </div>

      <img
        alt=""
        className="bombie"
        src={bombie}
      />
    </Reviews>
  );
}

export default ReviewCarousel
