import React from 'react'
import styled from 'styled-components'
import { documentToReactComponents } from '@contentful/rich-text-react-renderer'
import { BLOCKS, MARKS } from '@contentful/rich-text-types'

const RichTextWrapper = styled.div`
  max-width: 1920px;
  position: relative;
  margin-left: auto;
  margin-right: auto;
  padding-left: 128px;
  padding-right: 128px;
  /* left: 50%;
  transform: translateX(-50%); */
  display: flex;
  align-items: center;
  justify-content: center;

  @media only screen and (max-width: 900px){
    padding: 0 12px;
  }

`

const RichTextContainer = styled.div`
  ${({ color }) => typeof color === "string" ? `color: var(--neon-${color.toLowerCase()})` : "color: #FFFFFF"};
  margin-left: auto;
  margin-right: auto;
  width: ${({textAlignment}) => `${textAlignment}` === "center" ? "100%" : "80%"};

  .rich_paragraph, .rich_h6, .rich_ul{
    font-family: ${({font}) => `${font}`==="Pixel Digivolve" ? "Pixel" : "Acumin Pro"};
    font-style: ${({fontStyle}) => `${fontStyle}`==="Italics" ? "italic" : "normal"};
    font-weight: ${({fontWeight}) => `${fontWeight}`};
    font-size: ${({fontSize}) => `${fontSize}px`};
    line-height: 125%;
    margin-top: ${({topMargin}) => topMargin===false ? '0rem':'3.5rem'};
    margin-bottom: 0rem;
    text-transform: ${({textTransform}) => `${textTransform}`.toLowerCase()};
    text-align:${({textAlignment}) => `${textAlignment}`};

    @media only screen and (max-width: 768px){
      font-size: 25px;
      text-align: center;
      margin-top: 2.5rem;
    }

    @media only screen and (max-width: 500px){
      font-size: 16px;
    }
  }

  .rich_paragraph {
    font-weight: 300;
    text-align: center;
    font-family: "Acumin Pro";
    font-weight: 300;
    font-size: 33px;
    line-height: 133%;
    letter-spacing: 0px;
    color: #FFFFFF;
    opacity: 1;
    position: relative;
    z-index: 3;

    @media only screen and (max-width: 1600px){
      font-size: 24px;
    }
    
    @media only screen and (max-width: 1440px){
      font-size: 20px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 18px;
      text-align: center;
      margin-top: 2rem;
    }

    @media only screen and (max-width: 900px){
      font-size: 16px;
    }

    @media only screen and (max-width: 480px){
      margin-top: 1rem;
      font-size: 15px;
      line-height: 18px;
    }
  }

  .rich_ul{
    margin-top: 0;
  }
  .rich_ul >li >p{
    margin-top: 1rem;
  }

  .rich_h6{
    text-align: left;
  }

  .rich_h1{
    font-family: 'Acumin Pro';
    font-style: ${({fontStyle}) => `${fontStyle}`==="Italics" ? "italic" : "normal"};
    font-weight: 700;
    font-size: 100px;
    line-height: 119%;
    text-align:${({textAlignment}) => `${textAlignment}`};
    letter-spacing: 0;
    text-transform: ${({textTransform}) => `${textTransform}`.toLowerCase()};
    margin-top: 3.5rem;
    color: #ffffff;

    @media screen and (max-width: 1250px) {
      font-size: 80px;
    }

    @media screen and (max-width: 1024px) {
      font-size: 60px;
    }

    @media screen and (max-width: 768px) {
      font-size: 45px;
    }

    @media screen and (max-width: 500px) {
      font-size: 32px;
    }
  }

  .rich_h2{
    font-family: "Acumin Pro";
    font-style: ${({fontStyle}) => `${fontStyle}`==="Italics" ? "italic" : "normal"};
    font-weight: ${({fontWeight}) => `${fontWeight}`};
    font-size: ${({fontSize}) => `${fontSize}px`};
    line-height: 125%;
    color: #ffffff;
    margin-top: 3.5rem;
    margin-bottom: 0rem;
    text-transform: ${({textTransform}) => `${textTransform}`.toLowerCase()};
    text-align:${({textAlignment}) => `${textAlignment}`};

    @media only screen and (max-width: 1024px){
      font-size: 50px;
    }

    @media only screen and (max-width: 768px){
      font-size: 42px;
      text-align: center;
    }

    @media only screen and (max-width: 500px){
      font-size: 30px;
    }
  }

  .rich_h3{
    font-family: ${({font}) => `${font}`==="Pixel Digivolve" ? "Pixel" : "Acumin Pro"};
    font-style: ${({fontStyle}) => `${fontStyle}`==="Italics" ? "italic" : "normal"};
    font-weight: ${({fontWeight}) => `${fontWeight}`};
    font-size: ${({fontSize}) => `${fontSize}px`};
    line-height: 125%;
    margin-top: ${({topMargin}) => topMargin===false ? '0rem':'3.5rem'};
    margin-bottom: 0rem;
    text-transform: ${({textTransform}) => `${textTransform}`.toLowerCase()};
    text-align:${({textAlignment}) => `${textAlignment}`};

    @media screen and (max-width: 1250px) {
      font-size: 32px;
    }

    @media screen and (max-width: 1024px) {
      font-size: 25px;
    }

    @media screen and (max-width: 768px) {
      font-size: 20px;
    }
  }

  /* text for we're hiring */
  .rich_h4{
    font-family: 'Acumin Pro';
    font-style: ${({fontStyle}) => `${fontStyle}`==="Italics" ? "italic" : "normal"};
    font-weight: 700;
    font-size: 105px;
    line-height: 119%;
    text-align: center;
    letter-spacing: 0;
    text-transform: uppercase;
    margin-top: ${({topMargin}) => topMargin===false ? '0rem':'3.5rem'};

    @media screen and (max-width: 1250px) {
      font-size: 80px;
    }

    @media screen and (max-width: 1024px) {
      font-size: 60px;
    }

    @media screen and (max-width: 768px) {
      font-size: 45px;
    }

    @media screen and (max-width: 500px) {
      font-size: 32px;
    }
  }

  .rich_h5{
    font-family: 'Acumin Pro';
    font-style: ${({fontStyle}) => `${fontStyle}`==="Italics" ? "italic" : "normal"};
    font-weight: 700;
    font-size: 50px;
    line-height: 140%;
    text-align: center;
    letter-spacing: 0;
    margin-top: ${({topMargin}) => topMargin===false ? '0rem':'3.5rem'};

    @media screen and (max-width: 1250px) {
      font-size: 32px;
    }

    @media screen and (max-width: 1024px) {
      font-size: 25px;
    }

    @media screen and (max-width: 768px) {
      font-size: 20px;
      margin-top: 1rem;
    }
  }

  .blue { color: var(--neon-blue); }
  .green { color: var(--neon-green); }
  .pink { color: var(--neon-pink); }

  .underline { text-decoration: underline; }
  .strong_text {
    font-weight: 900;
  }

  @media only screen and (max-width: 500px){
    width: 95%;
  }
`

const RICHTEXT_OPTIONS = {
  renderMark: {
    [MARKS.BOLD]: text => <strong className='strong_text'><br/>{text}</strong>,
    [MARKS.UNDERLINE]: text => <span className='underline'>{text}</span>,
  },
  renderNode: {
    [BLOCKS.PARAGRAPH]: (node, children) =>{
      return children!='' && (<p className='rich_paragraph'>{children}</p>)
    },
    [BLOCKS.UL_LIST]: (node, children) =>{
      return children!='' && (<ul className='rich_ul'>{children}</ul>)
    },
    [BLOCKS.HEADING_1]: (node, children) =>{
      return children!='' && (<h1 className='rich_h1'>{children}</h1>)
    },
    [BLOCKS.HEADING_2]: (node, children) =>{
      return children!='' && (<h2 className='rich_h2'>{children}</h2>)
    },
    [BLOCKS.HEADING_3]: (node, children) =>{
      return children!='' && (<h3 className='rich_h3'>{children}</h3>)
    },
    [BLOCKS.HEADING_4]: (node, children) =>{
      return children!='' && (<h4 className='rich_h4'>{children}</h4>)
    },
    [BLOCKS.HEADING_5]: (node, children) =>{
      return children!='' && (<h5 className='rich_h5'>{children}</h5>)
    },
    [BLOCKS.HEADING_6]: (node, children) =>{
      return children!='' && (<h6 className='rich_h6'>{children}</h6>)
    },
  }
}

const Text = ({ data }) => {
  const { color, contentfulid, textAlignment, fontStyle ,richText, font, fontSize, fontWeight, topMargin, textTransform } = data;
  const json_text = JSON.parse(richText.raw)
  const divID = (contentfulid !== null) ? contentfulid : "";

  return (
    <RichTextWrapper id={divID}>
      <RichTextContainer
        color={color}
        font={font}
        fontStyle={fontStyle}
        fontSize={fontSize}
        textAlignment={textAlignment}
        fontWeight={fontWeight}
        topMargin={topMargin}
        textTransform={textTransform}
      >
        {documentToReactComponents(json_text, RICHTEXT_OPTIONS)}
      </RichTextContainer>
    </RichTextWrapper>
  )
}

export default Text
