import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from 'styled-components'
// import poster from '../../../assets/images/tiktok_poster.jpg'
import paintBlastVidPoster from "../../../assets/images/winlose/winLose_poster1.png"
import { BsFillPlayFill } from "react-icons/bs";

import ReactPlayer from 'react-player'
// import { Player, BigPlayButton } from 'video-react';

const ImagePanelWrapper = styled.div`
  max-width: 1440px;
  position: relative;
  left: 50%;
  transform: translateX(-50%);
  margin-top: 5rem;
  /* display: flex;
  align-items: center;
  justify-content: space-around; */
  width: 100%;
  padding:0 3rem;
  column-gap: 3rem;
  display: grid;
  grid-template-columns: 3fr 4fr;

  .right_col{
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    /* row-gap: 2rem; */
    justify-content: space-between;
    margin-top: 2rem;
    margin-bottom: 2rem;

  }

  .gif__container{
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 3rem;

    /*@media only screen and (max-width: 1440px){
      margin-top: 8.5rem;
    }

    @media only screen and (max-width: 1250px){
      margin-top: 6rem;
    }

    @media only screen and (max-width: 900px){
      margin-top: 4rem;
    }

    @media only screen and (max-width: 768px){
      margin-top: 2rem;
    } */
  }

  .gif__container video{
    width: 100%;
  }

  @media only screen and (max-width: 768px){
    /* flex-direction: column; */
    /* row-gap: 2rem; */
    padding:0 1rem;
    grid-template-columns: 1fr;
  }
`

const VideoContainer = styled.div`
  width: 100%;
  height: auto;
  position: relative;
  /* padding-right: 3rem; */

  .play_icon_container{
    position:absolute;
    left:0%;
    bottom:3%;
    display:flex;
    justify-content: center;
    align-items: center;

    p{
      font-family: 'Montserrat';
      font-style: normal;
      font-weight: 700;
      font-size: 50px;
      text-align: center;
      letter-spacing: 0.065em;
      text-transform: uppercase;
      color: #FFFFFF;
      margin-top: 0rem;
      margin-bottom: 0rem;

      @media only screen and (max-width: 1250px){
        font-size: 40px;
      }

      @media only screen and (max-width: 1024px){
        font-size: 30px;
      }

      @media only screen and (max-width: 768px){
        font-size: 50px;
      }

      @media only screen and (max-width: 650px){
        font-size: 40px;
      }

      @media only screen and (max-width: 500px){
        font-size: 30px;
      }

      @media only screen and (max-width: 425px){
        font-size: 20px;
      }
    }

    @media only screen and (max-width: 768px){
      bottom: 4%;
      left:5%;
    }

    @media only screen and (max-width: 500px){
      bottom: 6%;
      left:7%;
    }
  }

  .play{
    color: #FFFFFF;
    font-size: 50px;

    @media only screen and (max-width: 1250px){
      font-size: 40px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 30px;
    }

    @media only screen and (max-width: 768px){
      font-size: 50px;
    }

    @media only screen and (max-width: 650px){
      font-size: 40px;
    }

    @media only screen and (max-width: 500px){
      font-size: 30px;
    }

    @media only screen and (max-width: 425px){
      font-size: 20px;
    }
  }

  @media only screen and (max-width: 768px){
    padding-right: 0;
    padding: 0 2rem;
  }

  @media only screen and (max-width: 500px){
    padding-right: 0;
    padding: 0 1rem;
  }

`

const Icons = styled.div`
  position: absolute;
  right: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 50%;
  justify-content: space-evenly;


  .likes, .comments, .shares{
    display: flex;
    flex-direction: column;
    align-items: center;

    @media only screen and (max-width: 1250px){
      width: 75%
    }
    @media only screen and (max-width: 1024px){
      width: 60%;
    }

    @media only screen and (max-width: 900px){
      width: 55%;
    }

    @media only screen and (max-width: 768px){
      width: 100%;
    }

    @media only screen and (max-width: 650px){
      width: 75%;
    }

    @media only screen and (max-width: 500px){
      width: 60%;
    }

    @media only screen and (max-width: 425px){
      width: 40%;
    }
  }

  .tiktok_comments, .tiktok_shares, .tiktok_likes{
    max-width: 80px;
    border-radius: 3rem;
    border: 1px solid #FFFFFF;
  }

  .tiktok_icon{
    max-width: 80px;
    border-radius: 3rem;
    border: 1px solid #FFFFFF;
  }

  & p{
    font-family: 'Montserrat';
    font-style: normal;
    font-weight: 400;
    font-size: 30px;
    line-height: 37px;
    text-align: center;
    letter-spacing: 0.065em;
    text-transform: uppercase;
    color: #FFFFFF;

    @media only screen and (max-width: 1250px){
      font-size: 20px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 18px;
    }

    @media only screen and (max-width: 768px){
      font-size: 30px;
    }

    @media only screen and (max-width: 650px){
      font-size: 20px;
    }

    @media only screen and (max-width: 500px){
      font-size: 18px;
    }
  }

  @media only screen and (max-width: 768px){
    right: 0%;
  }

  @media only screen and (max-width: 500px){
    bottom: 7%;
  }

`

const ImagePanel = ({ data }) => {
  const { bottomRightAsset, tikTok ,topRightAsset } = data
  const { likes, likeImage, shares, shareImage, commentImage, comments, video, plays } = tikTok
  return (
    <ImagePanelWrapper>
      <VideoContainer>
        {/* <Player src={video.url} muted autoPlay poster={poster} preload="auto">
          <BigPlayButton position="center" />
        </Player> */}
        <ReactPlayer 
        controls 
        url={video.url} 
        playing
        volume={1}
        muted
        width={"100%"}
        height={"100%"}
        playsinline
        />
        <div className="play_icon_container">
          <BsFillPlayFill className="play"/>
          <p>{plays}</p>
        </div>

        <Icons>
          <div className="likes">
            <GatsbyImage alt={likeImage.title} className="tiktok_likes" imgClassName="tiktok_icon" image={getImage(likeImage.gatsbyImageData)} />
            <p>{likes}</p>
          </div>
          <div className="comments">
            <GatsbyImage alt={commentImage.title} className="tiktok_comments" imgClassName="tiktok_icon" image={getImage(commentImage.gatsbyImageData)} />
            <p>{comments}</p>
          </div>
          <div className="shares">
            <GatsbyImage alt={shareImage.title} className="tiktok_shares" imgClassName="tiktok_icon" image={getImage(shareImage.gatsbyImageData)} />
            <p>{shares}</p>
          </div>
        </Icons>
      </VideoContainer>
      <div className="right_col">
        <div className="image__container">
          <GatsbyImage alt={topRightAsset.title} image={getImage(topRightAsset.gatsbyImageData)}/>
        </div>
        <div className="gif__container">
          <video autoPlay playsInline loop muted poster={paintBlastVidPoster}>
            <source src={bottomRightAsset.url} type="video/mp4" />
          </video>
        </div>
      </div>
    </ImagePanelWrapper>
  )
}

export default ImagePanel