import React from 'react'
import styled from 'styled-components';
import { navigate } from 'gatsby'
import Axios from 'axios';

class Geolocation extends React.Component {
  constructor(props){
    super();
    this.state={
      loading: true,
      nearAtlanta: false,
      nearBrooklyn: false,
      nearDc: false,
    }

    this.apiRequest = this.apiRequest.bind(this);
  }

  componentDidMount() {
    if(typeof window !== "undefined"){
      var re = new RegExp([/bot/, /spider/, /crawl/].map((r)=>r.source).join("|"), 'i');
      var userAgent = navigator.userAgent; 
      if (re.test(userAgent)) {
        window.sessionStorage.setItem("loading", false);
      }else if(window.sessionStorage.getItem("loading") === "false" ){

      }
      else{
        this.apiRequest();
      }
    }
  }

  apiRequest() {
    const newState = {
      loading: false,
    };

    if(typeof window !== "undefined"){
      var location_timeout = setTimeout(()=>{
        console.log("loading timed out...defaulting to generic home page")
        navigate('/')
        window.sessionStorage.setItem("origin", "/");
      }, 5000);

      function toRadians(degree){
        return (Math.PI/180)*degree
      }

      function calcCrow(lat1, lon1, coord){
        const R = 3956; // miles

        lat1 = toRadians(lat1);
        lon1 = toRadians(lon1);
        const lat2 = toRadians(coord[0]);
        const lon2 = toRadians(coord[1]);
        
        const dlong = lon2-lon1;
        const dlat = lat2-lat1;

        const ans = Math.pow(Math.sin(dlat/2),2) + Math.cos(lat1)*Math.cos(lat2)* Math.pow(Math.sin(dlong/2), 2);
        const c = 2*Math.asin(Math.sqrt(ans));
        const d = R*c;

        return (d<=100);
      }

      Axios.get('https://ipapi.co/json/').then((res) => {
        clearTimeout(location_timeout);
        const myLat = res.data.latitude
        const myLong = res.data.longitude
        const brooklyn_coord = [40.703210, -73.983960]
        const atlanta_coord = [33.808920, -84.435630]
        const dc_coord = [38.915545, -76.983377]
        this.setState({ ...newState, 
          nearBrooklyn: calcCrow(myLat, myLong, brooklyn_coord), 
          nearAtlanta: calcCrow(myLat, myLong, atlanta_coord),
          nearDc: calcCrow(myLat, myLong, dc_coord)
      });

        if(this.state.nearAtlanta){
          navigate('/atlanta')
          window.sessionStorage.setItem("origin", "/atlanta");
          window.sessionStorage.setItem("loading", false);
        }else if(this.state.nearBrooklyn){
          navigate('/brooklyn')
          window.sessionStorage.setItem("origin", "/brooklyn");
          window.sessionStorage.setItem("loading", false);
        }else if(this.state.nearDc){
          navigate('/dc')
          window.sessionStorage.setItem("origin", "/dc");
          window.sessionStorage.setItem("loading", false);
        }else{
          // const loadingWrapper = document.getElementById("loading_screen");
          // loadingWrapper.style.display = "none";
          window.sessionStorage.setItem("origin", "/");
          window.sessionStorage.setItem("loading", false);
        }
      })
      .catch(error =>{
        console.error("\n\n error \n\n", error);
        this.setState({ ...newState, nearBrooklyn: false, nearAtlanta: false, nearDc: false})
        window.sessionStorage.setItem("origin", "/");
      }) 
    }       
  }

  render(){
    const MainWrapper = styled.div`
      display:flex;
      height: 100vh;
      width:100vw;
      justify-content: center;
      align-items: center;
      position: absolute;
      background: #000000;
      top: 0;
      left: 0;
      z-index:999;
      
      .loading {
        color: white;
        font-family: "Pixel", sans-serif;
        text-transform: uppercase;
        font-size: 120px;
        animation: loading 2s linear infinite;

        @media only screen and (max-width: 1250px){
          font-size: 110px;
        }

        @media only screen and (max-width: 1024px){
          font-size: 90px;
        }

        @media only screen and (max-width: 768px){
          font-size: 50px;
        }

        @media only screen and (max-width: 500px){
          font-size: 30px;
        }
      }

      @keyframes loading {
        0% {
          opacity: 1;
        }
        50% {
          opacity: 0.2;
        }
        100% {
          opacity: 1;
        }
      }
    `
    const getLoading = () => {
      if(typeof window !== "undefined"){
        return window.sessionStorage.getItem("loading");
      }
    }

    return ( getLoading() !== undefined ) ?
      <></>
      :
      (<MainWrapper id='loading_screen'>
        <p className='loading'>LOADING...</p>
      </MainWrapper>)
  }
}

export default Geolocation