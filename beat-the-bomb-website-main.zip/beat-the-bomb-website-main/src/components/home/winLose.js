import React from 'react'
import styled from 'styled-components'
import paintPoster from "../../assets/images/winlose/paintBlast.jpeg"
import paintBlastVidPoster from "../../assets/images/winlose/winLose_poster1.png"
import proLeaguePoster from "../../assets/images/winlose/winLose_poster2.png"

const WinLoseWrapper = styled.div`
  margin-bottom: 5rem;

  .bookButton{
    position:relative;
    left:50%;
    transform: translateX(-50%);

    @media only screen and (max-width:425px){
      width:80%;
    }
  }

`

const WinLoseInnerWrapper = styled.div`
  max-width: 1920px;
  margin: 3rem 0 1rem 0;

  @media only screen and (min-width: 1920px){
    position:relative;
    left:50%;
    transform:translateX(-50%);
  }
`

const WinLoseContent = styled.div`
  display: grid;
  grid-template-columns: repeat(2,1fr);
  grid-gap: 100px;
  align-items: center;
  padding: 0 60px;

  &:nth-child(2n) .winloseText{
    order:1;
  }
  &:nth-child(2n) .videoContainer{
    order:2;
  }

  &:nth-child(2n+1) .winloseText{
    order:2;
  }
  &:nth-child(2n+1) .videoContainer{
    order:1;
  }

  .winloseText p{
    font-family: 'Acumin-Pro';
    font-size: 40px;
    line-height: 125%;
    letter-spacing: .065em;
    color: #fff;
    text-align: center;
  }

  .videoContainer video{
    max-height: 550px;
    width: auto;
    margin: 0 auto;
    max-width: 100%;
  }

  @media only screen and (max-width: 1024px){
    .winloseText p{
      font-size: 30px;
    }
  }

  @media only screen and (max-width: 768px){
    display:flex;
    flex-direction: column;
    grid-gap: 50px;
    padding: 0 20px;
    
    .winloseText{
      margin-bottom: 2rem;
    }

    .winloseText p{
      font-size: 22px;
    }

    &:nth-child(n) .winloseText{
      order:2;
    }
    &:nth-child(n) .videoContainer{
      order:1;
    }

  }

  @media only screen and (max-width:500px){
    .winloseText{
      margin-bottom: 0;
    }

    .winloseText p{
      font-size: 18px;
    }
  }

`

const WinLose = ({ winlose }) => {
  const {headerTitle, assets, bodyTexts, buttonTexts } = winlose[0]
  return (
    <WinLoseWrapper>
      <div className="banner banner--normal banner--angle-2 banner--blue">
        <h2 data-aos="fade-right" data-aos-once="true">{headerTitle}</h2>
      </div>
      <WinLoseInnerWrapper>
        {bodyTexts.map((body, index)=>{
          return(
            <WinLoseContent key={index}>
              <div className="winloseText">
                <p>{body.body}</p>
              </div>
              <div className="videoContainer">
                {assets[index].title === "blast paint video" ?
                <video 
                  controls 
                  muted 
                  poster={paintPoster}
                  preload="none"
                >
                  <source src={assets[index].url} type="video/mp4" />
                </video>
                :
                
                <video autoPlay playsInline loop muted poster={assets[index].title === "paint" ? paintBlastVidPoster: proLeaguePoster}>
                  <source src={assets[index].url} type="video/mp4" />
                </video>
                }
              </div>
            </WinLoseContent>
          )
        })}
      </WinLoseInnerWrapper>
      
      <a className="button button--pink button--text-black bookButton button--xola" href="https://checkout.xola.com/index.html#buttons/61703987a2d9f8052c6bb522">{buttonTexts[0].button}</a>
    </WinLoseWrapper>
  )
}

export default WinLose