import React from 'react'
import styled from 'styled-components'

import { GatsbyImage, getImage } from 'gatsby-plugin-image'

const ArcadeWrapper = styled.div`
  margin-bottom: 5rem;
`

const ArcadeInnerWrapper = styled.div`
  max-width: 1920px;
  margin: 3rem 0;

  @media only screen and (min-width: 1920px){
    position:relative;
    left:50%;
    transform:translateX(-50%);
  }
`

const OuterLayout = styled.div`
  display: grid;
  grid-template-columns: repeat(2,1fr);
  grid-gap: 100px;
  align-items: center;
  padding: 0 60px;

  @media only screen and (max-width: 768px){
    display: flex;
    flex-direction: column;
    padding: 0 30px;
    grid-gap: 50px;
  }

`

const RightCol = styled.div`
  display:flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  height:100%;

  .rightColImg{
    width:30%;
  }

  .strong_description{
    font-family: 'Acumin-Pro-700';
    font-style: normal;
    font-weight: 700;
    font-size: 48px;
    line-height: 125%;
    text-align: center;
    letter-spacing: .065em;
    color: #fff;

    @media only screen and (max-width: 1024px){
      font-size: 30px;
    }
    @media only screen and (max-width: 768px){
      margin: 0.5rem 0 2rem 0;
    }
  }

  .norm_description{
    font-family: 'Acumin-Pro';
    font-style: normal;
    line-height: 125%;
    text-align: center;
    letter-spacing: .065em;
    color: #fff;
    font-weight: 400;
    font-size: 40px;

    & > span{
      color: var(--neon-blue);
    }

    @media only screen and (max-width: 1024px){
      font-size: 20px;
    }

    @media only screen and (max-width: 768px){
      margin: 2rem 0;
    }
  }

  .divider{
    border-top: 1px solid var(--neon-blue);
    width: 60%;
  }
`

const Arcade = ({ arcade }) => {
  const { headerTitle, assets, bodyTexts } = arcade[0]
  const arcadeImg = assets.filter(asset => asset.title === "arcade img")
  const controller = assets.filter(asset => asset.title === "game controller")
  return (
    <ArcadeWrapper>
      <div className="banner banner--normal banner--angle-2 banner--blue">
        <h2 data-aos="fade-right" data-aos-once="true">{headerTitle}</h2>
      </div>
      <ArcadeInnerWrapper>
        <OuterLayout>
          <GatsbyImage alt={arcadeImg[0].title} image={getImage(arcadeImg[0].gatsbyImageData)} />
          <RightCol>
            <GatsbyImage className="rightColImg" alt={controller[0].title} image={getImage(controller[0].gatsbyImageData)} />
            <p className="strong_description"><strong>{bodyTexts[0].body}</strong></p>
            <p className="norm_description">Currently <span>FREE</span> on a first come first serve basis.</p>
            <div className="divider"></div>
            <p className="norm_description">{bodyTexts[1].body}</p>
          </RightCol>
        </OuterLayout>

      </ArcadeInnerWrapper>
    </ArcadeWrapper>
  )
}

export default Arcade