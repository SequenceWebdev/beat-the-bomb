import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from 'styled-components'
import TikTok from './tiktok'
import StarContainer from '../starContainer'
import { FcGoogle } from 'react-icons/fc'
import { FaTripadvisor } from 'react-icons/fa'

const ReviewWrapper = styled.div`
  margin-bottom: 5rem;
  
`

const ReviewInnerWrapper = styled.div`
  padding: 0px 30px;
  max-width: 1920px;

  & .grid__layout{
    display:flex;
    align-items: center;
    margin-bottom: 3rem;
  }

  & .grid2__layout{
    display: grid;
    grid-template-columns: repeat(3,1fr);
    grid-gap: 60px;
    padding: 0 80px;
    /* align-items: center; */

    
  }

  @media screen and (max-width: 1024px) {
    padding: 0 20px;

    & .grid2__layout {
      grid-gap: 20px;
      padding: 0 1rem;
    }
  }

  @media screen and (max-width: 768px) {
    & .grid__layout {
      flex-direction: column;
    }

    & .grid2__layout {
      display: flex;
      align-items: center;
      flex-direction: column;
    }
  }

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }

`

const ReviewPanel = styled.div`
  width: 50%;
  text-align: center;

  & h3{
    font-family: "Pixel", monospace;
    font-style: normal;
    font-weight: normal;
    font-size: 80px;
    line-height: 59px;
    text-align: center;
    color: #FFFFFF;
    margin-bottom: 1rem;

    @media (max-width:1440px) and (min-width: 501px){
      font-size: 50px;
      
    }
  }

  .reviewPanel__review_text_container{
    @media only screen and (min-width: 769px){
      margin: 1rem 0 5rem 0;
      
    }
  }

  
  @media only screen and (max-width: 768px){
    width:100% 
    
  }

  @media only screen and (max-width: 500px){
    & h3{
      font-size: 30px;
    }  
    
  }
`

const ReviewIcons = styled.div`
  display: grid;
  grid-template-columns: repeat(2,1fr);
  grid-gap: 40px;
  align-items: center;
  padding: 0 30px;
  margin-top:1rem;

  & .logo_img:hover{
    opacity: 0.7;
  }

  @media only screen and (max-width: 768px){
    padding: 0 80px;
  }
`

// const ReviewTestimonial = styled.div`
//   display: flex;
//   flex-direction: column;
//   align-items: center;
//   position: relative;
//   justify-content: space-evenly;
//   background-color: #ffffff;
//   border-radius: 35px;
//   padding: 20px 60px 20px 60px;
  
//   p{
//     font-family: 'Acumin-Pro';
//     font-size: 23px;
//     line-height: 30px;
//     color: #000000;
//     text-align: center;
    
//   }

//   @media only screen and (max-width: 500px) {
//     padding: 20px;
//     p{
//       font-size: 16px;
      
//     }
//   }

// `

const ReviewTestimonial = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  position: relative;
  justify-content: space-evenly;
  font-family: 'Acumin-Pro';
  font-size: 23px;
  line-height: 30px;
  color: #000000;
  text-align: center;
  background-color: #ffffff;
  border-radius: 35px;
  padding: 20px 60px 20px 60px;

  @media only screen and (max-width: 1250px) {
    padding: 20px;
    
  }

  @media only screen and (max-width: 900px) {
    font-size: 20px;
    padding-top: 30px;
  }

  @media only screen and (max-width: 768px) {
    padding: 10px;
    padding-top: 20px;
  }
`

const BigStarContainer = styled.div`
  display: inline-flex;
  justify-content: center;
  align-items: center;

  .bigStarImg{
    width: 60px;
    aspect-ratio: 1;

    @media only screen and (max-width: 1250px){
      width: 50px;
    }
    @media only screen and (max-width: 900px){
      width: 40px;
    }

    @media only screen and (max-width: 500px){
      width: 30px;
    }

  }
`


const Reviews = ( { reviews } ) => {
  const { headerTitle, assets, reviewTestimonials, bodyTexts } = reviews[0]
  const tiktokVideo = assets.filter(asset => asset.title==="TikTok Video")

  const tiktokBadge = assets.filter(asset => asset.title==="tiktok badge")
  const tiktokPlay = assets.filter(asset => asset.title==="tiktok play icon")
  const tiktokPause = assets.filter(asset => asset.title==="tiktok pause icon")
  const tiktokReplies = assets.filter(asset => asset.title==="tiktok replies icon")
  const tiktokLikes = assets.filter(asset => asset.title==="tiktok likes icon")
  const tiktokComments = assets.filter(asset => asset.title==="tiktok comments icon")
  const tiktokAssets ={ tiktokVideo, tiktokBadge, tiktokPlay, tiktokPause, tiktokReplies, tiktokLikes, tiktokComments }

  const fullStar = assets.filter(asset => asset.title==="star")

  const tripadvisor = assets.filter(asset => asset.title==="tripadvisor logo")
  // const yelp = assets.filter(asset => asset.title==="yelp logo")
  // const facebook = assets.filter(asset => asset.title==="facebook logo")
  const google = assets.filter(asset => asset.title==="google logo")
  const logos = [tripadvisor, google]

  return (
    <ReviewWrapper>
      <div className="banner banner--normal banner--angle-2 banner--blue">
        <h2 data-aos="fade-right" data-aos-once="true">
          {headerTitle}
        </h2>
      </div>
      <ReviewInnerWrapper>
        <div className="grid__layout">
          <TikTok assets={tiktokAssets}/>
          <ReviewPanel>
            <h3>{bodyTexts[0].body}</h3>
            <BigStarContainer>
              <GatsbyImage alt="stars" className="bigStarImg" image={getImage(fullStar[0].gatsbyImageData)}/>
              <GatsbyImage alt="stars" className="bigStarImg" image={getImage(fullStar[0].gatsbyImageData)}/>
              <GatsbyImage alt="stars" className="bigStarImg" image={getImage(fullStar[0].gatsbyImageData)}/>
              <GatsbyImage alt="stars" className="bigStarImg" image={getImage(fullStar[0].gatsbyImageData)}/>
              <GatsbyImage alt="stars" className="bigStarImg" image={getImage(fullStar[0].gatsbyImageData)}/>
            </BigStarContainer>
            <h3 className="reviewPanel__review_text_container">{bodyTexts[1].body}</h3>
            <ReviewIcons>
              {logos.map((logo, index)=>{
                const { title, description, gatsbyImageData} = logo[0]
                return(
                  
                  <a key={index} href={description}>
                    <GatsbyImage alt={title} className="logo_img" image={getImage(gatsbyImageData)} />
                  </a>
                )
              })}
            </ReviewIcons>
          </ReviewPanel>
        </div>
        <div className="grid2__layout">
          {reviewTestimonials.references.map((testimonial, index) =>{
            const {name, review, logo} = testimonial
            const review_text = review.review
            return(
            <ReviewTestimonial key={index}>
              <StarContainer star={fullStar[0].gatsbyImageData} />
              <br></br>
              <p>{review_text}</p>
              <p>{name}</p>
              { logo === "Google" ? <FcGoogle /> : <FaTripadvisor />}
              
            </ReviewTestimonial>
            )
          })}

        </div>
      </ReviewInnerWrapper>
    </ReviewWrapper>
  )
}

export default Reviews