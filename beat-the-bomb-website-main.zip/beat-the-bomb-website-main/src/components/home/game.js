import React from 'react'
import styled from 'styled-components'
import { GatsbyImage, getImage } from 'gatsby-plugin-image'

const GameWrapper = styled.div`
  display:flex;
  flex-direction: column;
  align-items: center;

  & .modal_mission_title{
    font-family: "Pixel", monospace;
    font-style: italic;
    font-size: 85px;
    text-align: center;

    @media only screen and (max-width: 768px){
      font-size: 60px;
      padding: 1rem 0;
    }

    @media only screen and (max-width: 500px){
      font-size: 40px;
    }
  }

  .modal_mission_descrip{
    font-family: 'Acumin-Pro';
    font-style: normal;
    font-weight: 700;
    font-size: 45px;
    line-height: 60px;
    /* or 133% */
    color: #ffffff;
    text-align: center;
    letter-spacing: 0.065em;

    @media screen and (max-width: 1024px) {
      font-size: 32px;
    }

    @media screen and (max-width: 768px) {
      font-size: 24px;
      padding: 0 1rem;
      line-height: normal;
    }

    @media screen and (max-width: 500px) {
      font-size: 20px;

    }
  }

  .button{
    margin-top: 3rem;
    font-family: 'Acumin-Pro-700';
    font-style: italic;
    font-weight: 700;
    padding-top:17px;
    padding-left: 0;
    padding-right: 0;
    width:29%;

    @media only screen and (max-width:1250px){
      font-size: 30px;
      line-height: normal;
      
    }


    @media only screen and (max-width:1024px){
      font-size: 25px;
    }

    @media only screen and (max-width:768px){
      font-size: 15px;
      padding: 13px 20px 10px 20px;
      margin-top:1rem;
      margin-bottom: 3rem;
      width:45%;
    }
  }
`

const GameInfo = styled.div`
  display:flex;
  width:100%;
  justify-content: space-around;
  align-items: center;
  column-gap: 25px;

  .leftCol{
    display:flex;
    width: 50%;
    align-items: center;
    flex-direction: column;

    & .game_description {
      font-family: 'Acumin-Pro-L';
      font-style: normal;
      font-weight: 400;
      font-size: 32px;
      line-height: 125%;
      /* or 40px */
      color: #ffffff;
      text-align: center;
      padding:0;

      @media only screen and (max-width: 1250px) {
        font-size: 25px;
      }

      @media only screen and (max-width: 1024px) {
        font-size: 20px;
      }

      @media only screen and (max-width: 768px) {
        font-size: 18px;
      }

      @media only screen and (max-width: 500px) {
        font-size: 16px;
      }
    }
  }

  .rightCol{
    width:50%;
    display:flex;
    align-items: center;
    justify-content: center;
  }

  @media screen and (max-width: 768px){
    flex-direction: column;

    .leftCol{
      order:2;
      width: 100%;
      margin-bottom: 2rem;

      & .game_description{
        font-size: 20px;
        margin:0;
      }
    }

    .rightCol{
      width:100%;
    }
  }

`

const Game = ({ games, missionTitle, missionDescription, url }) => {
  return (
    <GameWrapper>
      <h2 className='modal_mission_title'>{missionTitle}</h2>
      <p className='modal_mission_descrip'>{missionDescription[0].text}</p>
      <a className="button button--large button--pink button--text-white" href={url}>Book Now</a>
      {games.references.map((game, index) => {
            const { name, gameDescription, gameMissionImageAssets } = game
            const leftImage = gameMissionImageAssets[0]
            const rightImage = gameMissionImageAssets[1]
            return(
              <GameInfo key={index}>
                <div className="leftCol">
                  <GatsbyImage alt={name} image={getImage(leftImage)} />
                  <p className="game_description">{gameDescription.gameDescription}</p>
                </div>
                <div className="rightCol">
                  <GatsbyImage alt={name} image={getImage(rightImage)} />
                </div>
              </GameInfo>
            )
          })}
    </GameWrapper>
  )
}

export default Game