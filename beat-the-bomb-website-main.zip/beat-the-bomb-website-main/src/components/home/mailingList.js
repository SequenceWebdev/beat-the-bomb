import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from 'styled-components'
import EmailListForm from '../forms/emailListForm'

const MailingListWrapper = styled.div`
  margin-bottom: 5rem;
  display:flex;
  justify-content: center;
  align-items: center;

`

const MailingListInnerWrapper = styled.div`
  max-width: 1200px;
  margin-bottom: 3rem;
  position: relative;


  .mailingList__text{
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:100%;

    padding: 3rem;
    display:flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;

    @media only screen and (max-width: 768px){
      padding: 1rem 5px;
    }
  }
  

  .mailing__header{
    color: #fff;
    font-family: "Pixel",monospace;
    z-index: 11;
    text-align: center;
    width:100%;

    @media only screen and (max-width: 500px){
      font-size: 22px;
    }
  }

  .mailing__body{
    max-width: 500px;
    padding: 30px;
    margin: auto;
    font-family: 'Acumin-Pro',sans-serif;
    font-style: normal;
    font-weight: 200;
    font-size: 27px;
    line-height: 32px;
    text-align: center;
    color: #fff;
    z-index: 11;

    @media only screen and (max-width: 768px){
      padding: 0;
      font-size: 18px;
    }

    @media only screen and (max-width: 500px){
      font-size: 15px;
    }
  }

  .mailing__form_container{
    z-index: 11;
    width:100%;


    @media only screen and (max-width: 768px){
      width:75%;
    }
  }
  
`
const BackgroundImage = styled.div`
  position: relative;

  .bgImg{
    z-index: 2;
  }

  .overlay{
    position: absolute;
    z-index: 10;
    background: linear-gradient(to bottom, rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6));
    width:100%;
    height:100%;
    top:0;
    left:0;
  }
`

const MailingList = ({ mailingList }) => {
  const { headerTitle, assets, bodyTexts } = mailingList[0]
  return (
    <MailingListWrapper>
      <MailingListInnerWrapper>
      
        <BackgroundImage>
          <GatsbyImage alt="background image" className="bgImg" image={getImage(assets[0].gatsbyImageData)} />
          <div className="overlay"></div>
        </BackgroundImage>

        <div className="mailingList__text">
          <h3 className="mailing__header">{headerTitle}</h3>
          <p className="mailing__body">{bodyTexts[0].body}</p>
          <div className="mailing__form_container">
            <EmailListForm/>
          </div>
        </div>        
        
        
        

      </MailingListInnerWrapper>
    </MailingListWrapper>
  )
}

export default MailingList