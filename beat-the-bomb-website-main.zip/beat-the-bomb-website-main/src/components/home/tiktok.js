import React, { Component } from 'react'
import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import styled from 'styled-components'

import { BsFillPlayFill } from "react-icons/bs";
import {IoHeartCircle, IoArrowRedoCircleSharp} from "react-icons/io5";
import poster from '../../assets/images/tiktok_poster.jpg'
import { Player, BigPlayButton } from 'video-react';

const TikTokWrapper = styled.div`
  position: relative;
  padding: 80px 80px 2rem 80px;
  grid-row: span 2;
  width:50%;

  @media only screen and (max-width: 768px) {
    width:100%;
    /* padding: 80px 80px 0 80px; */
  }

  @media only screen and (max-width: 500px) {
    padding: 30px 30px 1rem 30px;
  }

`

const TikTokContainer = styled.div`
  position:relative;
  
  .play_icon_overlay{
    position: absolute;
    /* width:10%;
    height:5%; */
    left:0;
    bottom:3%;
  }

  .play_icon_container{
    position:absolute;
    left:0;
    bottom:0;
    display:flex;
    justify-content: center;
    align-items: flex-start;

    p{
      font-family: 'Acumin-Pro-700';
      font-style: normal;
      font-weight: 700;
      font-size: 32px;

      text-align: center;
      letter-spacing: 0.03em;

      color: #FFFFFF;

      @media only screen and (max-width: 1024px){
        font-size: 25px;
      }

      @media only screen and (max-width: 500px){
        font-size: 16px;
      }
    }
  }

  .play{
    color: #fff;
    font-size: 50px;

    @media only screen and (max-width: 1024px){
      font-size: 30px;
    }

    @media only screen and (max-width: 500px){
      font-size: 20px;
    }
  }
`

const Icons = styled.div`
  position: absolute;
  top:45%;
  right: -5%;
  display: flex;
  flex-direction: column;
  align-items: center;

  & p {
    font-size: 30px;
    font-family: "Montserrat",sans-serif;
    text-align: center;
    font-size: 30px;
    text-transform: uppercase;
    font-weight: 600;
    letter-spacing: .065em;
    color: white;
  }

  & .likes, & .comments, & .replies{
    display:flex;
    flex-direction: column;
    align-items: center;
    width: 80px;
  }

  .tiktok_reactIcon{
    font-size:95px;
    color:white;
  }

  @media only screen and (max-width: 1250px) {
    /* top:30%; */
    right: -10%;
    & p{
      font-size:25px;
    }

    & .likes, & .comments, & .replies{
      width: 60px;
    }

    .tiktok_reactIcon{
      font-size:75px;
      
    }
  }

  @media only screen and (max-width: 1024px){
    top:35%;
    
    & p{
      font-size:20px;
    }

    & .likes, & .comments, & .replies{
      width: 42px;
    }

    .tiktok_reactIcon{
      font-size:49px;
      
    }
  }

  @media only screen and (max-width: 768px){
    & p{
      font-size:20px;
    }

    & .likes, & .comments, & .replies{
      width: 37px;
    }

    .tiktok_reactIcon{
      font-size:45px;
      
    }
  }

  @media only screen and (max-width: 500px){
    & p{
      font-size:16px;
    }

    & .likes, & .comments, & .replies{
      width: 30px;
    }

    .tiktok_reactIcon{
      font-size:38px;
      
    }
  }
`

const Badge = styled.div`
  position: absolute;
  top:5%;
  left: 5%;
  width: 320px;

  @media only screen and (max-width: 1024px){
    width: 200px;
  }

  @media only screen and (max-width: 768px){
    width: 250px;
  }

  @media only screen and (max-width: 500px){
    top:0;
    left:0;
    width:180px;
  }

`

class TikTok extends Component {

  render() {
    const tiktokVideo = this.props.assets.tiktokVideo
    const tiktokBadge = this.props.assets.tiktokBadge
    const tiktokComments = this.props.assets.tiktokComments
    
    return (
      <TikTokWrapper>
        
        <TikTokContainer>
          <Player src={tiktokVideo[0].url} muted autoPlay poster={poster} preload="auto">
            <BigPlayButton position="center" />
          </Player>
          <div className="play_icon_overlay">
            <div className="play_icon_container">
              <BsFillPlayFill className="play"/>
              <p>2.9M</p>
            </div>
          </div>
          
          <Icons>
            <div className="likes">
              {/* <GatsbyImage alt={tiktokLikes[0].title} placeholder="tracedSVG" image={getImage(tiktokLikes[0].gatsbyImageData)} /> */}
              <IoHeartCircle className="tiktok_reactIcon"/>
              <p>610.7K</p>
            </div>
            <div className="comments">
              <GatsbyImage alt={tiktokComments[0].title} placeholder="tracedSVG" image={getImage(tiktokComments[0].gatsbyImageData)} />
              <p>9017</p>
            </div>
            <div className="replies">
              {/* <GatsbyImage alt={tiktokReplies[0].title} placeholder="tracedSVG" image={getImage(tiktokReplies[0].gatsbyImageData)} /> */}
              <IoArrowRedoCircleSharp className="tiktok_reactIcon"/>
              <p>88.6K</p>
            </div>
          </Icons>
          
        </TikTokContainer>
        <Badge>
          <GatsbyImage alt={tiktokBadge[0].title} placeholder="tracedSVG" image={getImage(tiktokBadge[0].gatsbyImageData)} />
        </Badge>        
      </TikTokWrapper>
    )}
}

export default TikTok