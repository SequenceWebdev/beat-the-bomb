import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from 'styled-components'

import 'react-responsive-modal/styles.css';
import '../styles/modal.css'
import { Modal } from 'react-responsive-modal';

import {AiOutlineClose} from 'react-icons/ai'

const BeveragesWrapper = styled.div`
  margin-bottom: 5rem;
`

const BeveragesInnerWrapper = styled.div`
  max-width: 1920px;
  margin: 3rem 0;

  @media only screen and (min-width: 1920px){
    position:relative;
    left:50%;
    transform:translateX(-50%);
  }

`

const BeverageImages = styled.div`
  display: grid;
  grid-template-columns: repeat(2,1fr);
  row-gap: 20px;
  column-gap: 20px;
  align-items: center;
  padding: 0 60px;

  @media only screen and (max-width: 768px) {
    display:flex;
    padding: 0 20px;
    flex-direction: column;
  }
`

const BeverageContent = styled.div`
  text-align: center;
  padding: 0 60px;

  .button--desktop{
    @media only screen and (max-width:768px){
      display: none;
    }
  }

  .button--mobile{
    @media only screen and (min-width:769px){
      display: none;
    }
  }

  .bodyText {
    font-family: 'Acumin-Pro';
    font-style: normal;
    font-weight: 400;
    font-size: 40px;
    color: #ffffff;
    text-align: center;
    letter-spacing: 0.065em;
    margin: 2rem 0 3rem 0;

    & > a{
      color: var(--neon-blue);
    }

    & > a:hover{
      color: #ffffff;
    }
  }

  @media only screen and (max-width:768px){
    padding: 0 20px;
    
    .bodyText{
      font-size:22px;
    }  
  }

  @media only screen and (max-width:500px){   
    .bodyText{
      font-size:18px;
    }  
  }
`

const Beverages = ({ beverages }) => {
  const {headerTitle, assets, bodyTexts, buttonTexts } = beverages[0]
  const bombbar = assets.filter(asset => asset.title==="bombbar")
  const bombbar_mobile = assets.filter(asset => asset.title==="bombbar_mobile")

  const [openFirst, setOpenFirst] = React.useState(false);
  const [openSecond, setOpenSecond] = React.useState(false);

  const closeIcon = (<AiOutlineClose color='white' size={36} />);

  return (
    <BeveragesWrapper>
      <div className="banner banner--normal banner--angle-1 banner--pink">
        <h2 data-aos="fade-right" data-aos-once="true">{headerTitle}</h2>
      </div>
      <BeveragesInnerWrapper>
        <BeverageImages>
          {assets.map((image, index)=>{
            return(
              (image.title==="bombbar")||(image.title==="bombbar_mobile") ? <></> : <GatsbyImage key={index} alt={image.title} image={getImage(image.gatsbyImageData)} />
            )
          })}
        </BeverageImages>
        <BeverageContent>
          <p className="bodyText">{bodyTexts[0].body}</p>
          <p className="bodyText">{bodyTexts[1].body}</p>
          <button type="button" className="button button--blue button--text-black button--desktop" onClick={() => setOpenFirst(true)}>{buttonTexts[0].button}</button>
          <button type="button" className="button button--blue button--text-black button--mobile" onClick={() => setOpenSecond(true)}>{buttonTexts[0].button}</button>
          <p className="bodyText">Reach out to <a href="mailto:groupsales@beatthebomb.com">groupsales@beatthebomb.com</a> to plan a celebration or corporate team building event. We have an awesome private party space, drinks packages and catering.</p>
        </BeverageContent>

        <Modal 
          open={openFirst} 
          onClose={() => setOpenFirst(false)}
          center 
          showCloseIcon
          classNames={{
            overlay: 'customOverlay',
            modal: 'customModal',
          }}
          closeIcon={closeIcon}
        >
          <GatsbyImage alt={bombbar[0].title} className="menu__desktop" image={getImage(bombbar[0].gatsbyImageData)} />
        </Modal>

        <Modal 
          open={openSecond}
          onClose={() => setOpenSecond(false)}
          center 
          showCloseIcon
          classNames={{
            overlay: 'customOverlay',
            modal: 'customModal',
          }}
          closeIcon={closeIcon}
        >
          <GatsbyImage alt={bombbar_mobile[0].title} className="menu__mobile" image={getImage(bombbar_mobile[0].gatsbyImageData)} />
        </Modal>

      </BeveragesInnerWrapper>
    </BeveragesWrapper>
  )
}

export default Beverages