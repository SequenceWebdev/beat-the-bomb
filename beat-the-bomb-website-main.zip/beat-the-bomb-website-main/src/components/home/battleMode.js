import React from 'react'
import styled from 'styled-components'

import { Carousel } from "react-bootstrap";
import { GatsbyImage, getImage } from 'gatsby-plugin-image';
import battleModePoster from "../../assets/images/battleMode/battleMode_poster.png"

const BattleModeWrapper = styled.div`
  margin-bottom: 5rem;
  .bookButton{
    position:relative;
    left:50%;
    transform: translateX(-50%);
  }
`
const BattleModeInner = styled.div`
  max-width: 1920px;
  margin-bottom: 3rem;
  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }
`

const GifPlayer = styled.div`
  display: grid;
  grid-template-columns: repeat(2,1fr);
  grid-gap: 100px;
  align-items: center;
  padding: 0 60px;
  .battleText p{
    font-family: 'Acumin-Pro';
    font-size: 45px;
    line-height: 125%;
    letter-spacing: .065em;
    color: #fff;
    text-align: center;

    @media only screen and (max-width:1024px){
      font-size: 30px;
    }

    @media only screen and (max-width:768px){
      font-size: 22px;
    }

    @media only screen and (max-width:500px){
      font-size: 18px;
    }
  }
  .videoContainer video{
    max-height: 550px;
    width: auto;
    margin: 0 auto;
    max-width: 100%;
  }
  @media only screen and (max-width: 768px){
    display:flex;
    align-items: center;
    flex-direction: column;
    margin: 2rem 0;
    grid-gap: 50px;
    padding: 0 20px;
    
    .videoContainer{
      order:1;
    }
    .battleText{
      order:2;
    }
  }
`

const ImageCarousel = styled.div`
  display: grid;
  grid-template-columns: repeat(2,1fr);
  grid-gap: 100px;
  align-items: center;
  padding: 0 60px;
  .sliderImg{
    max-height: 550px;
    width: auto;
    margin: 0 auto;
    max-width: 100%;
  }
  .battleText p{
    font-family: 'Acumin-Pro';
    font-size: 45px;
    line-height: 125%;
    letter-spacing: .065em;
    color: #fff;
    text-align: center;

    @media only screen and (max-width:1024px){
      font-size: 30px;
    }

    @media only screen and (max-width:768px){
      font-size: 22px;
    }

    @media only screen and (max-width:500px){
      font-size: 18px;
    }
  }
  @media only screen and (max-width: 768px){
    display:flex;
    align-items: center;
    flex-direction: column;
    grid-gap: 50px;
    padding: 0 20px;
    .battleText{
      order:2;
    }
  }
`

const BattleMode = ({ battleMode }) => {
  const {headerTitle, assets, bodyTexts, buttonTexts} = battleMode[0]
  const carouselImages = [assets[1], assets[2]]
  const battleGif = assets[0]

  return (
    <BattleModeWrapper>
      <div className="banner banner--normal banner--angle-1 banner--pink">
        <h2 data-aos="fade-right" data-aos-once="true">{headerTitle}</h2>
      </div>
      <BattleModeInner>
        {bodyTexts.map((body, index) =>{
          const body_text = body.body
          return (
            (index === 0) ? 
            <GifPlayer key={index}>
              <div className="battleText">
                <p>{body_text}</p>
              </div>
              <div className="videoContainer">
                <video autoPlay playsInline loop muted poster={battleModePoster}>
                  <source src={battleGif.url} type="video/mp4" />
                </video>
              </div>
            </GifPlayer>
            :
            <ImageCarousel>
              <Carousel indicators={false} controls={false}>
                {carouselImages.map((image, index) =>{
                  return(
                    <Carousel.Item>
                      <GatsbyImage key={index} alt={image.title} image={getImage(image.gatsbyImageData)} />
                    </Carousel.Item>
                  )
                })}
              </Carousel>
              <div className="battleText">
                <p>{body_text}</p>
              </div>
            </ImageCarousel>
          )
        })}
      </BattleModeInner>
      <a className="button button--pink button--text-black bookButton button--xola" href="https://checkout.xola.com/index.html#buttons/61703987a2d9f8052c6bb522">{buttonTexts[0].button}</a>
    </BattleModeWrapper>
  )
}

export default BattleMode