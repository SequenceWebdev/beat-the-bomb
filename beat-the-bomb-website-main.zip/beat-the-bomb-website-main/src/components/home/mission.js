import React, { useState } from 'react'
import styled from 'styled-components'
import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import Game from './game';

import 'react-responsive-modal/styles.css';
import '../styles/modal.css'
import { Modal } from 'react-responsive-modal';

import {AiOutlineClose} from 'react-icons/ai'

const MissionWrapper = styled.div`
  margin-top: 15rem;
  position:relative;
  /* display:flex;
  align-items: center;
  flex-direction: column; */
  max-width:1086px;
  left:50%;
  transform:translateX(-50%);

  .title__container{
    background-color: #FFFFFF;
    height: 270px;
    width:80%
  }

  .mission_logo{
    width:83%;
    height:41%;
    position:absolute;
    left:0;
    top:0;
    z-index:1;
    transform: translateY(-63%);
  }

  .mission__container{
    max-width:1440px;
    display:flex;
    align-items:center;
    justify-content: center;
    border: 2px solid #FFFFFF;
    padding: 60px 20px 0px 20px;
    z-index:-1;

    @media only screen and (max-width:500px){
      padding: 20px 20px 0px 20px;
    }
  }

  .button{
    margin-top: 3rem;
    width:41%;
    font-family: 'Acumin-Pro-700';
    font-style: italic;
    position:relative;
    left:50%;
    transform: translate(-50%);
    margin-bottom: 5rem;
    padding-top:17px;

    @media only screen and (max-width:1024px){
      font-size: 25px;
      line-height: normal;
      
    }

    @media only screen and (max-width:768px){
      font-size: 15px;
      padding: 13px 20px 10px 20px;
      width:43%;
    }
  }

  @media only screen and (max-width:768px){
    margin-top:10rem;
  }

  @media only screen and (max-width:500px){
    margin-top:7rem;
  }
`

const Mission = ({ mission, buttonText }) => {
  const { gameMissionTitle, missionDescription, missionImages, missionGames, url } = mission
  const [open, setOpen] = useState(false);

  const onOpenModal = () => setOpen(true);
  const onCloseModal = () => setOpen(false);

  const closeIcon = (<AiOutlineClose color='white' size={36} />);

  return (
    <>
      <MissionWrapper>
        <GatsbyImage alt={missionImages[0].title} objectFit="contain" className="mission_logo" image={getImage(missionImages[0].gatsbyImageData)}/>
        <div className="mission__container">
          <GatsbyImage alt={gameMissionTitle.title} image={getImage(missionImages[1].gatsbyImageData)} />
        </div>
        <button type="button" className="button button--large button--blue button--text-white" onClick={onOpenModal}>{buttonText}</button>
      </MissionWrapper>
      <Modal 
      open={open} 
      onClose={onCloseModal} 
      center 
      showCloseIcon 
      classNames={{
          overlay: 'customOverlay',
          modal: 'customModal',
        }}
      closeIcon={closeIcon}>
        <Game games={missionGames} missionTitle={gameMissionTitle} missionDescription={missionDescription} url={url}/>
      </Modal>

    </>
  )
}

export default Mission