import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from 'styled-components'
import { FaInstagram } from 'react-icons/fa'

const SocialWrapper = styled.div`
  margin-bottom: 5rem;

`

const SocialInnerWrapper = styled.div`
  max-width: 1920px;
  margin-bottom: 3rem;

  display: grid;
  grid-template-columns: repeat(2,1fr);
  align-items: center;
  padding: 0 60px;

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }

  @media only screen and (max-width: 768px){
    display: flex;
    flex-direction: column;
    padding: 0 30px;
  }
`

const SocialDescription = styled.div`
  display:flex;
  justify-content: space-evenly;
  flex-direction: column;
  align-items:center;
  text-align: center;

  .socialIcon{
    color: #fff;
    font-size: 36px;
  }

  .headerInfo{
    color: #fff;
    font-family: "Pixel",monospace;
    font-size: 32px;
  }

  .socialTag{
    color: #fff;
    font-family: "Pixel",monospace;
  }

  .follow{
    width:50%;

    @media only screen and (max-width: 768px){
      width: 75%;
    }
  }

  @media only screen and (max-width: 768px){
    margin: 2rem 0;
  }

`


const Social = ({ social }) => {
  const { headerTitle, assets, bodyTexts, buttonTexts } = social[0]
  return (
    <SocialWrapper>
      <div className="banner banner--normal banner--angle-1 banner--pink">
        <h2 data-aos="fade-right" data-aos-once="true">{headerTitle}</h2>
      </div>
      <SocialInnerWrapper>
        <SocialDescription>
          <FaInstagram className="socialIcon"/>
          <h3 className="headerInfo">{bodyTexts[0].body}</h3>
          <p className="socialTag">{bodyTexts[1].body}</p>
          <a className="button button--blue button--text-black follow" href="https://www.instagram.com/beatthebomb/">{buttonTexts[0].button}</a>
        </SocialDescription>
        <GatsbyImage alt={assets[0].title} image={getImage(assets[0].gatsbyImageData)} />

      </SocialInnerWrapper>
    </SocialWrapper>
  )
}

export default Social