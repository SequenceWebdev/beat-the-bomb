import React from 'react';

import { Carousel } from "react-bootstrap";
import { GatsbyImage, getImage } from 'gatsby-plugin-image';
import styled from 'styled-components';

const HeroWrapper = styled.div`
  margin-bottom: 5rem;

  .banner h2{
    @media only screen and (max-width: 500px){
      font-size:30px;
    }
  }
`

const CarouselContainer = styled.div`
  position: relative;
  margin-bottom: 1rem;
  max-width: 1920px;
  
  .cItem{
    padding:0px 0px 50px 0px;
  }

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }
`

const BodyText = styled.div`
  max-width: 1920px;
  display:flex;
  align-items: center;
  flex-direction: column;

  .button{
    margin: 0.5rem 0 2rem 0;
  }

  p{
    margin: 10px auto;
    padding: 0 20px;
    font-family: 'Acumin-Pro';
    font-size: 40px;
    /* letter-spacing: -1.5px; */
    color: #fff;
    text-align: center;
  }

  @media only screen and (max-width: 768px) {
    p{
      font-size: 30px;
    }
  }

  @media only screen and (max-width: 500px) {
    p{
      font-size: 20px;
    }
  }

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }
  
`

const HeroCarousel = ({ heroCarousel }) => {
  const { headerTitle, assets, bodyTexts, buttonTexts } =heroCarousel[0]
  
  return (
    <HeroWrapper>
      <div className="banner banner--no-transition banner--normal banner--no-margin banner--no-transform banner--blue">
        <h2>
          {headerTitle}
        </h2>
      </div>
      <CarouselContainer>
        <Carousel controls={false}>
          <Carousel.Item interval={5000} className="cItem">
            <GatsbyImage loading="eager" imgStyle={{objectFit:"contain"}} image={getImage(assets[0].gatsbyImageData)} alt={assets[0].title}/>
          </Carousel.Item>
          <Carousel.Item interval={5000} className="cItem">
            <GatsbyImage loading="eager" imgStyle={{objectFit:"contain"}} image={getImage(assets[1].gatsbyImageData)} alt={assets[1].title}/>
          </Carousel.Item>
          <Carousel.Item interval={5000} className="cItem">
            <GatsbyImage loading="eager" imgStyle={{objectFit:"contain"}} image={getImage(assets[2].gatsbyImageData)} alt={assets[2].title}/>
          </Carousel.Item>
          <Carousel.Item interval={5000} className="cItem">
            <GatsbyImage loading="eager" imgStyle={{objectFit:"contain"}} image={getImage(assets[3].gatsbyImageData)} alt={assets[3].title}/>
          </Carousel.Item>
        </Carousel>
      </CarouselContainer>

      <BodyText>
        <a className="button button--large button--blue button--xola" href="https://checkout.xola.com/index.html#buttons/61703987a2d9f8052c6bb522">
            {buttonTexts[0].button}
        </a>
        
        {bodyTexts.map((text, index)=>{
          return(
            <p key={index}>{text.body}</p>
          )
        })}
      </BodyText>
      
    </HeroWrapper>
  )
}

export default HeroCarousel