import { GatsbyImage, getImage } from 'gatsby-plugin-image'
import React from 'react'
import styled from 'styled-components'

import Amenities from './amenities'
// import CompaniesScroller from '../companiesScroller'
import CompLogoScroller from '../compLogoScroller'

const PrivateEventWrapper = styled.div`
  margin-bottom: 5rem;

`

const PrivateEventInnerWrapper = styled.div`
  max-width: 1920px;

  .company__header{
    font-family: sans-serif;
    font-size: 46px;
    font-weight: 900;
    letter-spacing: 0.065em;
    text-transform: uppercase;
    padding: 0 2rem;
    color: #ffffff;
    text-align: center;

    @media screen and (max-width: 1024px) {
      font-size: 32px;
    }

    @media screen and (max-width: 768px) {
      font-size: 24px;
      padding: 0 1rem;
    }

    @media screen and (max-width: 500px) {
      font-size: 18px;

    }

  }
  
  .comp_logo_container{
    display:flex;
    align-items: center;
  }

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }
`

const ImageGallery = styled.div`
  display:grid;
  grid-template-columns: repeat(3,1fr);
  margin-bottom: 2rem;

  @media only screen and (max-width: 768px){
    display:flex;
    flex-direction: column;
    align-items: center;
  }
`

const PrivateEventButton = styled.div`
  margin-top:2rem;
  text-align: center;

  @media screen and (max-width: 500px) {
    & a{
      width: 70%;
    }
  }
`

const PrivateEvents = ({ privateEvents, amenities, companies }) => {
  const pe_Images = privateEvents[0].assets
  return (
    <PrivateEventWrapper>
      <div className="banner banner--normal banner--angle-1 banner--pink">
        <h2 data-aos="fade-right" data-aos-once="true">{privateEvents[0].headerTitle}</h2>
      </div>
      
      <PrivateEventInnerWrapper>
        <ImageGallery>
          {pe_Images.map((image, index) =>{
            return(
              <GatsbyImage alt={image.title} key={index} image={getImage(image.gatsbyImageData)}/>
            )
          })}
        </ImageGallery>
        <Amenities amenities={amenities} />
        <br></br>
        <h2 className='company__header'>{companies[0].headerTitle}</h2>
        {/* <CompaniesScroller companyLogos={companies}/> */}
        <div className="comp_logo_container">
          <CompLogoScroller assets={companies[0].assets} page="Home"/>
        </div>
        <PrivateEventButton>
          <a className="button button--pink button--transform-none button--text-black" href="mailto:groupsales@beatthebomb.com">Talk To Our Sales Team To Book Your Private Event</a>
        </PrivateEventButton>
      </PrivateEventInnerWrapper>
    </PrivateEventWrapper>
  )
}

export default PrivateEvents