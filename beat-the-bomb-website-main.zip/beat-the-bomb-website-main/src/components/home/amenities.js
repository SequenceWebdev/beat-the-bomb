import React from 'react'
import styled from 'styled-components'
import { GatsbyImage, getImage } from 'gatsby-plugin-image'

import Slider from "react-slick";
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";

const AmenityWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-evenly;
  margin-bottom: 2rem;
  padding: 0 2rem;

  @media screen and (max-width: 768px) {
    flex-direction: column;

  }
`

const Col1 = styled.div`
  width:50%;
  text-align: center;
  

  & h3{
    font-family: "Acumin-Black",sans-serif;
    font-style: normal;
    font-weight: 400;
    font-size: 80px;
    letter-spacing: .065em;
    text-transform: uppercase;
    color: #fff;
    transform: translateY(-10%);
  }

  @media only screen and (max-width: 1024px){
    & h3{
      font-size: 60px;
    }
  }

  @media only screen and (max-width:768px){
    width:100%;
  }

  @media screen and (max-width: 500px) {
    & h3{
      font-size: 50px;
    }
  }
`

const SlideItem = styled.div`
  width:100%;
  & p{
    font-family: "Acumin-Black",sans-serif;
    font-style: normal;
    font-weight: 400;
    font-size: 80px;
    letter-spacing: .065em;
    text-transform: uppercase;
    color: #fff;
  }

  .divider{
    width:50%;
    height:10px;
    border-top: 1px dotted var(--neon-pink);
    transform: translate(50%,-450%);

    @media only screen and (max-width:1024px){
      transform: translate(50%,-350%);
    }
  }

  @media only screen and (max-width: 1024px){
    & p{
      font-size: 60px;
    }
  }

  @media screen and (max-width: 500px) {
    & p{
      font-size: 50px;
    }
  }

`

const Col2 = styled.div`
  width: 50%;
  display: grid;
  grid-template-columns: repeat(2,1fr);
  grid-gap: 10px;
  margin-top:2rem;

  & p{
    font-family: 'Acumin Pro-700',sans-serif;
    font-size: 33px;
    letter-spacing: .065em;
    color: var(--neon-pink);
    font-weight: 700;
    text-transform: uppercase;

    @media only screen and (max-width:1024px){
      font-size:22px;
    }

    @media only screen and (max-width:768px){
      font-size:20px;
    }

    @media only screen and (max-width:500px){
      font-size:18px;
    }
  } 

  .amenity_icon{
    display:flex;
    align-items: center;
    flex-direction: column;
    text-align: center;
  }

  .amenity_icon_img{
    width:120px;
    aspect-ratio: 1;
  }

  @media screen and (max-width: 768px) {
    width:100%;
  }

  @media screen and (max-width: 500px) {

  }
`

const Amenities = ({ amenities }) =>{
  const settings = {
    arrows: false,
    autoplay: true,
    dots: false,
    infinite: true,
    pauseOnFocus: false,
    pauseOnHover: false,
    slidesToScroll: 1,
    slidesToShow: 1,
    speed: 500,
  };


  const amenity_items = amenities[0].amenities.references
  const amenity_texts = amenities[0].bodyTexts


  return (
    <AmenityWrapper>
      <Col1>
        <h3>Can your</h3>
        <Slider {...settings}>
          {amenity_texts.map((text, index) => (
            <SlideItem key={index}>
              <p>{text.body}</p>
              <div className="divider"></div>
            </SlideItem>
          ))}
        </Slider>
        <h3>Beat the bomb?</h3>
      </Col1>

      <Col2>
        {amenity_items.map((amenity, index) =>{
          const { title, amenityIcon } = amenity
          return(
            <div className="amenity_icon">
              <GatsbyImage alt={title} className="amenity_icon_img" key={index} image={getImage(amenityIcon.gatsbyImageData)}/>
              <p>{title}</p>
            </div>
          )
        })}
      </Col2>
    </AmenityWrapper>
  )
}

export default Amenities