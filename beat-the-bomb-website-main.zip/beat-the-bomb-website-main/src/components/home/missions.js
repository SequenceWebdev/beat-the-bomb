import React from 'react'
import styled from "styled-components"
import Mission from "./mission"

const MissionWrapper = styled.div`
  margin-bottom: 5rem;

  .bookButton{
    position:relative;
    left:50%;
    transform: translateX(-50%);
  }
 
  /* .banner h2{
    padding-right: 2rem;
    padding-left: 2rem;
  } */

`

const MissionInnerWrapper = styled.div`
  max-width:1920px;
  padding: 0rem 3rem;

  .body_text{
    font-family: "Acumin-Black",sans-serif;
    font-size: 45px;
    letter-spacing: .065em;
    color: #fff;
    text-align: center;
    margin-bottom: 1rem;
    padding-top:1rem;
  }

  & a{
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }

  @media screen and (min-width: 1920px) {
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }

  @media screen and (max-width: 768px) {
    padding: 0 1rem;
    .body_text{
      font-size: 25px;
    }
  }

  @media screen and (max-width: 500px) {
    .body_text{
      font-size: 20px;
    }
  }

  @media screen and (max-width: 425px) {
    .body_text{
      font-size: 18px;
    }
  }
`

const Missions = ({ games }) => {
  const { headerTitle, bodyTexts, buttonTexts, missions } = games[0]
  const mission1 = missions.references[0]
  const mission2 = missions.references[1]

  return (
    <MissionWrapper>
      <div className="banner banner--normal banner--angle-2 banner--blue">
        <h2 data-aos="fade-right" data-aos-once="true">
          {headerTitle}
        </h2>
      </div>
      <MissionInnerWrapper>
        <h3 className="body_text">{bodyTexts[0].body}</h3>
        <a className="button button--blue button--text-black button--xola" href="https://checkout.xola.com/index.html#buttons/61703987a2d9f8052c6bb522">{buttonTexts[0].button}</a>
        <h3 className="body_text">{bodyTexts[1].body}</h3>
        <h3 className="body_text">{bodyTexts[2].body}</h3>

        {/* {game mission 01: } */}
        <Mission mission={mission1} buttonText={buttonTexts[1].button}/>

        {/* {game mission 02: } */}
        <Mission mission={mission2} buttonText={buttonTexts[2].button}/>

        <a className="button button--pink button--text-black bookButton button--xola" href="https://checkout.xola.com/index.html#buttons/61703987a2d9f8052c6bb522">{buttonTexts[3].button}</a>
      </MissionInnerWrapper>
    </MissionWrapper>
  )
}

export default Missions