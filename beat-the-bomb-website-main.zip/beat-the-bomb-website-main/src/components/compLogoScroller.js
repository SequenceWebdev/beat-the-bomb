import React from 'react'
import styled from 'styled-components'

const ScrollerBody = styled.div`
  overflow: hidden;
  max-width: 1920px;
  margin: 1rem 0;
  z-index: 6;
  width:100%;
  position:relative;
  left:50%;
  transform: translateX(-50%);
  
  .slide-track{
    display:flex;
    align-items: center;
    width: min-content;
    animation: ${(props)=>props.currPage==="Virtual" ? "scroll 20s linear infinite":"scroll 80s linear infinite"};
  }

  .slider{
    display:flex;
    align-items: center;
  }

  .slide{
    width:auto;
    height:88px;
    margin: 0 1rem;
    padding: 1rem 2rem;
  }
  
  @keyframes scroll {
    0% {
      transform: translateX(0);
    }
    100% {
      transform:translateX(-50%)
    }
  }
`

const CompLogoScroller = ({assets, page}) => {  
  return (
    <ScrollerBody currPage={page}>
        <div className="slide-track">
          <div className="slider">
            {assets.map((asset, index) => {
              const {title, url} = asset
              return(
                <img key={index} alt={title} objectFit="contain" className="slide" imgClassName="slide-img" src={url}/>
              ) 
            })}
            {assets.map((asset, index) => {
              const {title, url} = asset
              return(
                <img key={index} alt={title} objectFit="contain" className="slide" imgClassName="slide-img" src={url}/>
              ) 
            })}
          </div>
        </div>
    </ScrollerBody>
  )
}

export default CompLogoScroller