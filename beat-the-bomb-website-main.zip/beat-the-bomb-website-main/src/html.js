// Core
import React from "react";
import PropTypes from "prop-types";
// Favicon
import favicon from "./assets/favicon.png";

export default function HTML(props) {
  return (
    <html {...props.htmlAttributes}>
      <head>
        {/* Required meta */}
        <meta charSet="utf-8" />
        <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport" />
        <meta content="en" name="language" />
        <meta content="ie=edge" httpEquiv="x-ua-compatible" />
        <meta content="index, follow" name="robots" />
        {/* Favicon */}
        <link href={favicon} rel="shortcut icon" type="image/png" />
        {/* Adobe Fonts */}
        {/* <link href="https://use.typekit.net/hwn7zem.css" rel="stylesheet" /> */}
        {/* XOLA*/}
        <script
          async 
          dangerouslySetInnerHTML={{
            __html: `
            (function() {
              var co=document.createElement("script");
              co.type="text/javascript"; co.async=true; co.src="https://xola.com/checkout.js";
              var s=document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(co, s); })();`,
          }}
        />
        {/* ABLyft script */}
        <script src="https://cdn.ablyft.com/s/41050127.js"></script>
        {/* Google Tag Manager */}
        <script
          async
          dangerouslySetInnerHTML={{
            __html: `
            (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
            new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
          })(window,document,'script','dataLayer','GTM-NXCGTN8');`,
          }}
        />
        {/* Dynamic head content */}
        {props.headComponents}
      </head>
      <body {...props.bodyAttributes}>
        {/* <!-- Google Tag Manager (noscript) --> */}
        <noscript
          dangerouslySetInnerHTML={{
            __html: `
              <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NXCGTN8"
              height="0" width="0" style="display:none;visibility:hidden"></iframe>
            `,
          }}
        />
        {/* <!-- END Google Tag Manager (noscript) --> */}
        {/* Dynamic pre body content */}
        {props.preBodyComponents}
        {/* Dynamic body content */}
        <div
          dangerouslySetInnerHTML={{ __html: props.body }}
          id="___gatsby"
          key={"body"}
        />
        {/* WisePops */}
        <script
          async
          dangerouslySetInnerHTML={{
            __html: `
            (function(W,i,s,e,P,o,p){W['WisePopsObject']=P;W[P]=W[P]||function(){
              (W[P].q=W[P].q||[]).push(arguments)},W[P].l=1*new Date();o=i.createElement(s),
              p=i.getElementsByTagName(s)[0];o.defer=1;o.src=e;p.parentNode.insertBefore(o,p)
            })(window,document,'script','//loader.wisepops.com/get-loader.js?v=1&site=fMPcURUy5j','wisepops');`,
          }}
        />
        <script
          async type="text/javascript"
          src="//static.klaviyo.com/onsite/js/klaviyo.js?company_id=Q8Ns4x"
        ></script>
        {/* Dynamic post body content */}
        {props.postBodyComponents}
      </body>
    </html>
  );
}

HTML.propTypes = {
  body: PropTypes.string,
  bodyAttributes: PropTypes.object,
  headComponents: PropTypes.array,
  htmlAttributes: PropTypes.object,
  postBodyComponents: PropTypes.array,
  preBodyComponents: PropTypes.array,
};
