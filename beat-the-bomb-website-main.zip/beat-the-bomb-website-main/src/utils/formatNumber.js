export default function turn(a) {
  if (a < 1000) return a;
  let result = [];
  let count = 1;
  while (a > 0) {
    let curr = a % 10;
    a = Math.floor(a / 10);
    result.push(curr);
    if (count === 3 && a > 0) {
      result.push(",");
      count = 0;
    }
    count++;
  }
  return result.reverse().join("");
}
