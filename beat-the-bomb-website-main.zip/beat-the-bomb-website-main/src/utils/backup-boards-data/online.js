/* eslint-disable sort-keys */
const myArr = [
    {
      "id": 335, "team_name": "5.2-backprop azz up", "game_1": 190, "game_2": 140, "game_3": 10, "total_bomb_time": 510, "total_score": 5100, "rank": 1, "percent_rank": 0,
    },
    {
      "id": 271, "team_name": "E.L. ", "game_1": 152, "game_2": 130, "game_3": 10, "total_bomb_time": 462, "total_score": 4620, "rank": 2, "percent_rank": 0.0054054054,
    },
    {
      "id": 135, "team_name": "Beat the Bomb", "game_1": 175, "game_2": 90, "game_3": 10, "total_bomb_time": 445, "total_score": 4450, "rank": 3, "percent_rank": 0.0108108108,
    },
    {
      "id": 336, "team_name": "1.2-nodes of ranvier", "game_1": 167, "game_2": 140, "game_3": 9, "total_bomb_time": 487, "total_score": 4383, "rank": 4, "percent_rank": 0.0162162162,
    },
    {
      "id": 340, "team_name": "4.2-Rage Against ML", "game_1": 147, "game_2": 100, "game_3": 10, "total_bomb_time": 427, "total_score": 4270, "rank": 5, "percent_rank": 0.0216216216,
    },
    {
      "id": 339, "team_name": "3.2-Adtech Dropouts", "game_1": 148, "game_2": 140, "game_3": 9, "total_bomb_time": 468, "total_score": 4212, "rank": 6, "percent_rank": 0.027027027,
    },
    {
      "id": 337, "team_name": "6.2-deepclusterducks", "game_1": 84, "game_2": 150, "game_3": 10, "total_bomb_time": 414, "total_score": 4140, "rank": 7, "percent_rank": 0.0324324324,
    },
    {
      "id": 229, "team_name": "6pm EST DANIEL", "game_1": 116, "game_2": 160, "game_3": 9, "total_bomb_time": 456, "total_score": 4104, "rank": 8, "percent_rank": 0.0378378378,
    },
    {
      "id": 338, "team_name": "2.2-Gaussbusters", "game_1": 160, "game_2": 150, "game_3": 8, "total_bomb_time": 490, "total_score": 3920, "rank": 9, "percent_rank": 0.0432432432,
    },
    {
      "id": 156, "team_name": "room 1", "game_1": 125, "game_2": 85, "game_3": 10, "total_bomb_time": 390, "total_score": 3900, "rank": 10, "percent_rank": 0.0486486486,
    }
  ]

export default (myArr);
