export const scores = [
  {
    bombDigits: 0,
    bombTimes: [0, 0, 0, 0],
    companyName: "company name",
    rank: 10000,
    teamName: "team name1",
    totalScore: 10000,
  },
  {
    bombDigits: 0,
    bombTimes: [0, 0, 0, 0],
    companyName: "company name",
    rank: 10000,
    teamName: "team name2",
    totalScore: 10000,
  },
  {
    bombDigits: 0,
    bombTimes: [0, 0, 0, 0],
    companyName: "company name",
    rank: 10000,
    teamName: "team name3",
    totalScore: 10000,
  },
  {
    bombDigits: 0,
    bombTimes: [0, 0, 0, 0],
    companyName: "company name",
    rank: 10000,
    teamName: "team name4",
    totalScore: 10000,
  },
  {
    bombDigits: 0,
    bombTimes: [0, 0, 0, 0],
    companyName: "company name",
    rank: 10000,
    teamName: "team name5",
    totalScore: 10000,
  },
];

export const versusScores = [
  {
    finalScore: "10 - 8",
    games: [
      "blue", "pink", "blue", "blue",
    ],
    loser: "rockets",
    winner: "lasers",
  },
  {
    finalScore: "10 - 8",
    games: [
      "pink", "blue", "blank", "blue",
    ],
    loser: "rockets",
    winner: "lasers",
  },
  {
    finalScore: "10 - 8",
    games: [
      "blue", "blank", "blank", "blue",
    ],
    loser: "rockets",
    winner: "lasers",
  },
  {
    finalScore: "10 - 8",
    games: [
      "blue", "pink", "blue", "pink",
    ],
    loser: "rockets",
    winner: "lasers",
  },
];
