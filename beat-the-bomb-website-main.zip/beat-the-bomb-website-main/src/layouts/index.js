import React from 'react'

import Navigation from "../components/navBar/navigation"
import Footer from "../components/footer/footer"
import Geolocation from '../components/geolocation';
// import AtlantaFooter from '../components/atlanta/atlantaFooter';

// Styles
import "./base.css";

import AOS from "aos";
import "aos/dist/aos.css";


class Layout extends React.Component {

  refreshXola() {
    // Remove Xola scripts
    document.head.querySelectorAll("script").forEach(script => {
      if (
        script.src.includes("xola") ||
        script.src.includes("iframeResizer") ||
        script.src.includes("polyfill.io")
      ) {
        script.remove();
      }
    });
    // Remove Xola iFrame
    const iframe = document.getElementById("xola-multi-item-checkout-app");
    if (iframe) {
      iframe.remove();
    }
    // Delete Xola objects
    delete window.xola;
    delete window.Xolabot;
    // Re-add Xola scripts
    window.setTimeout(() => {
      const script = document.createElement("script");
      script.async = true;
      script.src = "https://xola.com/checkout.js";
      script.type = "text/javascript";
      document.head.insertAdjacentElement("beforeEnd", script);
    }, 100);
  }

  componentDidMount() {
    if (window) {

        this.refreshXola();
      

      // Initiate AOS after 1 second to allow the DOM to properly load
      window.setTimeout(() => {
        AOS.init({ duration: 1500 });
      }, 1000);
    }
  }


  render(){
    const {
      children,
      pathname,
    } = this.props;

    return (
      <React.Fragment>
        <Navigation pathname={pathname}/>
        {pathname==='/' && <Geolocation/>}
        <main id="main_html">
          {children}
        </main>
        {/* {pathname === "/atlanta" ? <AtlantaFooter/>:<Footer />} */}
        <Footer pathname={pathname}/>
      </React.Fragment>
    )
  }
  
}

export default Layout;