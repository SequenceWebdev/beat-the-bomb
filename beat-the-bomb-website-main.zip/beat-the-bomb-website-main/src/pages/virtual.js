import React from 'react'
import Layout from "../layouts/index"
import { graphql } from "gatsby"

import site_image from "../assets/images/site.jpg";

// Components
import VirtualHero from "../components/virtual/virtualHero"
import VirtualCompanies from '../components/virtual/virtualCompanies'
import VirtualReviews from '../components/virtual/virtualReviews'
import VirtualGamePacks from '../components/virtual/virtualGamePacks'
import VirtualAmenities from '../components/virtual/virtualAmenities'
import VirtualChecklist from '../components/virtual/virtualChecklist'
import VirtualFAQ from '../components/virtual/virtualFAQ'
import VirtualDemo from '../components/virtual/virtualDemo'
import VirtualContact from '../components/virtual/virtualContact'
import Seo from '../components/seo';

const Virtual = ({ data }) => {
  const { nodes } = data.allContentfulVirtualPage;
  
  const hero = nodes.filter(node => node.sectionTitle==="01_VirtualGamePage - Hero")
  const comp = nodes.filter(node => node.sectionTitle==="02_VirtualGamePage - Company")
  const revs = nodes.filter(node => node.sectionTitle==="03_VirtualGamePage - Reviews")
  const games = nodes.filter(node => node.sectionTitle==="04_VirtualGamePage - Game Pack")
  const amenities = nodes.filter(node => node.sectionTitle==="05_VirtualGamePage - Amenities")
  const cl = nodes.filter(node => node.sectionTitle==="06_VirtualGamePage - Checklist")
  const faq = nodes.filter(node => node.sectionTitle==="07_VirtualGamePage - FAQ")
  const demo = nodes.filter(node => node.sectionTitle==="08_VirtualGamePage - Demo")
  const contact = nodes.filter(node => node.sectionTitle==="09_VirtualGamePage - Contact")
  return (
    <Layout pathname="/virtual">
      <Seo
        path="/virtual"
        description="Our video games are designed to strengthen team skills and maximize engagement in a fast-paced, one-of-a-kind experience"
        title="Beat The Bomb Virtual | Video games designed for virtual team building"
        seoImage={`https://beatthebomb.com${site_image}`}
      />
      {/* hero */}
      <VirtualHero hero={hero} />
      <VirtualCompanies companies={comp} />
      {/* review section */}
      <VirtualReviews reviews={revs} />
      <VirtualGamePacks games={games} />
      <VirtualAmenities amenities={amenities} />
      <VirtualChecklist checklist={cl} />
      <VirtualFAQ faq={faq} />
      <VirtualDemo demo={demo} />
      <VirtualContact contact={contact} />

    </Layout>
  )
}

export default Virtual;

export const query = graphql`
query VirtualQuery {
  allContentfulVirtualPage {
    nodes {
      sectionTitle
      headerTitle
      assets {
        gatsbyImageData
        title
        url
      }
      reviewTestimonial {
        references {
          name
          logo
          review {
            review
          }
          title
        }
      }
      bodyTexts {
        text
      }
      faq {
        question{
          question
        }
        answer{
          answer
        }
      }
    }
  }
}

`