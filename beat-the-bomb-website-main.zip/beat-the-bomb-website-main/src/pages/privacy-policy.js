import React from 'react'
import Layout from '../layouts'
import { graphql } from 'gatsby'
import { documentToReactComponents } from '@contentful/rich-text-react-renderer'
import { BLOCKS } from '@contentful/rich-text-types'
import styled from 'styled-components'
import Seo from '../components/seo'

const PrivacyPolicyWrapper = styled.div`
  max-width: 1920px;
  padding: 0 5rem;

  @media only screen and (max-width: 500px){
    padding: 0 1rem;
    display: flex;
    flex-direction: column;
  }

  @media only screen and (min-width:1920px){
    position: relative;
    left: 50%;
    transform: translateX(-50%);
  }
`

const PageHeader = styled.div`
  margin-top: 5rem;
  margin-bottom: 3rem;

  h1, h2{
    font-family: 'Acumin Pro', sans-serif;
    color: var(--neon-blue);
    text-align: left;
  }

  h1{
    font-size: 50px;
  }

  h2{
    font-size: 30px;
  }

  @media only screen and (max-width: 500px){
    margin-top: 0rem;

    h1{
    font-size: 40px;
  }

    h2{
    font-size: 25px;
  }
  }

`

const RichTextSection = styled.div`
  .rich_heading{
    font-family: 'Acumin Pro', sans-serif;
    font-size: 30px;
    color: var(--neon-pink);
    margin-top: 3rem;
    text-align: left;

    @media only screen and (max-width: 500px){
      font-size: 25px;
    }
  }

  .rich_paragraph{
    font-size: 25px;
    position: relative;
    font-family: 'Acumin Pro', sans-serif;
    font-weight: 200;
    color: #FFF;
    text-align: left;

    @media only screen and (max-width: 500px){
      font-size: 20px;
    }
  }

  .rich_ul{
    font-size: 20px;
    font-family: 'Acumin Pro', sans-serif;
    font-weight: 200;
    color: #FFF;
    text-align: left;

    @media only screen and (max-width: 500px){
      font-size: 16px;
    }
  }
`


const PrivacyPolicy = ({ data }) => {
  const {nodes} = data.allContentfulPrivacyPolicyPage;
  const { lastUpdated, markupTexts, pageTitle, title, description, image } = nodes[0]
  const contentful_content = JSON.parse(markupTexts.raw)
  
  const RICHTEXT_OPTIONS = {
    renderNode: {
      [BLOCKS.HEADING_4]: (node, children)=>{
        return (<h2 className='rich_heading'>{children}</h2>)
      },
      [BLOCKS.PARAGRAPH]: (node, children)=>{
        return <p className='rich_paragraph'>{children}</p>
      },
      [BLOCKS.UL_LIST]: (node, children)=>{
        return <ul className='rich_ul'>{children}</ul>
      },
    }
  }

  return (
    <Layout pathname="/privacy-policy">
      <Seo
        description={description}
        title={title}
        seoImage={image}
        path="/privacy-policy"
      />
      <PrivacyPolicyWrapper>
        <PageHeader>
          <h1>{pageTitle}</h1>
          <h2>Last Updated: {lastUpdated}</h2>
        </PageHeader>
        <RichTextSection>
          {documentToReactComponents(contentful_content, RICHTEXT_OPTIONS)}
        </RichTextSection>
      </PrivacyPolicyWrapper>
    </Layout>
  )
}

export default PrivacyPolicy

export const ppQuery = graphql`
query ppQuery {
  allContentfulPrivacyPolicyPage {
    nodes {
      pageTitle
      title
      description
      image {
        url
      }
      lastUpdated(formatString: "MMMM Do, YYYY")
      markupTexts {
        raw
      }
    }
  }
}

`