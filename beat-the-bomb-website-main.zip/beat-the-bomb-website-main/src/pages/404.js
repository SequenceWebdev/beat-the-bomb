import React from 'react'
import Layout from "../layouts/index";
import styled from 'styled-components';
import Seo from '../components/seo';
import site_image from "../assets/images/site.jpg";

const ErrorWrapper = styled.div`
  display:flex;
  width:100vw;
  justify-content: center;
  align-items: center;

  .text__container{
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-left: auto;
    margin-right: auto;
    padding: 0 20px;
    margin-top: 5rem;
    width: 70%;

    @media only screen and (max-width: 500px){
      margin-top: 3rem;
      width: 90%;
    }
  }

  .text__container p{
    color: white;
    font-family: "Acumin Pro";
    font-weight: 700;
    text-transform: uppercase;
    text-align: center;
    font-size: 70px;

    @media only screen and (max-width: 1250px){
      font-size: 65px;
    }

    @media only screen and (max-width: 1024px){
      font-size: 60px;
    }

    @media only screen and (max-width: 768px){
      font-size: 50px;
    }

    @media only screen and (max-width: 500px){
      font-size: 25px;
    }
  }
`

const ErrorPage = () => {
  return (
    <Layout pathname="/404">
      <Seo
        path="/404"
        description="Beat the Bomb's 404 Page"
        title="404 | Beat The Bomb"
        seoImage={`https://beatthebomb.com${site_image}`}
      />
      <ErrorWrapper>
        <div className="text__container">
          <p>Page is currently unavailable or under development</p>
          <br/>
          <p>Please come back later...</p>
        </div>
      </ErrorWrapper>
    </Layout>
  )
}

export default ErrorPage