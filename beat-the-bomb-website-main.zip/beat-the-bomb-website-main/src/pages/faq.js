import { graphql } from "gatsby";
import Seo from "../components/seo";
// Components
import Layout from "../layouts/index";

// Styles
import * as styles from "./styles/faq.module.css";

// Images
import site_image from "../assets/images/site.jpg";
import FaqQa from "../components/question-faq";
import * as React from 'react';
import ArrowCircleDownIcon from '@mui/icons-material/ArrowCircleDown';
// import {isMobile} from 'react-device-detect';

import { useState, useEffect } from 'react';
import styled from 'styled-components';
import ArrowCircleUpIcon from '@mui/icons-material/ArrowCircleUp';

const MyAccordion = styled.div`
    margin: 30px auto 0;
    border-radius: 4px;

   
	.sticky {
		position: sticky !important;
		top: 10%;
		z-index: 2;
		background-color: #FFFFFF !important;
	}


  .accordion-visible{
    background-color: #FFFFFF;
    width: 100%;
    color: var(--neon-pink);
    cursor: pointer;
    border: none;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    font-family: "Pixel";
    font-size: 24px;

    @media only screen and (max-width: 500px){
      font-size: 20px;
    }
  }

  .accordion-toggle{
    max-height: 0;
    overflow: hidden;
    transition: all 0.5s cubic-bezier(0, 1, 0, 1);
  }

  .accordion-toggle.show{
    height: auto;
    max-height: 999%;
    transition: all 0.5s cubic-bezier(1, 0, 1, 0);
  }
`

const FaqPage = ({ data }) => {
  const page_data = data.allContentfulFaqPage.nodes[0];
  const titles = Object.keys(page_data);

  const location_questions = ()=>{
    const init_question_arr = [];
    Object.entries(page_data).forEach(entry =>{
      init_question_arr.push(entry[1]);
    });

    return init_question_arr;
  }

  function _mapQuestions(set) {
    return (
      <div className={styles.faqText}>
        <FaqQa q={set.question.question} a={set.answer.answer}/>
      </div>
    );
  }

  const [selected, setSelected] = useState();
  // const [playAnimation, setPlayAnimation] = useState(false);

  const categories = {
    "experienceQuestions":"Experience Questions",
    "hostingAnEvent":"Hosting an Event",
    "visitingOurSpace":"Visiting Our Space",
    "otherQuestions": "Other Questions",
    "beatTheBombVirtual": "Beat The Bomb Virtual"
  }

  const [windowDimensions, setWindowDimensions] = useState(getWindowDimensions());

  function getWindowDimensions() {
    if(typeof window !== "undefined"){
       const { innerWidth: width } = window;
       return width;
    }
  }

  useEffect(() => {
    function handleResize() {
      setWindowDimensions(getWindowDimensions());
    }

    if(typeof window !=="undefined"){
      window.addEventListener('resize', handleResize);
      // return () => window.removeEventListener('resize', handleResize);
      
    }
  }, []);
  useEffect(() => {
    const onPageLoad = () => {
      // var html_main = document.main;
      var html_body = document.body;
      html_body.style.overflow = "visible";
      html_body.style.scrollBehavior = "smooth";

      var html_main = document.getElementById("main_html");
      html_main.style.overflow = "visible";
      html_main.style.scrollBehavior = "smooth";
    };
    const handleResize = () => {
      setWindowDimensions(getWindowDimensions());
    }

    // Check if the page has already loaded
    if (document.readyState === 'complete') {
      onPageLoad();
      handleResize();
    } else {
      if(typeof window !=="undefined"){
        window.addEventListener('load', onPageLoad);
        window.addEventListener('resize', handleResize);
      

        return () => {
          window.removeEventListener('load', onPageLoad);
          window.removeEventListener('resize', handleResize);
        }
      }
    }

    if(typeof window !=="undefined"){
      window.addEventListener('resize', handleResize);
      // return () => window.removeEventListener('resize', handleResize);
      
    }
  }, []);
    

  const getElementOriginalPos = () => {
    const arr =[]
    for (let i=0; i<location_questions.length ; i++){
      var element = document.getElementById(`accordion-${i}`);
      var elementPosition = element.getBoundingClientRect().top;
      arr.push(elementPosition);
    }
    return arr;
  }

  const accordionPos = getElementOriginalPos();

  const handleClick = (i) => {
    if(selected === i ){
      return setSelected(null);
    }
    setSelected(i);
    var headerOffset = 45;
    var elementPosition = accordionPos[i];
    var offsetPosition = elementPosition + window.pageYOffset - headerOffset;
    if(typeof window !== "undefined"){
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
    });
  }
  };

  var useIsMobile = () => {
    return windowDimensions <=500;
  }

  return (
    <Layout className={styles.faq} pathname="/faq" >
      <Seo
        path="/faq"
        description="Have questions about your Beat The Bomb experience? Curious about pricing or what to wear? Look at our FAQs!"
        title="Beat The Bomb | FAQs | Get all your questions answered!"
        seoImage={`https://beatthebomb.com${site_image}`}
      />
      <div className={styles.faqWrap}>
        <h1 className={styles.header}>FAQ</h1>
        {useIsMobile() && location_questions().map((questions, index)=>{
          return (
            <MyAccordion>
              <button id={`accordion-${index}`} className='accordion-visible sticky' onClick={()=>handleClick(index)}>
                <span>{categories[titles[`${index}`]]}</span>
                {selected === index ? <ArrowCircleUpIcon/> : <ArrowCircleDownIcon/>}
              </button>
              {((selected !== index) || (selected === undefined)) && <div className={"accordion-toggle"}>
                
              </div>}
              {(selected === index) && <div className={"accordion-toggle show"}>
                {questions.map((set)=>{
                  return(
                    _mapQuestions(set)
                  )
                })}
              </div>}
            </MyAccordion>
          );
        })}
        {!useIsMobile() && location_questions().map((questions, index)=>{
          return (
            <MyAccordion>
              <button className='accordion-visible'>
                <span>{categories[titles[`${index}`]]}</span>
              </button>
              <div className="accordion-toggle show">
                {questions.map((set)=>{
                  return(
                    _mapQuestions(set)
                  )
                })}
              </div>
            </MyAccordion>
          );
        })}
      </div>
    </Layout>
  );
}

export default FaqPage;

export const query = graphql`
query faqQuery {
  allContentfulFaqPage {
    nodes {
      experienceQuestions {
        question{
          question
        }
        answer{
          answer
        }
      }
      visitingOurSpace {
        question{
          question
        }
        answer{
          answer
        }
      }
      hostingAnEvent {
        question{
          question
        }
        answer{
          answer
        }
      }
      beatTheBombVirtual {
        question{
          question
        }
        answer{
          answer
        }
      }
      otherQuestions {
        question{
          question
        }
        answer{
          answer
        }
      }
    }
  }
}
`

