import React from "react";
import Seo from "../components/seo";

import 'bootstrap/dist/css/bootstrap.min.css';
import site_image from "../assets/images/site.jpg";
// import "../../node_modules/video-react/dist/video-react.css";
//components
import Layout from "../layouts/index";
// import BaysAnnouncement from "../components/bays/baysAnnouncement";
// import BaysHero from "../components/bays/baysHero";
// import BaysReviews from "../components/bays/baysReviews";
// import BaysExp from "../components/bays/baysExp";
// import BaysMissions from "../components/bays/baysMissions";
// import BaysEvents from "../components/bays/baysEvents";
// import BaysSocial from "../components/bays/baysSocial";

import Geolocation from "../components/geolocation";

const IndexPage = () => {
  // const { nodes } = data.allContentfulBaysPage;
  // const ann = nodes.filter(node => node.sectionTitle==="00_BaysPage - Announcement")
  // const hero = nodes.filter(node => node.sectionTitle==="01_BaysPage - Hero")
  // const rev = nodes.filter(node => node.sectionTitle==="02_BaysPage - Reviews")
  // const exp = nodes.filter(node => node.sectionTitle==="03_BaysPage - Experience")
  // const games = nodes.filter(node => node.sectionTitle==="04_BaysPage - Games")
  // const event = nodes.filter(node => node.sectionTitle==="05_BaysPage - Private Events")
  // const slider = nodes.filter(node => node.sectionTitle==="06_BaysPage - Slider")
  // const comp = nodes.filter(node => node.sectionTitle==="07_BaysPage - Companies")
  // const leag = nodes.filter(node => node.sectionTitle==="08_BaysPage - League")
  // const soc = nodes.filter(node=> node.sectionTitle === "09_BaysPage - Social")
  return (
    <Layout pathname="/old-index">
      <Seo
        path="/old-index"
        description="Dodge lasers, solve puzzles, & disarm a paint bomb or #GetBLASTED in Brooklyn; great for dates, companies, & any group!"
        title="Beat The Bomb | Brooklyn | Immersive Team Building Experience"
        seoImage={`https://beatthebomb.com${site_image}`}
      />
      {/* <BaysAnnouncement context={ann}/>
      <BaysHero context={hero}/>
      <BaysReviews context={rev}/>
      <BaysExp context={exp}/>
      <BaysMissions context={games}/>
      <BaysEvents pEvents={event} slider={slider} companies={comp} league={leag}/>
      <BaysSocial context={soc}/> */}
      <Geolocation/>
    </Layout>
  )
}

export default IndexPage

// export const bayQuery = graphql`
// query BayQuery {
//   allContentfulBaysPage {
//     nodes {
//       headerTitle
//       sectionTitle
//       imageAssets {
//         title
//         gatsbyImageData(
//           placeholder: BLURRED
//           breakpoints: [175, 250, 320, 375, 425, 768, 1024, 1440]
//           width:2560
//         )
//         url
//       }
//       bodyTexts {
//         text
//       }
//       missions {
//         references {
//           gameMissionTitle
//           url
//           missionDescription {
//             text
//           }
//           missionGames {
//             references {
//               name
//               gameDescription {
//                 gameDescription
//               }
//               gameMissionImageAssets {
//                 gatsbyImageData
//               }
//             }
//           }
//           missionCategories {
//             references {
//               gameType
//               gameTypeDescription
//               missionGames {
//                 references {
//                   name
//                   gameDescription {
//                     gameDescription
//                   }
//                   gameMissionImageAssets {
//                     gatsbyImageData
//                   }
//                 }
//               }
//             }
//           }
//           missionImages {
//             gatsbyImageData
//           }
//         }
//       }
//       reviewTestimonial {
//         references {
//           name
//           review {
//             review
//           }
//           logo
//         }
//       }
//       bookings {
//         references {
//           title
//           bodyTexts {
//             text
//           }
//           details{
//             text
//           }
//           imageAssets {
//             gatsbyImageData
//           }
//           url
//         }
//       }
//     }
//   }
// }
// `