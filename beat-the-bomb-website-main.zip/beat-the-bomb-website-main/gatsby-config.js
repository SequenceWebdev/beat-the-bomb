module.exports = {
  trailingSlash: "never",
  siteMetadata: {
    siteUrl: "https://www.beatthebomb.com",
    title: "Beat the Bomb",
    keywords: "NYC #1 Group Activity, escape room, Beat the Bomb, escape room near me"
  },
  plugins: [
    `gatsby-plugin-styled-components`,
    `gatsby-plugin-react-helmet`,
    {
      resolve: "gatsby-plugin-anchor-links",
      options: {
        offset: -150
      }
    },
    `gatsby-plugin-image`,
    {
      resolve: 'gatsby-plugin-sitemap',
      options: {
        exclude: ['/old-index'],
        query: `
        {
          site {
            siteMetadata {
              siteUrl
            }
          }
          allSitePage {
           nodes {
             path
           }
          }
      }`,
        serialize : ({site,allSitePage}) =>
             allSitePage.nodes.map(node => {
                let pVal = 0.5
                if(node.path === "/" || node.path === "/dc" || node.path === '/atlanta' || node.path === "/brooklyn"){
                  pVal = 0.7;
                }
                return {
                  url: `${site.siteMetadata.siteUrl}${node.path}`,
                  changefreq: `monthly`,
                  priority: pVal,
                }
              })
          },
    },
    `gatsby-plugin-sharp`,
    `gatsby-transformer-sharp`,
    'gatsby-plugin-remove-serviceworker',
    {
      resolve: `gatsby-source-filesystem`,
      options: {
        name: `pages`,
        path: `${__dirname}/src/pages/`,
      },
    },
    {
      resolve: `gatsby-source-contentful`,
      options: {
        spaceId: "83rvkxe1qxwz",
        accessToken: "yRci9CwT_Sgtq2RjUwmK0op1v_DZzsCKUXv8bVz4UlU"
      },
    },
  ],
}
